# u3K Android Player

Aplicación Android nativa para reproducir los `.mp3` del repositorio `softfxc/u3K`, con letras `.lrc` sincronizadas y una interfaz oscura inspirada en el diseño de referencia.

## Qué incluye

- Pantalla de entrada blanca con fundidos: “Música, maestro” y “Music, mr”.
- Biblioteca con buscador.
- Filtros: Todas, Favoritas y Recientes.
- Reproductor propio con controles básicos.
- Sincronización de letras LRC por posición de reproducción.
- Botón de traducción para alternar letras ES/EN cuando existen ambas.
- Catálogo `media.json` local en `app/src/main/assets/media.json`.
- Lectura remota opcional desde `https://raw.githubusercontent.com/softfxc/u3K/main/media.json`.
- Script `tools/generate_media_json.py` para regenerar el catálogo desde los `.mp3` y `.lrc` del repositorio.
- Workflow de GitHub Actions para compilar el APK.

## Estructura recomendada

Tu repositorio de música `softfxc/u3K` debería tener en la raíz:

```text
media.json
Cancion.mp3
Cancion.lrc
Cancion EN.lrc
Cancion ES.lrc
```

La app intenta cargar primero el `media.json` remoto. Si aún no existe o falla la conexión, usa el `media.json` incluido dentro de la app.

## Cómo generar media.json

Desde la raíz del proyecto Android:

```bash
python tools/generate_media_json.py > media.json
```

Después sube ese `media.json` a la raíz del repositorio `softfxc/u3K`.

## Cómo compilar en local

Con Android SDK y Gradle instalado:

```bash
gradle assembleDebug
```

El APK queda en:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Cómo compilar con GitHub Actions

Sube este proyecto a un repositorio GitHub y ejecuta el workflow **Build Android APK**. El APK se publicará como artefacto descargable.

## Notas

- La app usa `MediaPlayer` nativo, por lo que no depende de ExoPlayer ni de librerías externas de UI.
- Los pósters no se descargan del repositorio porque actualmente el repositorio listado solo contiene `.mp3`, `.lrc` y `README.md`. La app genera carátulas visuales internas por estilo.
- Para añadir carátulas reales, añade un campo opcional `coverUrl` al `media.json` y se puede extender el cargador de imágenes.


## Versión y paquete

- Versión de la app: `1.0`
- Application ID / paquete Android: `com.softfxc.u3k`

> Nota: Android no permite guiones (`-`) en el nombre de paquete, por eso el equivalente válido de `soft-fxc.com` es `com.softfxc.u3k`.
