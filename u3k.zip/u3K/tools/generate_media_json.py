#!/usr/bin/env python3
"""
Genera media.json desde los .mp3 y .lrc existentes en el repositorio GitHub.

Uso:
  python tools/generate_media_json.py > media.json

Después sube media.json a la raíz del repo softfxc/u3K para que la app lea el catálogo remoto:
  https://raw.githubusercontent.com/softfxc/u3K/main/media.json
"""

from __future__ import annotations

import json
import re
import unicodedata
import urllib.parse
import urllib.request
from collections import defaultdict
from datetime import date

OWNER = "softfxc"
REPO = "u3K"
BRANCH = "main"
API_URL = f"https://api.github.com/repos/{OWNER}/{REPO}/contents"
RAW_BASE = f"https://raw.githubusercontent.com/{OWNER}/{REPO}/{BRANCH}/"

DURATIONS_MS = {
    "Una fortuna sumergida": 232000,
    "Tenemos que hablar": 249000,
    "Esperanza - The Last of Us": 195000,
    "Sombras - The Last of Us": 221000,
    "Sueños lanzados - The Last of Us": 208000,
    "Cenizas y luz - The Last of Us": 242000,
    "Un buen hombre - The Last of Us": 165000,
    "Blood - Arcane": 202000,
    "Ayuda": 187000,
    "Ansiedad": 179000,
}

COVER_STYLES = {
    "Una fortuna sumergida": "ocean",
    "Tenemos que hablar": "sunset",
    "Ayuda": "sunset",
    "Ansiedad": "group",
    "Blood - Arcane": "red",
    "Today": "ocean",
    "afternoon": "sunset",
}

LANG_OVERRIDES = {
    "Blood - Arcane.lrc": "EN",
    "afternoon.lrc": "EN",
    "and nothing more.lrc": "EN",
}

TITLE_OVERRIDES = {
    " - Una fortuna sumergida.mp3": "Una fortuna sumergida",
    "today.mp3": "Today",
}

PREFERRED_ORDER = [
    "Una fortuna sumergida",
    "Tenemos que hablar",
    "Esperanza - The Last of Us",
    "Sombras - The Last of Us",
    "Sueños lanzados - The Last of Us",
    "Cenizas y luz - The Last of Us",
    "Un buen hombre - The Last of Us",
    "Blood - Arcane",
    "Ayuda",
    "Ansiedad",
]


def raw_url(name: str) -> str:
    return RAW_BASE + urllib.parse.quote(name)


def slug(text: str) -> str:
    normalized = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii")
    normalized = re.sub(r"[^a-zA-Z0-9]+", "-", normalized).strip("-").lower()
    return normalized or "track"


def strip_lang_suffix(stem: str) -> tuple[str, str | None]:
    patterns = [
        (r"\s*\[(EN|ES)\]$", None),
        (r"\s+(EN|ES)$", None),
    ]
    for pattern, _ in patterns:
        m = re.search(pattern, stem, flags=re.I)
        if m:
            lang = m.group(1).upper()
            title = re.sub(pattern, "", stem, flags=re.I).strip()
            return title, lang
    return stem.strip(), None


def title_from_mp3(name: str) -> str:
    if name in TITLE_OVERRIDES:
        return TITLE_OVERRIDES[name]
    return name[:-4].strip()


def title_from_lrc(name: str) -> tuple[str, str]:
    if name in LANG_OVERRIDES:
        return name[:-4].strip(), LANG_OVERRIDES[name]
    stem = name[:-4].strip()
    title, lang = strip_lang_suffix(stem)
    if lang is None:
        lang = "ES"
    return title, lang


def get_repo_files() -> list[str]:
    with urllib.request.urlopen(API_URL) as response:
        data = json.load(response)
    return [item["name"] for item in data if item.get("type") == "file"]


def author_for(title: str) -> str:
    return "" if "The Last of Us" in title else "Anxo"


def cover_file_for(title: str) -> str:
    if "The Last of Us" in title:
        return "cover2.jpg"
    if "-" in title or "–" in title:
        return "cover3.jpg"
    return "cover1.jpg"


def cover_style_for(title: str) -> str:
    if "The Last of Us" in title:
        return "logo"
    if "-" in title or "–" in title:
        return "red"
    return "sunset"


def main() -> None:
    names = get_repo_files()
    mp3_by_title = {}
    lrc_by_title = defaultdict(dict)

    for name in names:
        lower = name.lower()
        if lower.endswith(".mp3"):
            mp3_by_title[title_from_mp3(name)] = name
        elif lower.endswith(".lrc"):
            title, lang = title_from_lrc(name)
            lrc_by_title[title][lang] = name

    tracks = []
    used_ids = set()
    for title, mp3 in mp3_by_title.items():
        track_id = slug(title)
        base_id = track_id
        n = 2
        while track_id in used_ids:
            track_id = f"{base_id}-{n}"
            n += 1
        used_ids.add(track_id)
        tracks.append({
            "id": track_id,
            "title": title,
            "artist": author_for(title),
            "audioUrl": raw_url(mp3),
            **({"durationMs": DURATIONS_MS[title]} if title in DURATIONS_MS else {}),
            "coverStyle": cover_style_for(title),
            "coverUrl": raw_url(cover_file_for(title)),
            "lyrics": {lang: raw_url(filename) for lang, filename in sorted(lrc_by_title.get(title, {}).items())},
        })

    rank = {title: idx for idx, title in enumerate(PREFERRED_ORDER)}
    tracks.sort(key=lambda t: (rank.get(t["title"], 999), t["title"].lower()))

    print(json.dumps({
        "version": 2,
        "source": f"https://github.com/{OWNER}/{REPO}",
        "updatedAt": date.today().isoformat(),
        "tracks": tracks,
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
