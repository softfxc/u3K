package com.softfxc.u3k

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

class PlaybackNotificationService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        val title = intent?.getStringExtra("title") ?: "u3K"
        val playing = intent?.getBooleanExtra("playing", false) ?: false
        showNotification(title, playing)
        return START_STICKY
    }

    private fun showNotification(title: String, playing: Boolean) {
        createChannel()
        val openIntent = Intent(this, MainActivity::class.java)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        val contentIntent = PendingIntent.getActivity(this, 0, openIntent, flags)
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(com.softfxc.u3k.R.drawable.ic_stat_u3k)
            .setContentTitle(title)
            .setContentText(if (playing) "Reproduciendo" else "En pausa")
            .setContentIntent(contentIntent)
            .setOngoing(playing)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
            .build()
        startForeground(NOTIFICATION_ID, notification)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(CHANNEL_ID, "Reproducción u3K", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Reproducción en segundo plano"
                setSound(null, null)
            }
            manager.createNotificationChannel(channel)
        }
    }

    companion object {
        private const val CHANNEL_ID = "u3k_playback"
        private const val NOTIFICATION_ID = 2033
    }
}
