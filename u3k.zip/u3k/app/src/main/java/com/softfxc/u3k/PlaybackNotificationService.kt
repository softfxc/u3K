package com.softfxc.u3k

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat

class PlaybackNotificationService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_LOAD -> {
                val id = intent.getStringExtra(EXTRA_ID).orEmpty()
                val title = intent.getStringExtra(EXTRA_TITLE).orEmpty().ifBlank { "u3K" }
                val url = intent.getStringExtra(EXTRA_URL).orEmpty()
                val autoplay = intent.getBooleanExtra(EXTRA_AUTOPLAY, true)
                if (url.isNotBlank()) loadTrack(id, title, url, autoplay)
            }
            ACTION_TOGGLE -> toggle()
            ACTION_PLAY -> play()
            ACTION_PAUSE -> pause()
            ACTION_SEEK -> seekTo(intent.getIntExtra(EXTRA_POSITION, 0))
            ACTION_STOP -> {
                pause()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            else -> showNotification()
        }
        return START_STICKY
    }

    private fun loadTrack(id: String, title: String, url: String, autoplay: Boolean) {
        currentId = id
        currentTitle = title
        currentUrl = url
        prepared = false
        playing = false
        durationMs = 0
        positionMs = 0
        lastError = null
        showNotification()

        player?.setOnCompletionListener(null)
        player?.setOnPreparedListener(null)
        player?.setOnErrorListener(null)
        player?.release()
        player = null

        val mp = MediaPlayer()
        player = mp
        try {
            mp.setWakeMode(applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .build()
            )
            mp.setDataSource(this, Uri.parse(url))
            mp.setOnPreparedListener {
                prepared = true
                durationMs = it.duration.coerceAtLeast(1)
                positionMs = 0
                if (autoplay) {
                    it.start()
                    playing = true
                }
                showNotification()
            }
            mp.setOnCompletionListener {
                playing = false
                positionMs = durationMs
                showNotification()
            }
            mp.setOnErrorListener { _, what, extra ->
                prepared = false
                playing = false
                lastError = "$what/$extra"
                showNotification()
                true
            }
            mp.prepareAsync()
        } catch (e: Exception) {
            prepared = false
            playing = false
            lastError = e.message
            showNotification()
        }
    }

    private fun play() {
        val mp = player ?: return
        if (!prepared) return
        try {
            mp.start()
            playing = true
            showNotification()
        } catch (_: Exception) {}
    }

    private fun pause() {
        val mp = player ?: return
        try {
            if (mp.isPlaying) mp.pause()
            playing = false
            positionMs = mp.currentPosition
            showNotification()
        } catch (_: Exception) {}
    }

    private fun toggle() {
        val mp = player ?: return
        if (!prepared) return
        try {
            if (mp.isPlaying) pause() else play()
        } catch (_: Exception) {}
    }

    private fun seekTo(pos: Int) {
        val mp = player ?: return
        if (!prepared) return
        try {
            val safe = pos.coerceIn(0, mp.duration.coerceAtLeast(1))
            mp.seekTo(safe)
            positionMs = safe
        } catch (_: Exception) {}
    }

    private fun showNotification() {
        createChannel()

        val flags = PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        val openIntent = Intent(this, MainActivity::class.java)
        val contentIntent = PendingIntent.getActivity(this, 10, openIntent, flags)

        val toggleAction = if (playing) ACTION_PAUSE else ACTION_PLAY
        val toggleTitle = if (playing) "Pausa" else "Reproducir"
        val toggleIcon = if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        val toggleIntent = PendingIntent.getService(this, 11, Intent(this, PlaybackNotificationService::class.java).apply { action = toggleAction }, flags)
        val stopIntent = PendingIntent.getService(this, 12, Intent(this, PlaybackNotificationService::class.java).apply { action = ACTION_STOP }, flags)

        val subtitle = when {
            lastError != null -> "No se pudo reproducir"
            !prepared -> "Preparando reproducción"
            playing -> "Reproduciendo"
            else -> "En pausa"
        }

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(com.softfxc.u3k.R.drawable.ic_stat_u3k)
            .setContentTitle(currentTitle.ifBlank { "u3K" })
            .setContentText(subtitle)
            .setContentIntent(contentIntent)
            .setOngoing(playing)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
            .addAction(toggleIcon, toggleTitle, toggleIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Cerrar", stopIntent)
            .build()

        startForeground(NOTIFICATION_ID, notification)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(CHANNEL_ID, "Reproducción u3K", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Reproducción en segundo plano"
                setSound(null, null)
            }
            manager.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        player?.release()
        player = null
        prepared = false
        playing = false
        super.onDestroy()
    }

    data class State(
        val trackId: String?,
        val title: String,
        val prepared: Boolean,
        val playing: Boolean,
        val positionMs: Int,
        val durationMs: Int,
        val error: String?
    )

    companion object {
        const val ACTION_LOAD = "com.softfxc.u3k.action.LOAD"
        const val ACTION_TOGGLE = "com.softfxc.u3k.action.TOGGLE"
        const val ACTION_PLAY = "com.softfxc.u3k.action.PLAY"
        const val ACTION_PAUSE = "com.softfxc.u3k.action.PAUSE"
        const val ACTION_SEEK = "com.softfxc.u3k.action.SEEK"
        const val ACTION_STOP = "com.softfxc.u3k.action.STOP"

        const val EXTRA_ID = "id"
        const val EXTRA_TITLE = "title"
        const val EXTRA_URL = "url"
        const val EXTRA_AUTOPLAY = "autoplay"
        const val EXTRA_POSITION = "position"

        private const val CHANNEL_ID = "u3k_playback"
        private const val NOTIFICATION_ID = 2033

        @Volatile private var player: MediaPlayer? = null
        @Volatile private var currentId: String? = null
        @Volatile private var currentTitle: String = "u3K"
        @Volatile private var currentUrl: String? = null
        @Volatile private var prepared: Boolean = false
        @Volatile private var playing: Boolean = false
        @Volatile private var positionMs: Int = 0
        @Volatile private var durationMs: Int = 0
        @Volatile private var lastError: String? = null

        fun currentState(): State {
            val mp = player
            if (mp != null && prepared) {
                try {
                    positionMs = mp.currentPosition
                    durationMs = mp.duration.coerceAtLeast(durationMs.coerceAtLeast(1))
                    playing = mp.isPlaying
                } catch (_: Exception) {}
            }
            return State(currentId, currentTitle, prepared, playing, positionMs, durationMs, lastError)
        }

        fun isCurrentPlaying(id: String): Boolean {
            val state = currentState()
            return state.trackId == id && state.playing
        }
    }
}
