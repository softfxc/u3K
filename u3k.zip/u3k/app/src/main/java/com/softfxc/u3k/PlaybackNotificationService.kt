package com.softfxc.u3k

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import java.net.URL

class PlaybackNotificationService : Service() {
    private val ui = Handler(Looper.getMainLooper())
    private val progressTick = object : Runnable {
        override fun run() {
            refreshPosition()
            showNotification()
            if (playing) ui.postDelayed(this, 1000L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_LOAD -> {
                val id = intent.getStringExtra(EXTRA_ID).orEmpty()
                val title = intent.getStringExtra(EXTRA_TITLE).orEmpty().ifBlank { "Audio" }
                val url = intent.getStringExtra(EXTRA_URL).orEmpty()
                val coverUrl = intent.getStringExtra(EXTRA_COVER_URL).orEmpty()
                val mp3Name = intent.getStringExtra(EXTRA_MP3_NAME).orEmpty().ifBlank { mp3NameFromUrl(url) }
                val autoplay = intent.getBooleanExtra(EXTRA_AUTOPLAY, true)
                if (url.isNotBlank()) loadTrack(id, title, url, coverUrl, mp3Name, autoplay)
            }
            ACTION_TOGGLE -> toggle()
            ACTION_PLAY -> play()
            ACTION_PAUSE -> pause()
            ACTION_SEEK -> seekTo(intent.getIntExtra(EXTRA_POSITION, 0))
            ACTION_STOP -> {
                pause()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            else -> showNotification()
        }
        return START_STICKY
    }

    private fun loadTrack(id: String, title: String, url: String, coverUrl: String, mp3Name: String, autoplay: Boolean) {
        currentId = id
        currentTitle = title
        currentUrl = url
        currentCoverUrl = coverUrl
        currentMp3Name = mp3Name.ifBlank { mp3NameFromUrl(url) }
        currentCoverBitmap = null
        coverLoading = false
        coverFailedUrl = ""
        prepared = false
        playing = false
        durationMs = 0
        positionMs = 0
        lastError = null
        showNotification()
        loadCoverIfNeeded()

        player?.setOnCompletionListener(null)
        player?.setOnPreparedListener(null)
        player?.setOnErrorListener(null)
        player?.release()
        player = null

        val mp = MediaPlayer()
        player = mp
        try {
            mp.setWakeMode(applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .build()
            )
            mp.setDataSource(this, Uri.parse(url))
            mp.setOnPreparedListener {
                prepared = true
                durationMs = it.duration.coerceAtLeast(1)
                positionMs = 0
                if (autoplay) {
                    it.start()
                    playing = true
                }
                showNotification()
            }
            mp.setOnCompletionListener {
                playing = false
                positionMs = durationMs
                showNotification()
            }
            mp.setOnErrorListener { _, what, extra ->
                prepared = false
                playing = false
                lastError = "$what/$extra"
                showNotification()
                true
            }
            mp.prepareAsync()
        } catch (e: Exception) {
            prepared = false
            playing = false
            lastError = e.message
            showNotification()
        }
    }

    private fun play() {
        val mp = player ?: return
        if (!prepared) return
        try {
            mp.start()
            playing = true
            showNotification()
        } catch (_: Exception) {}
    }

    private fun pause() {
        val mp = player ?: return
        try {
            if (mp.isPlaying) mp.pause()
            playing = false
            positionMs = mp.currentPosition
            showNotification()
        } catch (_: Exception) {}
    }

    private fun toggle() {
        val mp = player ?: return
        if (!prepared) return
        try {
            if (mp.isPlaying) pause() else play()
        } catch (_: Exception) {}
    }

    private fun seekTo(pos: Int) {
        val mp = player ?: return
        if (!prepared) return
        try {
            val safe = pos.coerceIn(0, mp.duration.coerceAtLeast(1))
            mp.seekTo(safe)
            positionMs = safe
            showNotification()
        } catch (_: Exception) {}
    }

    private fun refreshPosition() {
        val mp = player ?: return
        if (!prepared) return
        try {
            positionMs = mp.currentPosition
            durationMs = mp.duration.coerceAtLeast(durationMs.coerceAtLeast(1))
            playing = mp.isPlaying
        } catch (_: Exception) {}
    }

    private fun showNotification() {
        createChannel()
        refreshPosition()
        loadCoverIfNeeded()

        val flags = PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        val contentIntent = PendingIntent.getActivity(this, 10, Intent(this, MainActivity::class.java), flags)

        val toggleAction = if (playing) ACTION_PAUSE else ACTION_PLAY
        val toggleIntent = PendingIntent.getService(this, 11, Intent(this, PlaybackNotificationService::class.java).apply { action = toggleAction }, flags)
        val stopIntent = PendingIntent.getService(this, 12, Intent(this, PlaybackNotificationService::class.java).apply { action = ACTION_STOP }, flags)

        val timing = if (prepared && durationMs > 0) "${formatTime(positionMs)} / ${formatTime(durationMs)}" else "0:00 / 0:00"
        val title = currentMp3Name.ifBlank { currentTitle.ifBlank { "audio.mp3" } }

        val collapsed = RemoteViews(packageName, R.layout.notification_u3k_small).apply {
            setTextViewText(R.id.notif_title, title)
            setTextViewText(R.id.notif_timing, timing)
            setOnClickPendingIntent(R.id.notif_root, contentIntent)
            setOnClickPendingIntent(R.id.notif_toggle, toggleIntent)
            setOnClickPendingIntent(R.id.notif_close, stopIntent)
            setImageViewResource(R.id.notif_toggle, if (playing) R.drawable.ic_u3k_pause_flat else R.drawable.ic_u3k_play_flat)
            currentCoverBitmap?.let { setImageViewBitmap(R.id.notif_cover_bg, it) }
                ?: setImageViewResource(R.id.notif_cover_bg, R.drawable.u3k_icon_transparent_real)
        }
        val expanded = RemoteViews(packageName, R.layout.notification_u3k_big).apply {
            setTextViewText(R.id.notif_title, title)
            setTextViewText(R.id.notif_timing, timing)
            setOnClickPendingIntent(R.id.notif_root, contentIntent)
            setOnClickPendingIntent(R.id.notif_toggle, toggleIntent)
            setOnClickPendingIntent(R.id.notif_close, stopIntent)
            setImageViewResource(R.id.notif_toggle, if (playing) R.drawable.ic_u3k_pause_flat else R.drawable.ic_u3k_play_flat)
            currentCoverBitmap?.let { setImageViewBitmap(R.id.notif_cover_bg, it) }
                ?: setImageViewResource(R.id.notif_cover_bg, R.drawable.u3k_icon_transparent_real)
        }

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_u3k)
            .setContentTitle(title)
            .setContentText(timing)
            .setContentIntent(contentIntent)
            .setOngoing(playing)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
            .setStyle(NotificationCompat.DecoratedCustomViewStyle())
            .setCustomContentView(collapsed)
            .setCustomBigContentView(expanded)
            .setCustomHeadsUpContentView(expanded)

        currentCoverBitmap?.let { builder.setLargeIcon(it) }
        if (prepared && durationMs > 0) builder.setProgress(durationMs, positionMs.coerceIn(0, durationMs), false)

        startForeground(NOTIFICATION_ID, builder.build())
        if (playing) {
            ui.removeCallbacks(progressTick)
            ui.postDelayed(progressTick, 1000L)
        } else {
            ui.removeCallbacks(progressTick)
        }
    }

    private fun loadCoverIfNeeded() {
        val url = currentCoverUrl
        if (url.isBlank() || currentCoverBitmap != null || coverLoading || coverFailedUrl == url) return
        coverLoading = true
        Thread {
            try {
                val bytes = URL(url).openStream().use { it.readBytes() }
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                if (bmp != null && currentCoverUrl == url) currentCoverBitmap = bmp
            } catch (_: Exception) {
                coverFailedUrl = url
            } finally {
                coverLoading = false
                ui.post { showNotification() }
            }
        }.start()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(CHANNEL_ID, "Reproducción", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Audio en segundo plano"
                setSound(null, null)
            }
            manager.createNotificationChannel(channel)
        }
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        ui.removeCallbacks(progressTick)
        try { player?.stop() } catch (_: Exception) {}
        player?.release()
        player = null
        prepared = false
        playing = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        ui.removeCallbacks(progressTick)
        player?.release()
        player = null
        prepared = false
        playing = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    data class State(
        val trackId: String?,
        val title: String,
        val prepared: Boolean,
        val playing: Boolean,
        val positionMs: Int,
        val durationMs: Int,
        val error: String?
    )

    companion object {
        const val ACTION_LOAD = "com.softfxc.u3k.action.LOAD"
        const val ACTION_TOGGLE = "com.softfxc.u3k.action.TOGGLE"
        const val ACTION_PLAY = "com.softfxc.u3k.action.PLAY"
        const val ACTION_PAUSE = "com.softfxc.u3k.action.PAUSE"
        const val ACTION_SEEK = "com.softfxc.u3k.action.SEEK"
        const val ACTION_STOP = "com.softfxc.u3k.action.STOP"

        const val EXTRA_ID = "id"
        const val EXTRA_TITLE = "title"
        const val EXTRA_URL = "url"
        const val EXTRA_COVER_URL = "coverUrl"
        const val EXTRA_MP3_NAME = "mp3Name"
        const val EXTRA_AUTOPLAY = "autoplay"
        const val EXTRA_POSITION = "position"

        private const val CHANNEL_ID = "u3k_playback"
        private const val NOTIFICATION_ID = 2033

        @Volatile private var player: MediaPlayer? = null
        @Volatile private var currentId: String? = null
        @Volatile private var currentTitle: String = ""
        @Volatile private var currentUrl: String? = null
        @Volatile private var currentCoverUrl: String = ""
        @Volatile private var currentMp3Name: String = "audio.mp3"
        @Volatile private var currentCoverBitmap: Bitmap? = null
        @Volatile private var coverLoading: Boolean = false
        @Volatile private var coverFailedUrl: String = ""
        @Volatile private var prepared: Boolean = false
        @Volatile private var playing: Boolean = false
        @Volatile private var positionMs: Int = 0
        @Volatile private var durationMs: Int = 0
        @Volatile private var lastError: String? = null

        fun currentState(): State {
            val mp = player
            if (mp != null && prepared) {
                try {
                    positionMs = mp.currentPosition
                    durationMs = mp.duration.coerceAtLeast(durationMs.coerceAtLeast(1))
                    playing = mp.isPlaying
                } catch (_: Exception) {}
            }
            return State(currentId, currentTitle, prepared, playing, positionMs, durationMs, lastError)
        }

        fun isCurrentPlaying(id: String): Boolean {
            val state = currentState()
            return state.trackId == id && state.playing
        }

        private fun formatTime(ms: Int): String {
            if (ms <= 0) return "0:00"
            val total = ms / 1000
            return "${total / 60}:${(total % 60).toString().padStart(2, '0')}"
        }

        private fun mp3NameFromUrl(url: String): String {
            return try {
                val raw = Uri.parse(url).lastPathSegment.orEmpty().ifBlank { url.substringAfterLast('/') }
                Uri.decode(raw).ifBlank { "audio.mp3" }
            } catch (_: Exception) {
                url.substringAfterLast('/').ifBlank { "audio.mp3" }
            }
        }
    }
}
