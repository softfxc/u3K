package com.softfxc.u3k

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Space
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

private const val REMOTE_MEDIA_JSON = "https://raw.githubusercontent.com/softfxc/u3K/main/media.json"
private const val REMOTE_BASE = "https://raw.githubusercontent.com/softfxc/u3K/main/"
private const val PROFILE_HAND_TEXT = "u3K: 'u' de you/tú, '3' del formato de audio mp3 y 'K' de mil como en redes sociales: tus miles de audios."
private const val GITHUB_REPO_URL = "https://github.com/softfxc/u3K"
private const val TLOU_VIDEO_URL = "https://raw.githubusercontent.com/softfxc/u3K/main/The%20Last%20of%20Us.mp4"
private const val PROFILE_STRANGER_VIDEO_URL = "https://raw.githubusercontent.com/softfxc/u3K/main/stranger%20things.mp4"
private const val PROFILE_ARCANE_VIDEO_URL = "https://raw.githubusercontent.com/softfxc/u3K/main/arcane.mp4"

private const val C_BG = 0xFF03060B.toInt()
private const val C_BG_2 = 0xFF07111E.toInt()
private const val C_SURFACE = 0xFF101826.toInt()
private const val C_SURFACE_2 = 0xFF151F2E.toInt()
private const val C_CARD = 0xFF172130.toInt()
private const val C_CARD_2 = 0xFF1D2A3B.toInt()
private const val C_STROKE = 0xFF2C3B4E.toInt()
private const val C_TEXT = 0xFFF6FAFF.toInt()
private const val C_MUTED = 0xFFAAB6C6.toInt()
private const val C_SOFT = 0xFF748399.toInt()
private const val C_ACCENT = 0xFF6EE7F9.toInt()
private const val C_ACCENT_DARK = 0xFF126173.toInt()
private const val C_GOLD = 0xFFFFD36A.toInt()
private const val C_GREEN = 0xFF4ADE80.toInt()
private const val C_PINK = 0xFFFF5C93.toInt()
private const val C_PURPLE = 0xFF9A78FF.toInt()
private const val C_ORANGE = 0xFFFF9F5C.toInt()

private const val PLAY = "▶"
private const val PAUSE = "Ⅱ"
private const val PREV = "‹"
private const val NEXT = "›"

private data class Track(
    val id: String,
    val title: String,
    val artist: String,
    val audioUrl: String,
    val durationMs: Long?,
    val coverStyle: String,
    val coverUrl: String?,
    val videoUrl: String?,
    val lyrics: Map<String, String>
)

private data class LyricLine(val timeMs: Long, val text: String)

private enum class FilterMode { ALL, FAVORITES, RECENTS }
private enum class Screen { LIBRARY, PLAYER, PROFILE, INTRO }

class MainActivity : Activity() {
    private lateinit var root: FrameLayout
    private val ui = Handler(Looper.getMainLooper())

    private var tracks: MutableList<Track> = mutableListOf()
    private var filterMode = FilterMode.ALL
    private var searchTerm = ""
    private var currentScreen = Screen.INTRO

    private val favorites = linkedSetOf<String>()
    private val recents = mutableListOf<String>()
    private var totalListens = 0
    private val playCounts = linkedMapOf<String, Int>()
    private val coverCache = linkedMapOf<String, Bitmap>()

    private var currentIndex = -1
    private var selectedLanguage = ""
    private var lyricLines = listOf<LyricLine>()
    private var lyricLabels = mutableListOf<TextView>()
    private var lastLyricIndex = -1
    private var countedStartForTrackId: String? = null
    private var isPrepared = false

    private var seekBar: SeekBar? = null
    private var elapsedView: TextView? = null
    private var durationView: TextView? = null
    private var playButton: TextView? = null
    private var lyricsContainer: LinearLayout? = null
    private var titleView: TextView? = null
    private var miniPlayButton: TextView? = null

    private val tick = object : Runnable {
        override fun run() {
            updatePlaybackUi()
            ui.postDelayed(this, 250)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window.statusBarColor = C_BG
        window.navigationBarColor = C_BG
        root = FrameLayout(this)
        root.background = appBackground()
        setContentView(root)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
        }
        showIntroThenStart()
    }

    override fun onDestroy() {
        ui.removeCallbacks(tick)
        super.onDestroy()
    }

    override fun onBackPressed() {
        when (currentScreen) {
            Screen.PLAYER, Screen.PROFILE -> buildLibraryScreen()
            else -> super.onBackPressed()
        }
    }

    private fun showIntroThenStart() {
        currentScreen = Screen.INTRO
        root.removeAllViews()
        root.background = appBackground()

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(28), 0, dp(28), 0)
        }
        root.addView(box, FrameLayout.LayoutParams(-1, -1))

        val logo = logoMark(dp(118), 38f).apply { alpha = 0f; scaleX = 0.82f; scaleY = 0.82f }
        box.addView(logo, LinearLayout.LayoutParams(dp(118), dp(118)).apply { bottomMargin = dp(22) })
        val title = label("u3K", 42f, C_TEXT, true).apply {
            alpha = 0f
            gravity = Gravity.CENTER
            letterSpacing = 0.04f
        }
        box.addView(title, LinearLayout.LayoutParams(-1, -2))
        val subtitle = label("Tus miles de audios", 16f, C_MUTED, false).apply {
            alpha = 0f
            gravity = Gravity.CENTER
        }
        box.addView(subtitle, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        fun startApp() {
            loadPrefs()
            loadMedia()
            ui.post(tick)
        }
        logo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(520).start()
        title.animate().alpha(1f).translationY(-dp(4).toFloat()).setStartDelay(160).setDuration(520).start()
        subtitle.animate().alpha(1f).setStartDelay(320).setDuration(520).withEndAction {
            ui.postDelayed({
                box.animate().alpha(0f).scaleX(0.98f).scaleY(0.98f).setDuration(360).withEndAction { startApp() }.start()
            }, 650)
        }.start()
    }

    private fun loadMedia() {
        root.removeAllViews()
        root.background = appBackground()
        val loading = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(28), 0, dp(28), 0)
        }
        root.addView(loading, FrameLayout.LayoutParams(-1, -1))
        loading.addView(logoMark(dp(86), 28f), LinearLayout.LayoutParams(dp(86), dp(86)).apply { bottomMargin = dp(18) })
        loading.addView(label("Cargando biblioteca desde GitHub", 17f, C_TEXT, true).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, -2))
        loading.addView(label("u3K no usa catálogo interno dentro del APK", 13f, C_MUTED, false).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        Thread {
            try {
                val raw = httpGet(REMOTE_MEDIA_JSON)
                val loaded = parseMediaJson(raw).toMutableList()
                runOnUiThread {
                    tracks = loaded
                    preloadCovers(tracks)
                    buildLibraryScreen()
                }
            } catch (e: Exception) {
                runOnUiThread { showLoadError(e.message ?: "error desconocido") }
            }
        }.start()
    }

    private fun showLoadError(detail: String) {
        root.removeAllViews()
        root.background = appBackground()
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(28), dp(28), dp(28), dp(28))
            background = rounded(C_SURFACE, dp(28), C_STROKE)
        }
        root.addView(panel, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER).apply { leftMargin = dp(22); rightMargin = dp(22) })
        panel.addView(label("No se pudo cargar la biblioteca", 21f, C_TEXT, true).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, -2))
        panel.addView(label("Revisa que media.json exista en GitHub y que sus URLs sean accesibles.", 14f, C_MUTED, false).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        panel.addView(label(detail, 12f, C_SOFT, false).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        panel.addView(actionPill("Reintentar", true) { loadMedia() }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(18) })
    }

    private fun parseMediaJson(json: String): List<Track> {
        val out = mutableListOf<Track>()
        val arr = JSONObject(json).getJSONArray("tracks")
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val lyricsObj = o.optJSONObject("lyrics")
            val lyrics = linkedMapOf<String, String>()
            if (lyricsObj != null) {
                val keys = lyricsObj.keys()
                while (keys.hasNext()) {
                    val originalKey = keys.next()
                    lyrics[originalKey.uppercase(Locale.ROOT)] = normalizeRemoteUrl(lyricsObj.getString(originalKey))
                }
            }
            val title = o.optString("title", "Audio ${i + 1}").ifBlank { "Audio ${i + 1}" }
            val coverUrlRaw = o.optString("coverUrl", "").takeIf { it.isNotBlank() } ?: defaultCoverUrl(title)
            val videoUrlRaw = o.optString("videoUrl", "").takeIf { it.isNotBlank() } ?: if (title.contains("The Last of Us", true)) TLOU_VIDEO_URL else null
            val duration = if (o.has("durationMs") && !o.isNull("durationMs")) o.optLong("durationMs") else null
            out += Track(
                id = o.optString("id", "track_$i").ifBlank { "track_$i" },
                title = title,
                artist = "",
                audioUrl = normalizeRemoteUrl(o.getString("audioUrl")),
                durationMs = duration,
                coverStyle = o.optString("coverStyle", defaultCoverStyle(title)),
                coverUrl = normalizeRemoteUrl(coverUrlRaw),
                videoUrl = videoUrlRaw?.let { normalizeRemoteUrl(it) },
                lyrics = lyrics
            )
        }
        return out
    }

    private fun buildLibraryScreen() {
        currentScreen = Screen.LIBRARY
        clearPlayerRefs()
        root.removeAllViews()
        root.background = appBackground()
        window.statusBarColor = C_BG
        window.navigationBarColor = C_BG

        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), statusBarInset() + dp(12), dp(18), navigationBarInset() + dp(6))
        }
        root.addView(shell, FrameLayout.LayoutParams(-1, -1))

        val scroll = ScrollView(this).apply { isFillViewport = false; clipToPadding = false }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content, FrameLayout.LayoutParams(-1, -2))
        shell.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        buildLibraryHeader(content)
        buildHeroCard(content)
        buildSearchAndFilters(content)

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; id = LIST_CONTAINER_ID }
        content.addView(list, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10); bottomMargin = dp(12) })
        refreshSongList()

        buildMiniPlayer(shell)
        buildBottomBar(shell, Screen.LIBRARY)
    }

    private fun clearPlayerRefs() {
        seekBar = null
        elapsedView = null
        durationView = null
        playButton = null
        lyricsContainer = null
        titleView = null
        miniPlayButton = null
        lyricLabels.clear()
    }

    private fun buildLibraryHeader(parent: LinearLayout) {
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        parent.addView(header, LinearLayout.LayoutParams(-1, dp(68)).apply { bottomMargin = dp(12) })
        header.addView(logoMark(dp(48), 16f), LinearLayout.LayoutParams(dp(48), dp(48)).apply { rightMargin = dp(12) })
        val copy = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(copy, LinearLayout.LayoutParams(0, -1, 1f))
        copy.addView(label("Biblioteca u3K", 27f, C_TEXT, true), LinearLayout.LayoutParams(-1, 0, 1f))
        copy.addView(label("Audios remotos · portada · letras · vídeo", 12.5f, C_MUTED, false), LinearLayout.LayoutParams(-1, 0, 1f))
        header.addView(actionPill("Perfil", false) { buildProfileScreen() }, LinearLayout.LayoutParams(dp(88), dp(42)))
    }

    private fun buildHeroCard(parent: LinearLayout) {
        val track = when {
            currentIndex >= 0 -> tracks.getOrNull(currentIndex)
            recents.isNotEmpty() -> tracks.firstOrNull { it.id == recents.first() }
            else -> tracks.firstOrNull()
        } ?: return
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = gradientRounded(intArrayOf(C_CARD_2, C_ACCENT_DARK, C_SURFACE), dp(30))
            setOnClickListener { openPlayer(tracks.indexOfFirst { it.id == track.id }.coerceAtLeast(0)) }
        }
        parent.addView(hero, LinearLayout.LayoutParams(-1, dp(154)).apply { bottomMargin = dp(16) })
        hero.addView(coverView(track, dp(112), dp(24), 18f), LinearLayout.LayoutParams(dp(112), dp(112)).apply { rightMargin = dp(16) })
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
        hero.addView(info, LinearLayout.LayoutParams(0, -1, 1f))
        info.addView(label("Sigue escuchando", 12f, C_ACCENT, true).apply { letterSpacing = 0.06f }, LinearLayout.LayoutParams(-1, -2))
        info.addView(label(track.title, 22f, C_TEXT, true).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        val metaText = if (track.durationMs != null) formatTime(track.durationMs) else "Disponible en GitHub"
        info.addView(label(metaText, 13f, C_MUTED, false), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        info.addView(actionPill(if (PlaybackNotificationService.isCurrentPlaying(track.id)) "Pausar" else "Reproducir", true) {
            val idx = tracks.indexOfFirst { it.id == track.id }.coerceAtLeast(0)
            if (currentIndex == idx && PlaybackNotificationService.currentState().trackId == track.id) togglePlayback() else openPlayer(idx)
        }, LinearLayout.LayoutParams(dp(132), dp(42)).apply { topMargin = dp(14) })
    }

    private fun buildSearchAndFilters(parent: LinearLayout) {
        val search = EditText(this).apply {
            id = SEARCH_FIELD_ID
            hint = "Buscar en tu biblioteca"
            setHintTextColor(C_SOFT)
            setTextColor(C_TEXT)
            textSize = 15f
            singleLineSet()
            background = rounded(C_SURFACE, dp(24), C_STROKE)
            setPadding(dp(18), 0, dp(18), 0)
            setText(searchTerm)
            setSelection(text?.length ?: 0)
            addTextChangedListener(SimpleTextWatcher { value ->
                searchTerm = value
                refreshSongList()
            })
        }
        parent.addView(search, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(12) })

        val chipsScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        chipsScroll.addView(chips, ViewGroup.LayoutParams(-2, -1))
        parent.addView(chipsScroll, LinearLayout.LayoutParams(-1, dp(44)))
        chips.addView(filterChip("Todas", FilterMode.ALL), LinearLayout.LayoutParams(dp(92), dp(38)).apply { rightMargin = dp(9) })
        chips.addView(filterChip("Guardadas", FilterMode.FAVORITES), LinearLayout.LayoutParams(dp(126), dp(38)).apply { rightMargin = dp(9) })
        chips.addView(filterChip("Recientes", FilterMode.RECENTS), LinearLayout.LayoutParams(dp(118), dp(38)).apply { rightMargin = dp(9) })
    }

    private fun refreshSongList() {
        val list = root.findViewById<LinearLayout>(LIST_CONTAINER_ID) ?: return
        list.removeAllViews()
        val q = searchTerm.trim().lowercase(Locale.ROOT)
        val filtered = tracks.filter { track ->
            val byFilter = when (filterMode) {
                FilterMode.ALL -> true
                FilterMode.FAVORITES -> favorites.contains(track.id)
                FilterMode.RECENTS -> recents.contains(track.id)
            }
            val byText = q.isBlank() || track.title.lowercase(Locale.ROOT).contains(q)
            byFilter && byText
        }.let { found ->
            if (filterMode == FilterMode.RECENTS) found.sortedBy { recents.indexOf(it.id).takeIf { pos -> pos >= 0 } ?: Int.MAX_VALUE } else found
        }

        val title = when (filterMode) {
            FilterMode.ALL -> "Todos los audios"
            FilterMode.FAVORITES -> "Audios guardados"
            FilterMode.RECENTS -> "Últimas escuchas"
        }
        list.addView(sectionTitle(title, "${filtered.size} elementos"), LinearLayout.LayoutParams(-1, dp(44)).apply { bottomMargin = dp(4) })

        if (filtered.isEmpty()) {
            list.addView(emptyState(), LinearLayout.LayoutParams(-1, dp(132)))
            return
        }
        filtered.forEachIndexed { i, track ->
            list.addView(songCard(track, i), LinearLayout.LayoutParams(-1, dp(92)).apply { bottomMargin = dp(10) })
        }
    }

    private fun sectionTitle(title: String, meta: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        addView(label(title, 19f, C_TEXT, true), LinearLayout.LayoutParams(0, -1, 1f))
        addView(label(meta, 12.5f, C_MUTED, false).apply { gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL }, LinearLayout.LayoutParams(dp(110), -1))
    }

    private fun emptyState(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        setPadding(dp(18), dp(18), dp(18), dp(18))
        background = rounded(C_SURFACE, dp(24), C_STROKE)
        val msg = if (filterMode == FilterMode.FAVORITES) "Todavía no has guardado ningún audio." else "No hay audios para este filtro."
        addView(label(msg, 15f, C_MUTED, false).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, -2))
    }

    private fun songCard(track: Track, position: Int): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(12), dp(10), dp(12), dp(10))
        val selected = tracks.getOrNull(currentIndex)?.id == track.id
        background = if (selected) gradientRounded(intArrayOf(C_CARD_2, C_SURFACE_2), dp(24)) else rounded(C_SURFACE, dp(24), C_STROKE)
        setOnClickListener { openPlayer(tracks.indexOfFirst { it.id == track.id }.coerceAtLeast(0)) }

        addView(coverView(track, dp(66), dp(18), 12f), LinearLayout.LayoutParams(dp(66), dp(66)).apply { rightMargin = dp(12) })
        val middle = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
        addView(middle, LinearLayout.LayoutParams(0, -1, 1f))
        middle.addView(label(track.title, 16f, C_TEXT, true).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }, LinearLayout.LayoutParams(-1, 0, 1f))
        val meta = when {
            selected && PlaybackNotificationService.isCurrentPlaying(track.id) -> "Reproduciendo ahora"
            track.durationMs != null -> formatTime(track.durationMs)
            else -> "Audio remoto"
        }
        middle.addView(label(meta, 12.5f, if (selected) C_ACCENT else C_MUTED, false), LinearLayout.LayoutParams(-1, 0, 1f))

        val fav = actionPill(if (favorites.contains(track.id)) "Guardada" else "Guardar", favorites.contains(track.id)) {
            toggleFavorite(track.id)
            refreshSongList()
        }
        addView(fav, LinearLayout.LayoutParams(dp(94), dp(38)).apply { leftMargin = dp(10) })
    }

    private fun filterChip(label: String, mode: FilterMode): TextView = TextView(this).apply {
        text = label
        gravity = Gravity.CENTER
        textSize = 13.5f
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        val selected = filterMode == mode
        setTextColor(if (selected) C_BG else C_TEXT)
        background = if (selected) gradientRounded(intArrayOf(C_ACCENT, C_GOLD), dp(20)) else rounded(C_SURFACE, dp(20), C_STROKE)
        setOnClickListener {
            filterMode = mode
            buildLibraryScreen()
        }
    }

    private fun openPlayer(index: Int) {
        if (tracks.isEmpty()) return
        currentIndex = index.coerceIn(0, tracks.lastIndex)
        addRecent(tracks[currentIndex].id)
        buildPlayerScreen()
        prepareCurrentTrack(true)
    }

    private fun buildPlayerScreen() {
        currentScreen = Screen.PLAYER
        val track = tracks.getOrNull(currentIndex) ?: return
        clearPlayerRefs()
        root.removeAllViews()
        root.background = playerBackground(track)
        window.statusBarColor = darken(lyricCardColor(track), 0.42f)
        window.navigationBarColor = C_BG
        lastLyricIndex = -1

        val scroll = ScrollView(this).apply { isFillViewport = true; clipToPadding = false }
        val main = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(18), statusBarInset() + dp(8), dp(18), navigationBarInset() + dp(12))
        }
        scroll.addView(main, FrameLayout.LayoutParams(-1, -2))
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        main.addView(top, LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(12) })
        top.addView(circleButton("Cerrar", false) { buildLibraryScreen() }, LinearLayout.LayoutParams(dp(86), dp(42)))
        top.addView(label("Ahora reproduciendo", 13f, C_MUTED, true).apply { gravity = Gravity.CENTER; letterSpacing = 0.08f }, LinearLayout.LayoutParams(0, -1, 1f))
        top.addView(circleButton("Perfil", false) { buildProfileScreen() }, LinearLayout.LayoutParams(dp(86), dp(42)))

        val coverSize = min(resources.displayMetrics.widthPixels - dp(44), dp(390))
        main.addView(nowPlayingVisual(track, coverSize), LinearLayout.LayoutParams(coverSize, coverSize).apply { bottomMargin = dp(18) })

        val titleCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            background = rounded(0xCC101826.toInt(), dp(28), C_STROKE)
        }
        main.addView(titleCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        titleCard.addView(row, LinearLayout.LayoutParams(-1, -2))
        titleView = label(track.title, 25f, C_TEXT, true).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END }
        row.addView(titleView, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(actionPill(if (favorites.contains(track.id)) "Guardada" else "Guardar", favorites.contains(track.id)) {
            toggleFavorite(track.id)
            buildPlayerScreen()
        }, LinearLayout.LayoutParams(dp(104), dp(42)).apply { leftMargin = dp(12) })

        seekBar = SeekBar(this).apply {
            max = (track.durationMs ?: 1L).toInt().coerceAtLeast(1)
            progress = 0
            progressTintList = ColorStateList.valueOf(C_ACCENT)
            thumbTintList = ColorStateList.valueOf(C_GOLD)
            progressBackgroundTintList = ColorStateList.valueOf(C_STROKE)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser && isPrepared) seekService(progress)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        titleCard.addView(seekBar, LinearLayout.LayoutParams(-1, dp(38)).apply { topMargin = dp(12) })
        val timeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        elapsedView = label("0:00", 12f, C_MUTED, false)
        durationView = label(if (track.durationMs != null) formatTime(track.durationMs) else "--:--", 12f, C_MUTED, false).apply { gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL }
        timeRow.addView(elapsedView, LinearLayout.LayoutParams(0, dp(22), 1f))
        timeRow.addView(durationView, LinearLayout.LayoutParams(0, dp(22), 1f))
        titleCard.addView(timeRow, LinearLayout.LayoutParams(-1, dp(24)))

        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        main.addView(controls, LinearLayout.LayoutParams(-1, dp(86)).apply { bottomMargin = dp(12) })
        controls.addView(roundControl(PREV, 30f) { previousTrack() }, LinearLayout.LayoutParams(0, dp(76), 1f))
        playButton = roundControl(PLAY, 30f) { togglePlayback() }.apply {
            setTextColor(C_BG)
            background = gradientRounded(intArrayOf(C_ACCENT, C_GOLD), dp(42))
        }
        controls.addView(playButton, LinearLayout.LayoutParams(dp(82), dp(82)))
        controls.addView(roundControl(NEXT, 30f) { nextTrack() }, LinearLayout.LayoutParams(0, dp(76), 1f))

        val lyricActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        main.addView(lyricActions, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(12) })
        lyricActions.addView(actionPill("Cambiar idioma", false) { toggleLyricsLanguage() }.apply { visibility = if (track.lyrics.size > 1) View.VISIBLE else View.GONE }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { rightMargin = dp(8) })
        lyricActions.addView(actionPill("Crear imagen", false) { showShareLyricsOptions() }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { leftMargin = dp(8) })

        lyricsContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.LEFT
            setPadding(dp(22), dp(22), dp(22), dp(26))
            background = gradientRounded(intArrayOf(lyricCardColor(track), darken(lyricCardColor(track), 0.60f)), dp(32))
        }
        main.addView(lyricsContainer, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(18) })
        renderLyricsLoading()
        if (lyricLines.isNotEmpty()) renderLyrics()
    }

    private fun prepareCurrentTrack(autoplay: Boolean) {
        val track = tracks.getOrNull(currentIndex) ?: return
        isPrepared = false
        countedStartForTrackId = null
        playButton?.text = PLAY
        seekBar?.progress = 0
        seekBar?.max = (track.durationMs ?: 1L).toInt().coerceAtLeast(1)
        elapsedView?.text = "0:00"
        durationView?.text = if (track.durationMs != null) formatTime(track.durationMs) else "--:--"

        selectedLanguage = when {
            track.lyrics.containsKey("ES") -> "ES"
            track.lyrics.containsKey("EN") -> "EN"
            track.lyrics.isNotEmpty() -> track.lyrics.keys.first()
            else -> ""
        }
        lyricLines = emptyList()
        loadLyrics(track)

        if (autoplay) registerListen(track.id)
        val intent = Intent(this, PlaybackNotificationService::class.java).apply {
            action = PlaybackNotificationService.ACTION_LOAD
            putExtra(PlaybackNotificationService.EXTRA_ID, track.id)
            putExtra(PlaybackNotificationService.EXTRA_TITLE, track.title)
            putExtra(PlaybackNotificationService.EXTRA_URL, track.audioUrl)
            putExtra(PlaybackNotificationService.EXTRA_AUTOPLAY, autoplay)
        }
        try {
            ContextCompat.startForegroundService(this, intent)
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo iniciar la reproducción: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun seekService(position: Int) {
        val intent = Intent(this, PlaybackNotificationService::class.java).apply {
            action = PlaybackNotificationService.ACTION_SEEK
            putExtra(PlaybackNotificationService.EXTRA_POSITION, position)
        }
        try { ContextCompat.startForegroundService(this, intent) } catch (_: Exception) {}
    }

    private fun togglePlayback() {
        val track = tracks.getOrNull(currentIndex) ?: return
        val state = PlaybackNotificationService.currentState()
        if (state.trackId != track.id) {
            prepareCurrentTrack(true)
            return
        }
        if (state.prepared && !state.playing) registerListen(track.id)
        val intent = Intent(this, PlaybackNotificationService::class.java).apply { action = PlaybackNotificationService.ACTION_TOGGLE }
        try {
            ContextCompat.startForegroundService(this, intent)
            ui.postDelayed({ updatePlaybackUi() }, 180)
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo controlar la reproducción: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun nextTrack() {
        if (tracks.isEmpty()) return
        currentIndex = if (currentIndex < 0) 0 else (currentIndex + 1) % tracks.size
        addRecent(tracks[currentIndex].id)
        buildPlayerScreen()
        prepareCurrentTrack(true)
    }

    private fun previousTrack() {
        if (tracks.isEmpty()) return
        currentIndex = if (currentIndex <= 0) tracks.lastIndex else currentIndex - 1
        addRecent(tracks[currentIndex].id)
        buildPlayerScreen()
        prepareCurrentTrack(true)
    }

    private fun updatePlaybackUi() {
        val track = tracks.getOrNull(currentIndex) ?: return
        val state = PlaybackNotificationService.currentState()
        if (state.trackId != track.id) return
        isPrepared = state.prepared
        val pos = state.positionMs.coerceAtLeast(0)
        val dur = state.durationMs.coerceAtLeast((track.durationMs ?: 1L).toInt()).coerceAtLeast(1)
        seekBar?.max = dur
        if (seekBar?.isPressed != true) seekBar?.progress = min(pos, dur)
        elapsedView?.text = formatTime(pos.toLong())
        durationView?.text = formatTime(dur.toLong())
        playButton?.text = if (state.playing) PAUSE else PLAY
        miniPlayButton?.text = if (state.playing) PAUSE else PLAY
        updateLyricHighlight(pos.toLong())
        if (state.error != null) {
            playButton?.text = PLAY
            miniPlayButton?.text = PLAY
        }
    }

    private fun loadLyrics(track: Track) {
        val url = track.lyrics[selectedLanguage]
        if (url.isNullOrBlank()) {
            renderLyricsMessage("Sin letra disponible")
            return
        }
        renderLyricsLoading()
        Thread {
            try {
                val text = httpGet(url)
                val parsed = parseLrc(text)
                runOnUiThread {
                    lyricLines = parsed
                    if (parsed.isEmpty()) renderLyricsMessage("Sin letra disponible") else renderLyrics()
                }
            } catch (_: Exception) {
                runOnUiThread { renderLyricsMessage("Sin letra disponible") }
            }
        }.start()
    }

    private fun toggleLyricsLanguage() {
        val track = tracks.getOrNull(currentIndex) ?: return
        if (track.lyrics.size <= 1) return
        val keys = track.lyrics.keys.sorted()
        val currentPos = keys.indexOf(selectedLanguage).takeIf { it >= 0 } ?: 0
        selectedLanguage = keys[(currentPos + 1) % keys.size]
        loadLyrics(track)
    }

    private fun renderLyricsLoading() {
        lyricsContainer?.removeAllViews()
        lyricLabels.clear()
        lastLyricIndex = -1
        lyricsContainer?.addView(label("Preparando letra", 17f, C_TEXT, true).apply { gravity = Gravity.LEFT }, LinearLayout.LayoutParams(-1, -2))
    }

    private fun renderLyricsMessage(message: String) {
        lyricsContainer?.removeAllViews()
        lyricLabels.clear()
        lyricsContainer?.addView(label(message, 18f, C_TEXT, true).apply {
            gravity = Gravity.LEFT
            setLineSpacing(dp(4).toFloat(), 1f)
        }, LinearLayout.LayoutParams(-1, -2))
    }

    private fun renderLyrics() {
        val box = lyricsContainer ?: return
        box.removeAllViews()
        lyricLabels.clear()
        lyricLines.forEach { line ->
            val tv = TextView(this).apply {
                text = line.text
                setTextColor(0xCCFFFFFF.toInt())
                alpha = 0.66f
                textSize = 21f
                gravity = Gravity.LEFT
                typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
                includeFontPadding = false
                setLineSpacing(dp(4).toFloat(), 1.0f)
                setPadding(0, dp(9), 0, dp(9))
            }
            lyricLabels += tv
            box.addView(tv, LinearLayout.LayoutParams(-1, -2))
        }
    }

    private fun updateLyricHighlight(positionMs: Long) {
        if (lyricLines.isEmpty() || lyricLabels.isEmpty()) return
        var idx = 0
        for (i in lyricLines.indices) {
            if (positionMs >= lyricLines[i].timeMs) idx = i else break
        }
        if (idx == lastLyricIndex) return
        lastLyricIndex = idx
        lyricLabels.forEachIndexed { i, tv ->
            val distance = abs(i - idx)
            when (distance) {
                0 -> {
                    tv.setTextColor(C_TEXT)
                    tv.alpha = 1f
                    tv.textSize = 26f
                }
                1 -> {
                    tv.setTextColor(0xE6FFFFFF.toInt())
                    tv.alpha = 0.86f
                    tv.textSize = 22f
                }
                else -> {
                    tv.setTextColor(0xB8FFFFFF.toInt())
                    tv.alpha = 0.52f
                    tv.textSize = 21f
                }
            }
        }
    }

    private fun parseLrc(text: String): List<LyricLine> {
        val out = mutableListOf<LyricLine>()
        val rx = Regex("\\[(\\d{1,2}):(\\d{2})(?:\\.(\\d{1,3}))?]")
        text.lineSequence().forEach { raw ->
            val matches = rx.findAll(raw).toList()
            if (matches.isEmpty()) return@forEach
            val lyricText = raw.substringAfterLast("]").trim()
            if (lyricText.isBlank()) return@forEach
            matches.forEach { m ->
                val min = m.groupValues[1].toLong()
                val sec = m.groupValues[2].toLong()
                val frac = m.groupValues.getOrNull(3).orEmpty()
                val ms = when (frac.length) {
                    0 -> 0L
                    1 -> frac.toLong() * 100
                    2 -> frac.toLong() * 10
                    else -> frac.take(3).toLong()
                }
                out += LyricLine(min * 60_000 + sec * 1_000 + ms, lyricText)
            }
        }
        return out.sortedBy { it.timeMs }
    }

    private fun buildProfileScreen() {
        currentScreen = Screen.PROFILE
        clearPlayerRefs()
        root.removeAllViews()
        root.background = appBackground()
        window.statusBarColor = C_BG
        window.navigationBarColor = C_BG

        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), statusBarInset() + dp(12), dp(18), navigationBarInset() + dp(6))
        }
        root.addView(shell, FrameLayout.LayoutParams(-1, -1))

        val scroll = ScrollView(this).apply { clipToPadding = false }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content, FrameLayout.LayoutParams(-1, -2))
        shell.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        content.addView(header, LinearLayout.LayoutParams(-1, dp(64)).apply { bottomMargin = dp(14) })
        header.addView(circleButton("Volver", false) { buildLibraryScreen() }, LinearLayout.LayoutParams(dp(92), dp(42)))
        header.addView(label("Perfil", 28f, C_TEXT, true).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(0, -1, 1f))
        header.addView(Space(this), LinearLayout.LayoutParams(dp(92), dp(42)))

        val profileCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(22))
            background = gradientRounded(intArrayOf(C_CARD_2, C_SURFACE, C_BG_2), dp(32))
        }
        content.addView(profileCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })
        profileCard.addView(logoMark(dp(82), 27f), LinearLayout.LayoutParams(dp(82), dp(82)).apply { bottomMargin = dp(16) })
        profileCard.addView(label("u3K", 32f, C_TEXT, true), LinearLayout.LayoutParams(-1, -2))
        profileCard.addView(label(PROFILE_HAND_TEXT, 16f, C_MUTED, false).apply {
            setLineSpacing(dp(4).toFloat(), 1f)
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        content.addView(stats, LinearLayout.LayoutParams(-1, dp(104)).apply { bottomMargin = dp(14) })
        stats.addView(statCard("Escuchas", totalListens.toString()), LinearLayout.LayoutParams(0, -1, 1f).apply { rightMargin = dp(8) })
        stats.addView(statCard("Guardadas", favorites.size.toString()), LinearLayout.LayoutParams(0, -1, 1f).apply { leftMargin = dp(4); rightMargin = dp(4) })
        stats.addView(statCard("Recientes", recents.size.toString()), LinearLayout.LayoutParams(0, -1, 1f).apply { leftMargin = dp(8) })

        content.addView(sectionTitle("Vídeos del perfil", "GitHub"), LinearLayout.LayoutParams(-1, dp(42)).apply { bottomMargin = dp(4) })
        content.addView(profileVideoCard("Stranger Things", PROFILE_STRANGER_VIDEO_URL), LinearLayout.LayoutParams(-1, dp(220)).apply { bottomMargin = dp(12) })
        content.addView(profileVideoCard("Arcane", PROFILE_ARCANE_VIDEO_URL), LinearLayout.LayoutParams(-1, dp(220)).apply { bottomMargin = dp(18) })

        val topTracks = playCounts.entries.sortedByDescending { it.value }.take(4)
        if (topTracks.isNotEmpty()) {
            content.addView(sectionTitle("Más escuchadas", "local"), LinearLayout.LayoutParams(-1, dp(42)).apply { bottomMargin = dp(4) })
            topTracks.forEach { entry ->
                val track = tracks.firstOrNull { it.id == entry.key } ?: return@forEach
                content.addView(songCard(track, 0), LinearLayout.LayoutParams(-1, dp(92)).apply { bottomMargin = dp(10) })
            }
        }

        buildMiniPlayer(shell)
        buildBottomBar(shell, Screen.PROFILE)
    }

    private fun statCard(labelText: String, value: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        setPadding(dp(8), dp(10), dp(8), dp(10))
        background = rounded(C_SURFACE, dp(24), C_STROKE)
        addView(label(value, 27f, C_ACCENT, true).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, 0, 1f))
        addView(label(labelText, 12f, C_MUTED, false).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, 0, 1f))
    }

    private fun profileVideoCard(title: String, url: String): FrameLayout {
        val frame = FrameLayout(this).apply { background = rounded(C_SURFACE, dp(28), C_STROKE); clipToOutline = true }
        val video = VideoView(this).apply { alpha = 0f }
        frame.addView(video, FrameLayout.LayoutParams(-1, -1))
        val overlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.BOTTOM
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x00101826, 0xEE03060B.toInt()))
        }
        frame.addView(overlay, FrameLayout.LayoutParams(-1, -1))
        overlay.addView(label(title, 22f, C_TEXT, true), LinearLayout.LayoutParams(-1, -2))
        overlay.addView(label("Reproducción automática silenciada. Puedes activar el audio.", 12.5f, C_MUTED, false), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
        var muted = true
        val audioButton = actionPill("Activar audio", false) {
            muted = !muted
            val mp = videoTagPlayer(video)
            mp?.setVolume(if (muted) 0f else 1f, if (muted) 0f else 1f)
            (it as? TextView)?.text = if (muted) "Activar audio" else "Silenciar"
        }
        overlay.addView(audioButton, LinearLayout.LayoutParams(dp(138), dp(42)).apply { topMargin = dp(12) })
        try {
            video.setVideoURI(Uri.parse(url))
            video.setOnPreparedListener { mp ->
                video.tag = mp
                mp.isLooping = true
                mp.setVolume(0f, 0f)
                video.alpha = 1f
                video.start()
            }
            video.setOnErrorListener { _, _, _ -> true }
        } catch (_: Exception) {}
        return frame
    }

    private fun videoTagPlayer(video: VideoView): MediaPlayer? = video.tag as? MediaPlayer

    private fun nowPlayingVisual(track: Track, sizePx: Int): FrameLayout {
        val outer = FrameLayout(this).apply {
            background = rounded(0x66101826, dp(34), C_STROKE)
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        val coverHolder = coverView(track, sizePx - dp(20), dp(28), 22f)
        outer.addView(coverHolder, FrameLayout.LayoutParams(sizePx - dp(20), sizePx - dp(20), Gravity.CENTER))
        val videoUrl = track.videoUrl
        if (!videoUrl.isNullOrBlank()) {
            val video = VideoView(this).apply { alpha = 0f; visibility = View.GONE }
            outer.addView(video, FrameLayout.LayoutParams(sizePx - dp(20), sizePx - dp(20), Gravity.CENTER))
            val hint = label("Toca para alternar portada y vídeo", 12f, C_TEXT, true).apply {
                gravity = Gravity.CENTER
                background = rounded(0xAA000000.toInt(), dp(18), 0)
                setPadding(dp(12), 0, dp(12), 0)
            }
            outer.addView(hint, FrameLayout.LayoutParams(-2, dp(36), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(18) })
            var showingVideo = false
            fun startVideo() {
                try {
                    video.setVideoURI(Uri.parse(videoUrl))
                    video.setOnPreparedListener { mp ->
                        mp.isLooping = true
                        mp.setVolume(0f, 0f)
                        video.alpha = 1f
                        video.start()
                    }
                    video.setOnErrorListener { _, _, _ -> true }
                } catch (_: Exception) {}
            }
            outer.setOnClickListener {
                showingVideo = !showingVideo
                if (showingVideo) {
                    video.visibility = View.VISIBLE
                    if (!video.isPlaying) startVideo()
                    hint.text = "Vídeo activo · toca para volver a portada"
                } else {
                    try { video.pause() } catch (_: Exception) {}
                    video.visibility = View.GONE
                    hint.text = "Toca para alternar portada y vídeo"
                }
            }
        }
        return outer
    }

    private fun buildMiniPlayer(parent: LinearLayout) {
        val track = tracks.getOrNull(currentIndex) ?: return
        val mini = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = gradientRounded(intArrayOf(C_CARD_2, C_SURFACE), dp(24))
            setOnClickListener { buildPlayerScreen() }
        }
        mini.addView(coverView(track, dp(52), dp(16), 9f), LinearLayout.LayoutParams(dp(52), dp(52)).apply { rightMargin = dp(12) })
        val copy = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
        mini.addView(copy, LinearLayout.LayoutParams(0, -1, 1f))
        copy.addView(label(track.title, 14.5f, C_TEXT, true).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }, LinearLayout.LayoutParams(-1, 0, 1f))
        copy.addView(label(if (PlaybackNotificationService.isCurrentPlaying(track.id)) "Sonando" else "Listo", 12f, C_ACCENT, false), LinearLayout.LayoutParams(-1, 0, 1f))
        mini.addView(actionPill(if (favorites.contains(track.id)) "Guardada" else "Guardar", favorites.contains(track.id)) {
            toggleFavorite(track.id)
            when (currentScreen) {
                Screen.LIBRARY -> buildLibraryScreen()
                Screen.PROFILE -> buildProfileScreen()
                else -> buildPlayerScreen()
            }
        }, LinearLayout.LayoutParams(dp(96), dp(40)).apply { leftMargin = dp(8) })
        miniPlayButton = roundControl(if (PlaybackNotificationService.isCurrentPlaying(track.id)) PAUSE else PLAY, 18f) { togglePlayback() }.apply {
            background = gradientRounded(intArrayOf(C_ACCENT, C_GOLD), dp(22))
            setTextColor(C_BG)
        }
        mini.addView(miniPlayButton, LinearLayout.LayoutParams(dp(46), dp(46)).apply { leftMargin = dp(8) })
        parent.addView(mini, LinearLayout.LayoutParams(-1, dp(72)).apply { topMargin = dp(6); bottomMargin = dp(8) })
    }

    private fun buildBottomBar(parent: LinearLayout, selected: Screen) {
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(6), dp(6), dp(6))
            background = rounded(0xEE101826.toInt(), dp(26), C_STROKE)
        }
        parent.addView(nav, LinearLayout.LayoutParams(-1, dp(58)))
        nav.addView(navItem("Biblioteca", selected == Screen.LIBRARY) { buildLibraryScreen() }, LinearLayout.LayoutParams(0, -1, 1f))
        nav.addView(navItem("Ahora", selected == Screen.PLAYER) {
            if (currentIndex >= 0) buildPlayerScreen() else if (tracks.isNotEmpty()) openPlayer(0)
        }, LinearLayout.LayoutParams(0, -1, 1f).apply { leftMargin = dp(6); rightMargin = dp(6) })
        nav.addView(navItem("Perfil", selected == Screen.PROFILE) { buildProfileScreen() }, LinearLayout.LayoutParams(0, -1, 1f))
    }

    private fun navItem(text: String, selected: Boolean, action: () -> Unit): TextView = TextView(this).apply {
        this.text = text
        gravity = Gravity.CENTER
        textSize = 13f
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        setTextColor(if (selected) C_BG else C_MUTED)
        background = if (selected) gradientRounded(intArrayOf(C_ACCENT, C_GOLD), dp(20)) else rounded(Color.TRANSPARENT, dp(20), 0)
        setOnClickListener { action() }
    }

    private fun showShareLyricsOptions() {
        val track = tracks.getOrNull(currentIndex) ?: return
        if (lyricLines.isEmpty()) {
            Toast.makeText(this, "Esta canción no tiene letra para crear imagen.", Toast.LENGTH_SHORT).show()
            return
        }
        var start = lastLyricIndex.coerceAtLeast(0).coerceAtMost(lyricLines.lastIndex)
        var count = 4
        var selectedColor = lyricCardColor(track)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), 0)
        }
        val preview = label("", 16f, C_TEXT, true).apply {
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = gradientRounded(intArrayOf(selectedColor, darken(selectedColor, 0.58f)), dp(22))
            setLineSpacing(dp(4).toFloat(), 1f)
        }
        fun updatePreview() {
            val text = shareTextFrom(start, count).ifBlank { lyricLines.getOrNull(start)?.text.orEmpty() }
            preview.text = text
            preview.background = gradientRounded(intArrayOf(selectedColor, darken(selectedColor, 0.58f)), dp(22))
        }
        layout.addView(preview, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })
        layout.addView(label("Inicio del fragmento", 13f, Color.DKGRAY, true), LinearLayout.LayoutParams(-1, -2))
        layout.addView(SeekBar(this).apply {
            max = lyricLines.lastIndex.coerceAtLeast(1)
            progress = start
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { start = progress; updatePreview() }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }, LinearLayout.LayoutParams(-1, dp(42)))
        layout.addView(label("Número de líneas", 13f, Color.DKGRAY, true), LinearLayout.LayoutParams(-1, -2))
        layout.addView(SeekBar(this).apply {
            max = 6
            progress = 2
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { count = progress + 2; updatePreview() }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }, LinearLayout.LayoutParams(-1, dp(42)))
        val colors = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        layout.addView(colors, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(6) })
        intArrayOf(C_ACCENT_DARK, C_PURPLE, C_PINK, C_ORANGE, C_GREEN).forEach { color ->
            colors.addView(TextView(this).apply {
                text = ""
                background = rounded(color, dp(18), C_STROKE)
                setOnClickListener { selectedColor = color; updatePreview() }
            }, LinearLayout.LayoutParams(0, dp(36), 1f).apply { leftMargin = dp(4); rightMargin = dp(4) })
        }
        updatePreview()

        val dialog = AlertDialog.Builder(this)
            .setTitle("Crear imagen de letra")
            .setView(layout)
            .setPositiveButton("Compartir") { _, _ -> shareLyricImage(track, shareTextFrom(start, count), selectedColor) }
            .setNegativeButton("Guardar") { _, _ -> saveLyricImage(track, shareTextFrom(start, count), selectedColor) }
            .setNeutralButton("Cancelar", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(C_ACCENT_DARK)
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(C_ACCENT_DARK)
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL)?.setTextColor(Color.DKGRAY)
        }
        dialog.show()
    }

    private fun shareLyricImage(track: Track, lyricText: String, baseColor: Int) {
        val bitmap = createLyricBitmap(track, lyricText, baseColor)
        val uri = saveBitmapToCache(bitmap, track)
        if (uri == null) {
            Toast.makeText(this, "No se pudo preparar la imagen.", Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, "u3K · $GITHUB_REPO_URL")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Compartir letra"))
    }

    private fun saveLyricImage(track: Track, lyricText: String, baseColor: Int) {
        val bitmap = createLyricBitmap(track, lyricText, baseColor)
        val uri = saveBitmapToGallery(bitmap, track)
        Toast.makeText(this, if (uri != null) "Imagen guardada en galería." else "No se pudo guardar la imagen.", Toast.LENGTH_SHORT).show()
    }

    private fun createLyricBitmap(track: Track, lyricText: String, baseColor: Int): Bitmap {
        val width = 1080
        val height = 1350
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        bgPaint.shader = LinearGradient(0f, 0f, width.toFloat(), height.toFloat(), baseColor, darken(baseColor, 0.38f), Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        val accentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x22FFFFFF; style = Paint.Style.FILL }
        canvas.drawCircle(width * 0.82f, height * 0.16f, 260f, accentPaint)
        canvas.drawCircle(width * 0.12f, height * 0.92f, 340f, accentPaint)

        val brand = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = C_GOLD
            textSize = 64f
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        }
        canvas.drawText("u3K", 76f, 112f, brand)

        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xDDFFFFFF.toInt()
            textSize = 34f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }
        drawWrappedText(canvas, track.title, titlePaint, 76f, 176f, width - 152, Layout.Alignment.ALIGN_NORMAL)

        val lyricPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 68f
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        }
        drawWrappedText(canvas, lyricText, lyricPaint, 76f, 440f, width - 152, Layout.Alignment.ALIGN_NORMAL)

        val repoPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xCCFFFFFF.toInt()
            textSize = 30f
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        }
        canvas.drawText(GITHUB_REPO_URL, 76f, height - 86f, repoPaint)
        return bitmap
    }

    private fun drawWrappedText(canvas: Canvas, text: String, paint: TextPaint, x: Float, y: Float, width: Int, alignment: Layout.Alignment) {
        val layout = StaticLayout.Builder.obtain(text, 0, text.length, paint, width)
            .setAlignment(alignment)
            .setLineSpacing(8f, 1f)
            .setIncludePad(false)
            .build()
        canvas.save()
        canvas.translate(x, y)
        layout.draw(canvas)
        canvas.restore()
    }

    private fun saveBitmapToCache(bitmap: Bitmap, track: Track): Uri? = try {
        val dir = File(cacheDir, "shared").apply { mkdirs() }
        val file = File(dir, "u3k_${safeFilePart(track.title)}_${System.currentTimeMillis()}.png")
        FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
    } catch (_: Exception) { null }

    private fun saveBitmapToGallery(bitmap: Bitmap, track: Track): Uri? = try {
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "u3k_${safeFilePart(track.title)}_${System.currentTimeMillis()}.png")
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/u3K")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
            contentResolver.openOutputStream(uri)?.use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            uri
        } else {
            saveBitmapToCache(bitmap, track)
        }
    } catch (_: Exception) { null }

    private fun toggleFavorite(id: String) {
        if (favorites.contains(id)) favorites.remove(id) else favorites.add(id)
        savePrefs()
    }

    private fun addRecent(id: String) {
        recents.remove(id)
        recents.add(0, id)
        while (recents.size > 25) recents.removeAt(recents.lastIndex)
        savePrefs()
    }

    private fun registerListen(id: String) {
        if (countedStartForTrackId == id) return
        countedStartForTrackId = id
        totalListens += 1
        playCounts[id] = (playCounts[id] ?: 0) + 1
        savePrefs()
    }

    private fun loadPrefs() {
        val sp = getSharedPreferences("u3k_prefs", Context.MODE_PRIVATE)
        favorites.clear()
        favorites.addAll(sp.getString("favorites", "")?.split("|")?.filter { it.isNotBlank() }.orEmpty())
        recents.clear()
        recents.addAll(sp.getString("recents", "")?.split("|")?.filter { it.isNotBlank() }.orEmpty())
        totalListens = sp.getInt("total_listens", 0)
        playCounts.clear()
        sp.getString("play_counts", "")?.split("|")?.forEach { part ->
            val pieces = part.split(":")
            if (pieces.size == 2) playCounts[pieces[0]] = pieces[1].toIntOrNull() ?: 0
        }
    }

    private fun savePrefs() {
        val sp = getSharedPreferences("u3k_prefs", Context.MODE_PRIVATE)
        sp.edit()
            .putString("favorites", favorites.joinToString("|"))
            .putString("recents", recents.joinToString("|"))
            .putInt("total_listens", totalListens)
            .putString("play_counts", playCounts.entries.joinToString("|") { "${it.key}:${it.value}" })
            .apply()
    }

    private fun coverView(track: Track, sizePx: Int, radiusPx: Int, labelSize: Float): FrameLayout {
        val frame = FrameLayout(this).apply {
            background = coverDrawable(track.coverStyle, radiusPx)
            clipToOutline = true
        }
        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = 0f
        }
        val label = TextView(this).apply {
            text = coverLabel(track)
            gravity = Gravity.CENTER
            setTextColor(C_TEXT)
            textSize = labelSize
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            alpha = 0.9f
        }
        frame.addView(image, FrameLayout.LayoutParams(sizePx, sizePx))
        frame.addView(label, FrameLayout.LayoutParams(sizePx, sizePx))
        track.coverUrl?.let { loadCoverImage(it, image, label) }
        return frame
    }

    private fun loadCoverImage(url: String, imageView: ImageView, fallbackLabel: TextView) {
        coverCache[url]?.let {
            imageView.setImageBitmap(it)
            imageView.alpha = 1f
            fallbackLabel.visibility = View.GONE
            return
        }
        Thread {
            try {
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 10000
                conn.readTimeout = 10000
                conn.setRequestProperty("User-Agent", "u3K-Android-Player")
                val bitmap = conn.inputStream.use { BitmapFactory.decodeStream(it) }
                if (bitmap != null) {
                    coverCache[url] = bitmap
                    runOnUiThread {
                        imageView.setImageBitmap(bitmap)
                        imageView.animate().alpha(1f).setDuration(250).start()
                        fallbackLabel.visibility = View.GONE
                    }
                }
            } catch (_: Exception) {}
        }.start()
    }

    private fun preloadCovers(list: List<Track>) {
        val urls = list.mapNotNull { it.coverUrl }.distinct().filter { !coverCache.containsKey(it) }
        if (urls.isEmpty()) return
        Thread {
            urls.forEach { url ->
                try {
                    val conn = URL(url).openConnection() as HttpURLConnection
                    conn.connectTimeout = 8000
                    conn.readTimeout = 8000
                    conn.setRequestProperty("User-Agent", "u3K-Android-Player")
                    val bitmap = conn.inputStream.use { BitmapFactory.decodeStream(it) }
                    if (bitmap != null) coverCache[url] = bitmap
                } catch (_: Exception) {}
            }
        }.start()
    }

    private fun defaultCoverUrl(title: String): String {
        val file = when {
            title.contains("The Last of Us", true) -> "cover2.jpg"
            title.contains("-") || title.contains("–") -> "cover3.jpg"
            else -> "cover1.jpg"
        }
        return REMOTE_BASE + file
    }

    private fun defaultCoverStyle(title: String): String = when {
        title.contains("The Last of Us", true) -> "ocean"
        title.contains("-") || title.contains("–") -> "purple"
        else -> "gold"
    }

    private fun coverLabel(track: Track): String {
        val clean = track.title.trim()
        if (clean.isBlank()) return "u3K"
        val words = clean.split(Regex("\\s+")).filter { it.isNotBlank() }
        return words.take(2).joinToString("") { it.first().uppercaseChar().toString() }.take(3).ifBlank { "u3K" }
    }

    private fun normalizeRemoteUrl(value: String): String {
        val trimmed = value.trim()
        if (trimmed.isBlank()) return trimmed
        if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) return trimmed.replace(" ", "%20")
        val encoded = trimmed.trimStart('/').split('/').joinToString("/") { Uri.encode(it) }
        return REMOTE_BASE + encoded
    }

    private fun appBackground(): GradientDrawable = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(C_BG, C_BG_2, C_BG)
    )

    private fun playerBackground(track: Track): GradientDrawable = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM,
        intArrayOf(darken(lyricCardColor(track), 0.54f), C_BG_2, C_BG)
    )

    private fun lyricCardColor(track: Track): Int {
        val colors = intArrayOf(C_ACCENT_DARK, C_PURPLE, C_PINK, C_ORANGE, 0xFF2F7D65.toInt())
        return colors[(track.id.hashCode() and Int.MAX_VALUE) % colors.size]
    }

    private fun darken(color: Int, factor: Float): Int {
        val a = Color.alpha(color)
        val r = (Color.red(color) * factor).toInt().coerceIn(0, 255)
        val g = (Color.green(color) * factor).toInt().coerceIn(0, 255)
        val b = (Color.blue(color) * factor).toInt().coerceIn(0, 255)
        return Color.argb(a, r, g, b)
    }

    private fun rounded(fill: Int, radius: Int, stroke: Int): GradientDrawable = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = radius.toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    private fun gradientRounded(colors: IntArray, radius: Int): GradientDrawable = GradientDrawable(GradientDrawable.Orientation.TL_BR, colors).apply {
        cornerRadius = radius.toFloat()
    }

    private fun coverDrawable(style: String, radius: Int): GradientDrawable {
        val colors = when (style.lowercase(Locale.ROOT)) {
            "ocean" -> intArrayOf(0xFF164E63.toInt(), 0xFF0F172A.toInt())
            "sunset" -> intArrayOf(0xFF7C2D12.toInt(), 0xFF111827.toInt())
            "red" -> intArrayOf(0xFF7F1D1D.toInt(), 0xFF111827.toInt())
            "purple" -> intArrayOf(0xFF4C1D95.toInt(), 0xFF111827.toInt())
            "gold" -> intArrayOf(0xFF5D4218.toInt(), 0xFF111827.toInt())
            "group" -> intArrayOf(0xFF334155.toInt(), 0xFF111827.toInt())
            else -> intArrayOf(C_CARD_2, C_SURFACE)
        }
        return GradientDrawable(GradientDrawable.Orientation.TL_BR, colors).apply { cornerRadius = radius.toFloat() }
    }

    private fun label(text: String, sp: Float, color: Int, bold: Boolean): TextView = TextView(this).apply {
        this.text = text
        setTextColor(color)
        textSize = sp
        typeface = Typeface.create(if (bold) "sans-serif-black" else "sans-serif", if (bold) Typeface.BOLD else Typeface.NORMAL)
        includeFontPadding = true
    }

    private fun actionPill(text: String, selected: Boolean, action: (View) -> Unit): TextView = TextView(this).apply {
        this.text = text
        gravity = Gravity.CENTER
        textSize = 12.5f
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        setTextColor(if (selected) C_BG else C_TEXT)
        background = if (selected) gradientRounded(intArrayOf(C_ACCENT, C_GOLD), dp(21)) else rounded(0xAA172130.toInt(), dp(21), C_STROKE)
        setOnClickListener { action(it) }
    }

    private fun circleButton(text: String, selected: Boolean, action: () -> Unit): TextView = TextView(this).apply {
        this.text = text
        gravity = Gravity.CENTER
        textSize = 12.5f
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        setTextColor(if (selected) C_BG else C_TEXT)
        background = if (selected) gradientRounded(intArrayOf(C_ACCENT, C_GOLD), dp(22)) else rounded(0x99101826.toInt(), dp(22), C_STROKE)
        setOnClickListener { action() }
    }

    private fun roundControl(text: String, sp: Float, action: () -> Unit): TextView = TextView(this).apply {
        this.text = text
        gravity = Gravity.CENTER
        textSize = sp
        typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        includeFontPadding = false
        setTextColor(C_TEXT)
        background = rounded(0x77101826.toInt(), dp(40), C_STROKE)
        setOnClickListener { action() }
    }

    private fun logoMark(sizePx: Int, textSizeSp: Float): TextView = TextView(this).apply {
        text = "u3K"
        setTextColor(C_GOLD)
        textSize = textSizeSp
        typeface = Typeface.create("serif", Typeface.BOLD)
        gravity = Gravity.CENTER
        includeFontPadding = false
        background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFFBAE6FD.toInt(), 0xFF38BDF8.toInt(), 0xFF1D4ED8.toInt())).apply {
            shape = GradientDrawable.OVAL
            setStroke(dp(1), 0x99FFFFFF.toInt())
        }
    }

    private fun shareTextFrom(start: Int, count: Int): String {
        if (lyricLines.isEmpty()) return ""
        val from = start.coerceIn(0, lyricLines.lastIndex)
        val to = min(lyricLines.size, from + count.coerceAtLeast(1))
        return lyricLines.subList(from, to).joinToString("\n") { it.text }
    }

    private fun focusSearchField() {
        val search = root.findViewById<EditText>(SEARCH_FIELD_ID) ?: return
        search.requestFocus()
        (getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager)?.showSoftInput(search, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun formatTime(ms: Long?): String {
        val total = max(0, (ms ?: 0L) / 1000)
        val min = total / 60
        val sec = total % 60
        return "%d:%02d".format(Locale.ROOT, min, sec)
    }

    private fun safeFilePart(value: String): String = value.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9]+"), "_").trim('_').take(50).ifBlank { "letra" }

    private fun statusBarInset(): Int {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else 0
    }

    private fun navigationBarInset(): Int {
        val id = resources.getIdentifier("navigation_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else 0
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun TextView.singleLineSet() { setSingleLine(true) }

    private fun httpGet(url: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 12000
        conn.readTimeout = 12000
        conn.setRequestProperty("User-Agent", "u3K-Android-Player")
        return conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
    }

    private class SimpleTextWatcher(private val cb: (String) -> Unit) : android.text.TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { cb(s?.toString().orEmpty()) }
        override fun afterTextChanged(s: android.text.Editable?) {}
    }

    companion object {
        private const val LIST_CONTAINER_ID = 104203
        private const val SEARCH_FIELD_ID = 104204
    }
}
