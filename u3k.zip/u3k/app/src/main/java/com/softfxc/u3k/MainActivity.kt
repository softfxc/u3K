package com.softfxc.u3k

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.MediaStore
import android.text.Editable
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextWatcher
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.core.content.FileProvider
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

private const val REMOTE_MEDIA_JSON = "https://raw.githubusercontent.com/softfxc/u3K/main/media.json"
private const val REMOTE_BASE = "https://raw.githubusercontent.com/softfxc/u3K/main/"
private const val PROFILE_HAND_TEXT = "u3K: 'u' de you/tú, '3' del formato de audio mp3 y 'K' de mil como en redes sociales: tus miles de audios."
private const val GITHUB_REPO_URL = "https://github.com/softfxc/u3K"
private const val TLOU_VIDEO_URL = "https://raw.githubusercontent.com/softfxc/u3K/main/The%20Last%20of%20Us.mp4"
private const val PROFILE_STRANGER_VIDEO_URL = "https://raw.githubusercontent.com/softfxc/u3K/main/stranger%20things.mp4"
private const val PROFILE_ARCANE_VIDEO_URL = "https://raw.githubusercontent.com/softfxc/u3K/main/arcane.mp4"

private const val C_BG = 0xFF090A0D.toInt()
private const val C_CARD = 0xFF17181D.toInt()
private const val C_LINE = 0xFF202127.toInt()
private const val C_TEXT = 0xFFF3F3F4.toInt()
private const val C_MUTED = 0xFF9A9BA1.toInt()
private const val C_CHIP = 0xFF202126.toInt()
private const val C_WHITE = 0xFFFFFFFF.toInt()
private const val C_GREEN = 0xFF1DB954.toInt()
private const val C_LYRIC_BLUE = 0xFF4E86A6.toInt()
private const val C_LYRIC_ORANGE = 0xFFA66A4E.toInt()
private const val C_LYRIC_PURPLE = 0xFF7A5C99.toInt()
private const val C_LYRIC_GREEN = 0xFF55785B.toInt()

private data class Track(
    val id: String,
    val title: String,
    val artist: String,
    val audioUrl: String,
    val durationMs: Long?,
    val coverStyle: String,
    val coverUrl: String?,
    val videoUrl: String?,
    val lyrics: Map<String, String>
)

private data class LyricLine(val timeMs: Long, val text: String)

private enum class FilterMode { ALL, FAVORITES, RECENTS }

class MainActivity : Activity() {
    private lateinit var root: FrameLayout
    private val ui = Handler(Looper.getMainLooper())

    private var tracks: MutableList<Track> = mutableListOf()
    private var filterMode = FilterMode.ALL
    private var searchTerm = ""

    private val favorites = linkedSetOf<String>()
    private val recents = mutableListOf<String>()
    private var totalListens = 0
    private val playCounts = linkedMapOf<String, Int>()
    private val coverCache = linkedMapOf<String, Bitmap>()
    private var currentScreen = "intro"

    private var player: MediaPlayer? = null
    private var isPrepared = false
    private var currentIndex = -1
    private var selectedLanguage = "ES"
    private var lyricLines = listOf<LyricLine>()
    private var lyricLabels = mutableListOf<TextView>()
    private var lastLyricIndex = -1
    private var countedStartForTrackId: String? = null

    private var seekBar: SeekBar? = null
    private var elapsedView: TextView? = null
    private var durationView: TextView? = null
    private var playButton: TextView? = null
    private var titleView: TextView? = null
    private var artistView: TextView? = null
    private var heartButton: TextView? = null
    private var lyricsContainer: LinearLayout? = null
    private var translateButton: TextView? = null

    private val tick = object : Runnable {
        override fun run() {
            updatePlaybackUi()
            ui.postDelayed(this, 250)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window.statusBarColor = C_BG
        window.navigationBarColor = C_BG
        root = FrameLayout(this)
        root.setBackgroundColor(C_WHITE)
        setContentView(root)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
        }
        showIntroThenStart()
    }

    private fun showIntroThenStart() {
        window.statusBarColor = C_WHITE
        window.navigationBarColor = C_WHITE
        root.removeAllViews()
        root.setBackgroundColor(C_WHITE)

        val introText = TextView(this).apply {
            text = "Música, maestro"
            setTextColor(Color.BLACK)
            textSize = 32f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            alpha = 0f
            letterSpacing = 0.02f
        }
        root.addView(introText, FrameLayout.LayoutParams(-1, -1))

        fun startApp() {
            introText.animate().cancel()
            root.removeAllViews()
            root.setBackgroundColor(C_BG)
            window.statusBarColor = C_BG
            window.navigationBarColor = C_BG
            loadPrefs()
            loadMedia()
            ui.post(tick)
        }

        introText.animate()
            .alpha(1f)
            .setDuration(650)
            .withEndAction {
                ui.postDelayed({
                    introText.animate()
                        .alpha(0f)
                        .setDuration(500)
                        .withEndAction {
                            introText.text = "Music, mr"
                            introText.animate()
                                .alpha(1f)
                                .setDuration(650)
                                .withEndAction {
                                    ui.postDelayed({
                                        introText.animate()
                                            .alpha(0f)
                                            .setDuration(500)
                                            .withEndAction { startApp() }
                                            .start()
                                    }, 600)
                                }
                                .start()
                        }
                        .start()
                }, 700)
            }
            .start()
    }

    override fun onDestroy() {
        super.onDestroy()
        ui.removeCallbacks(tick)
        player?.release()
        player = null
    }

    override fun onBackPressed() {
        if (currentScreen != "library") {
            buildLibraryScreen()
        } else {
            super.onBackPressed()
        }
    }

    private fun loadMedia() {
        tracks = mutableListOf()
        buildLibraryScreen()

        Thread {
            try {
                val remoteJson = httpGet(REMOTE_MEDIA_JSON)
                val remoteTracks = parseMediaJson(remoteJson)
                runOnUiThread {
                    tracks = remoteTracks.toMutableList()
                    preloadCovers(tracks)
                    if (currentScreen == "library") buildLibraryScreen()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(
                        this,
                        "No se pudo cargar media.json desde GitHub.",
                        Toast.LENGTH_LONG
                    ).show()
                    if (currentScreen == "library") buildLibraryScreen()
                }
            }
        }.start()
    }

    private fun parseMediaJson(json: String): List<Track> {
        val out = mutableListOf<Track>()
        val arr = JSONObject(json).getJSONArray("tracks")
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val lyricsObj = o.optJSONObject("lyrics")
            val lyrics = linkedMapOf<String, String>()
            if (lyricsObj != null) {
                val keys = lyricsObj.keys()
                while (keys.hasNext()) {
                    val originalKey = keys.next()
                    val k = originalKey.uppercase(Locale.ROOT)
                    lyrics[k] = lyricsObj.getString(originalKey)
                }
            }
            val duration = if (o.has("durationMs") && !o.isNull("durationMs")) o.getLong("durationMs") else null
            val title = o.getString("title")
            val normalizedArtist = ""
            val coverUrl = o.optString("coverUrl", "").takeIf { it.isNotBlank() } ?: defaultCoverUrl(title)
            out += Track(
                id = o.getString("id"),
                title = title,
                artist = normalizedArtist,
                audioUrl = o.getString("audioUrl"),
                durationMs = duration,
                coverStyle = o.optString("coverStyle", defaultCoverStyle(title)),
                coverUrl = coverUrl,
                videoUrl = o.optString("videoUrl", "").takeIf { it.isNotBlank() } ?: if (title.contains("The Last of Us", ignoreCase = true)) TLOU_VIDEO_URL else null,
                lyrics = lyrics
            )
        }
        return out
    }

private fun buildLibraryScreen() {
        currentScreen = "library"
        titleView = null
        artistView = null
        heartButton = null
        seekBar = null
        elapsedView = null
        durationView = null
        playButton = null
        lyricsContainer = null
        translateButton = null
        root.removeAllViews()
        root.setBackgroundColor(C_BG)
        window.statusBarColor = C_BG
        window.navigationBarColor = C_BG

        val main = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), statusBarInset() + dp(10), dp(16), 0)
            setBackgroundColor(C_BG)
        }
        root.addView(main, FrameLayout.LayoutParams(-1, -1))

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        main.addView(header, LinearLayout.LayoutParams(-1, dp(66)))
        header.addView(logoCircleView(dp(42), 18f), LinearLayout.LayoutParams(dp(42), dp(42)).apply { rightMargin = dp(14) })
        header.addView(TextView(this).apply {
            text = "Tu biblioteca"
            setTextColor(C_WHITE)
            textSize = 28f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
            maxLines = 1
        }, LinearLayout.LayoutParams(0, -1, 1f))
        val searchIcon = iconText("⌕", 35f).apply { setOnClickListener { focusSearchField() } }
        header.addView(searchIcon, LinearLayout.LayoutParams(dp(52), -1))

        val search = EditText(this).apply {
            id = SEARCH_FIELD_ID
            hint = "Buscar canciones"
            setHintTextColor(0xFFB3B3B3.toInt())
            setTextColor(C_TEXT)
            textSize = 16f
            singleLineSet()
            background = rounded(C_CARD, dp(18), 0)
            setPadding(dp(18), 0, dp(18), 0)
            setText(searchTerm)
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    searchTerm = s?.toString().orEmpty()
                    refreshSongList()
                }
                override fun afterTextChanged(s: Editable?) {}
            })
        }
        main.addView(search, LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(14) })

        val chips = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        main.addView(chips, LinearLayout.LayoutParams(-1, dp(44)).apply { bottomMargin = dp(10) })
        chips.addView(filterChip("Todas", FilterMode.ALL), LinearLayout.LayoutParams(dp(86), dp(36)).apply { rightMargin = dp(10) })
        chips.addView(filterChip("Favoritas", FilterMode.FAVORITES), LinearLayout.LayoutParams(dp(108), dp(36)).apply { rightMargin = dp(10) })
        chips.addView(filterChip("Recientes", FilterMode.RECENTS), LinearLayout.LayoutParams(dp(110), dp(36)))

        val recentTitle = TextView(this).apply {
            text = when (filterMode) {
                FilterMode.ALL -> "Recientes"
                FilterMode.FAVORITES -> "Favoritas"
                FilterMode.RECENTS -> "Últimas escuchas"
            }
            setTextColor(C_WHITE)
            textSize = 17f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
        }
        main.addView(recentTitle, LinearLayout.LayoutParams(-1, dp(36)))

        val listScroll = ScrollView(this).apply { isFillViewport = false }
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            id = LIST_CONTAINER_ID
        }
        listScroll.addView(list, FrameLayout.LayoutParams(-1, -2))
        main.addView(listScroll, LinearLayout.LayoutParams(-1, 0, 1f))

        buildMiniPlayer(main)
        buildBottomBar(main, "Biblioteca")
        refreshSongList()
    }



private fun refreshSongList() {
        val list = root.findViewById<LinearLayout>(LIST_CONTAINER_ID) ?: return
        list.removeAllViews()
        val q = searchTerm.trim().lowercase(Locale.ROOT)
        val filtered = tracks.filter { track ->
            val byFilter = when (filterMode) {
                FilterMode.ALL -> true
                FilterMode.FAVORITES -> favorites.contains(track.id)
                FilterMode.RECENTS -> recents.contains(track.id)
            }
            val byText = q.isBlank() || track.title.lowercase(Locale.ROOT).contains(q)
            byFilter && byText
        }.let { list ->
            if (filterMode == FilterMode.RECENTS) list.sortedBy { recents.indexOf(it.id).takeIf { pos -> pos >= 0 } ?: Int.MAX_VALUE } else list
        }

        if (filtered.isEmpty()) {
            list.addView(TextView(this).apply {
                text = if (filterMode == FilterMode.FAVORITES) "Aún no hay favoritos." else "No hay canciones para este filtro."
                setTextColor(C_MUTED)
                textSize = 16f
                gravity = Gravity.CENTER
                setPadding(0, dp(32), 0, 0)
            }, LinearLayout.LayoutParams(-1, dp(110)))
            return
        }

        filtered.forEach { track -> list.addView(songRow(track), LinearLayout.LayoutParams(-1, dp(74))) }
    }



private fun songRow(track: Track): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(7), 0, dp(7))
            setBackgroundColor(C_BG)
            setOnClickListener { openPlayer(tracks.indexOfFirst { it.id == track.id }.coerceAtLeast(0)) }
        }

        val cover = coverView(track, dp(58), dp(4), if (track.coverStyle == "logo") 8f else 18f)
        row.addView(cover, LinearLayout.LayoutParams(dp(58), dp(58)).apply { rightMargin = dp(16) })

        val center = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(center, LinearLayout.LayoutParams(0, -1, 1f))

        center.addView(TextView(this).apply {
            text = track.title
            setTextColor(C_TEXT)
            textSize = 17f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            maxLines = 1
        }, LinearLayout.LayoutParams(-1, 0, 1f))

        center.addView(TextView(this).apply {
            text = formatTime(track.durationMs ?: 0L).takeIf { track.durationMs != null } ?: ""
            setTextColor(C_MUTED)
            textSize = 13f
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            maxLines = 1
        }, LinearLayout.LayoutParams(-1, 0, 1f))

        val fav = TextView(this).apply {
            text = if (favorites.contains(track.id)) "GUARDADA" else ""
            setTextColor(C_GREEN)
            textSize = 10f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
        }
        row.addView(fav, LinearLayout.LayoutParams(dp(78), -1))
        return row
    }



private fun buildPlayerScreen() {
        currentScreen = "player"
        val track = tracks.getOrNull(currentIndex) ?: return
        root.removeAllViews()
        root.setBackgroundColor(C_BG)
        window.statusBarColor = C_BG
        window.navigationBarColor = C_BG
        lyricLabels.clear()
        lastLyricIndex = -1

        val scroll = ScrollView(this).apply { isFillViewport = true }
        val main = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(22), statusBarInset() + dp(8), dp(22), navigationBarInset() + dp(18))
        }
        scroll.addView(main, FrameLayout.LayoutParams(-1, -2))
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        main.addView(top, LinearLayout.LayoutParams(-1, dp(48)))
        top.addView(iconText("∨", 30f).apply { setOnClickListener { buildLibraryScreen() } }, LinearLayout.LayoutParams(dp(48), -1))
        top.addView(TextView(this).apply {
            text = "Ahora reproduciendo"
            setTextColor(C_TEXT)
            textSize = 18f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(0, -1, 1f))
        top.addView(Space(this), LinearLayout.LayoutParams(dp(48), -1))

        val coverSize = min(resources.displayMetrics.widthPixels - dp(60), dp(332))
        val cover = nowPlayingVisual(track, coverSize)
        main.addView(cover, LinearLayout.LayoutParams(coverSize, coverSize).apply { topMargin = dp(18); bottomMargin = dp(28) })

        val titleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        main.addView(titleRow, LinearLayout.LayoutParams(-1, dp(72)))
        titleView = TextView(this).apply {
            text = track.title
            setTextColor(C_TEXT)
            textSize = 26f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            maxLines = 2
            gravity = Gravity.CENTER_VERTICAL
        }
        titleRow.addView(titleView, LinearLayout.LayoutParams(0, -1, 1f))
        heartButton = TextView(this).apply {
            text = if (favorites.contains(track.id)) "Guardada" else "Guardar"
            textSize = 13f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            gravity = Gravity.CENTER
            setTextColor(if (favorites.contains(track.id)) C_BG else C_TEXT)
            background = rounded(if (favorites.contains(track.id)) C_GREEN else 0x00000000, dp(18), if (favorites.contains(track.id)) 0 else C_LINE)
            setOnClickListener {
                toggleFavorite(track.id)
                text = if (favorites.contains(track.id)) "Guardada" else "Guardar"
                setTextColor(if (favorites.contains(track.id)) C_BG else C_TEXT)
                background = rounded(if (favorites.contains(track.id)) C_GREEN else 0x00000000, dp(18), if (favorites.contains(track.id)) 0 else C_LINE)
            }
        }
        titleRow.addView(heartButton, LinearLayout.LayoutParams(dp(96), dp(38)))

        seekBar = SeekBar(this).apply {
            max = (track.durationMs ?: 1L).toInt()
            progress = 0
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser && isPrepared) player?.seekTo(progress)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        main.addView(seekBar, LinearLayout.LayoutParams(-1, dp(32)))

        val times = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        elapsedView = smallMuted("0:00")
        durationView = smallMuted(formatTime(track.durationMs ?: 0L).takeIf { track.durationMs != null } ?: "--:--").apply { gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL }
        times.addView(elapsedView, LinearLayout.LayoutParams(0, dp(22), 1f))
        times.addView(durationView, LinearLayout.LayoutParams(0, dp(22), 1f))
        main.addView(times, LinearLayout.LayoutParams(-1, dp(25)))

        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        main.addView(controls, LinearLayout.LayoutParams(-1, dp(86)).apply { topMargin = dp(4) })
        controls.addView(iconText("⏮", 36f).apply { setOnClickListener { previousTrack() } }, LinearLayout.LayoutParams(0, -1, 1f))
        playButton = TextView(this).apply {
            text = "▶"
            textSize = 32f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            gravity = Gravity.CENTER
            setTextColor(C_BG)
            background = rounded(C_WHITE, dp(38), 0)
            setOnClickListener { togglePlayback() }
        }
        controls.addView(playButton, LinearLayout.LayoutParams(dp(76), dp(76)))
        controls.addView(iconText("⏭", 36f).apply { setOnClickListener { nextTrack() } }, LinearLayout.LayoutParams(0, -1, 1f))

        translateButton = TextView(this).apply {
            text = "Traducir"
            setTextColor(C_TEXT)
            textSize = 14f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            gravity = Gravity.CENTER
            background = rounded(0x00000000, dp(18), C_LINE)
            visibility = if (track.lyrics.size > 1) View.VISIBLE else View.GONE
            setOnClickListener { toggleLyricsLanguage() }
        }
        main.addView(translateButton, LinearLayout.LayoutParams(dp(132), dp(42)).apply { topMargin = dp(2); bottomMargin = dp(10) })

        val shareButton = TextView(this).apply {
            text = "Compartir letra"
            setTextColor(C_TEXT)
            textSize = 14f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            gravity = Gravity.CENTER
            background = rounded(0x00000000, dp(18), C_LINE)
            setOnClickListener { showShareLyricsOptions() }
        }
        main.addView(shareButton, LinearLayout.LayoutParams(dp(178), dp(42)).apply { bottomMargin = dp(18) })

        lyricsContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.LEFT
            setPadding(dp(22), dp(22), dp(22), dp(26))
            background = rounded(lyricCardColor(track), dp(18), 0)
        }
        main.addView(lyricsContainer, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(24) })
        renderLyricsLoading()
    }



    private fun openPlayer(index: Int) {
        if (tracks.isEmpty()) return
        currentIndex = index.coerceIn(0, tracks.lastIndex)
        addRecent(tracks[currentIndex].id)
        buildPlayerScreen()
        prepareCurrentTrack(true)
    }

private fun prepareCurrentTrack(autoplay: Boolean) {
        val track = tracks.getOrNull(currentIndex) ?: return
        player?.release()
        player = null
        isPrepared = false
        countedStartForTrackId = null
        playButton?.text = "▶"
        lyricLines = emptyList()
        selectedLanguage = when {
            track.lyrics.containsKey("ES") -> "ES"
            track.lyrics.containsKey("EN") -> "EN"
            track.lyrics.isNotEmpty() -> track.lyrics.keys.first()
            else -> "ES"
        }
        loadLyrics(track)
        startPlaybackNotification(track, false)

        val mp = MediaPlayer()
        try { mp.setWakeMode(applicationContext, PowerManager.PARTIAL_WAKE_LOCK) } catch (_: Exception) {}
        player = mp
        try {
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .build()
            )
            mp.setDataSource(this, Uri.parse(track.audioUrl))
            mp.setOnPreparedListener {
                isPrepared = true
                seekBar?.max = max(1, it.duration)
                durationView?.text = formatTime(it.duration.toLong())
                if (autoplay) {
                    registerListen(track.id)
                    it.start()
                    playButton?.text = "Ⅱ"
                    startPlaybackNotification(track, true)
                } else {
                    playButton?.text = "▶"
                    startPlaybackNotification(track, false)
                }
            }
            mp.setOnCompletionListener { nextTrack() }
            mp.setOnErrorListener { _, what, extra ->
                Toast.makeText(this, "No se pudo reproducir. Código $what/$extra", Toast.LENGTH_LONG).show()
                playButton?.text = "▶"
                startPlaybackNotification(track, false)
                true
            }
            mp.prepareAsync()
        } catch (e: Exception) {
            Toast.makeText(this, "Error al abrir el MP3: ${e.message}", Toast.LENGTH_LONG).show()
            playButton?.text = "▶"
            startPlaybackNotification(track, false)
        }
    }



private fun togglePlayback() {
        val mp = player ?: return
        val track = tracks.getOrNull(currentIndex) ?: return
        if (!isPrepared) return
        if (mp.isPlaying) {
            mp.pause()
            playButton?.text = "▶"
            startPlaybackNotification(track, false)
        } else {
            registerListen(track.id)
            mp.start()
            playButton?.text = "Ⅱ"
            startPlaybackNotification(track, true)
        }
    }



    private fun nextTrack() {
        if (tracks.isEmpty()) return
        currentIndex = if (currentIndex < 0) 0 else (currentIndex + 1) % tracks.size
        addRecent(tracks[currentIndex].id)
        buildPlayerScreen()
        prepareCurrentTrack(true)
    }

    private fun previousTrack() {
        if (tracks.isEmpty()) return
        currentIndex = if (currentIndex <= 0) tracks.lastIndex else currentIndex - 1
        addRecent(tracks[currentIndex].id)
        buildPlayerScreen()
        prepareCurrentTrack(true)
    }

    private fun updatePlaybackUi() {
        val mp = player ?: return
        if (!isPrepared) return
        try {
            val pos = mp.currentPosition
            val dur = max(1, mp.duration)
            seekBar?.max = dur
            if (seekBar?.isPressed != true) seekBar?.progress = min(pos, dur)
            elapsedView?.text = formatTime(pos.toLong())
            durationView?.text = formatTime(dur.toLong())
            playButton?.text = if (mp.isPlaying) "Ⅱ" else "▶"
            updateLyricHighlight(pos.toLong())
        } catch (_: Exception) {}
    }

private fun loadLyrics(track: Track) {
        val url = track.lyrics[selectedLanguage]
        if (url == null) {
            renderLyricsMessage("Sin letra disponible")
            return
        }
        renderLyricsLoading()
        Thread {
            try {
                val text = httpGet(url)
                val parsed = parseLrc(text)
                runOnUiThread {
                    lyricLines = parsed
                    if (parsed.isEmpty()) renderLyricsMessage("Sin letra disponible") else renderLyrics()
                }
            } catch (_: Exception) {
                runOnUiThread { renderLyricsMessage("Sin letra disponible") }
            }
        }.start()
    }



private fun toggleLyricsLanguage() {
        val track = tracks.getOrNull(currentIndex) ?: return
        if (track.lyrics.size <= 1) return
        val keys = track.lyrics.keys.sorted()
        val currentPos = keys.indexOf(selectedLanguage).takeIf { it >= 0 } ?: 0
        selectedLanguage = keys[(currentPos + 1) % keys.size]
        loadLyrics(track)
    }



private fun renderLyricsLoading() {
        lyricsContainer?.removeAllViews()
        lyricLabels.clear()
    }

private fun renderLyricsMessage(message: String) {
        lyricsContainer?.removeAllViews()
        lyricLabels.clear()
        lyricsContainer?.addView(TextView(this).apply {
            text = message
            setTextColor(0xDFFFFFFF.toInt())
            textSize = 20f
            gravity = Gravity.LEFT
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setPadding(0, dp(4), 0, dp(4))
        }, LinearLayout.LayoutParams(-1, -2))
    }



private fun renderLyrics() {
        val box = lyricsContainer ?: return
        box.removeAllViews()
        lyricLabels.clear()
        lyricLines.forEach { line ->
            val tv = TextView(this).apply {
                text = line.text
                setTextColor(0xBFFFFFFF.toInt())
                alpha = 0.72f
                textSize = 21f
                gravity = Gravity.LEFT
                typeface = Typeface.create("sans-serif", Typeface.BOLD)
                includeFontPadding = false
                setLineSpacing(dp(3).toFloat(), 1.0f)
                setPadding(0, dp(9), 0, dp(9))
            }
            lyricLabels += tv
            box.addView(tv, LinearLayout.LayoutParams(-1, -2))
        }
    }



private fun updateLyricHighlight(positionMs: Long) {
        if (lyricLines.isEmpty() || lyricLabels.isEmpty()) return
        var idx = 0
        for (i in lyricLines.indices) {
            if (positionMs >= lyricLines[i].timeMs) idx = i else break
        }
        if (idx == lastLyricIndex) return
        lastLyricIndex = idx
        lyricLabels.forEachIndexed { i, tv ->
            val distance = kotlin.math.abs(i - idx)
            when (distance) {
                0 -> {
                    tv.setTextColor(C_WHITE)
                    tv.alpha = 1f
                    tv.textSize = 28f
                    tv.typeface = Typeface.create("sans-serif", Typeface.BOLD)
                }
                1 -> {
                    tv.setTextColor(0xE6FFFFFF.toInt())
                    tv.alpha = 0.82f
                    tv.textSize = 22f
                    tv.typeface = Typeface.create("sans-serif", Typeface.BOLD)
                }
                else -> {
                    tv.setTextColor(0xB3FFFFFF.toInt())
                    tv.alpha = 0.50f
                    tv.textSize = 20f
                    tv.typeface = Typeface.create("sans-serif", Typeface.BOLD)
                }
            }
        }
    }



    private fun parseLrc(text: String): List<LyricLine> {
        val out = mutableListOf<LyricLine>()
        val rx = Regex("\\[(\\d{1,2}):(\\d{2})(?:\\.(\\d{1,3}))?]")
        text.lineSequence().forEach { raw ->
            val matches = rx.findAll(raw).toList()
            if (matches.isEmpty()) return@forEach
            val lyricText = raw.substringAfterLast("]").trim()
            if (lyricText.isBlank()) return@forEach
            matches.forEach { m ->
                val min = m.groupValues[1].toLong()
                val sec = m.groupValues[2].toLong()
                val frac = m.groupValues.getOrNull(3).orEmpty()
                val ms = when (frac.length) {
                    0 -> 0L
                    1 -> frac.toLong() * 100
                    2 -> frac.toLong() * 10
                    else -> frac.take(3).toLong()
                }
                out += LyricLine(min * 60_000 + sec * 1_000 + ms, lyricText)
            }
        }
        return out.sortedBy { it.timeMs }
    }

private fun filterChip(label: String, mode: FilterMode): TextView = TextView(this).apply {
        text = label
        gravity = Gravity.CENTER
        textSize = 14f
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
        setTextColor(if (filterMode == mode) C_BG else C_TEXT)
        background = rounded(if (filterMode == mode) C_WHITE else C_CHIP, dp(18), 0)
        setOnClickListener {
            filterMode = mode
            buildLibraryScreen()
        }
    }



    private fun smallTag(label: String): TextView = TextView(this).apply {
        text = label
        setTextColor(C_TEXT)
        textSize = 11f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        background = rounded(C_CHIP, dp(5), 0)
    }

    private fun smallMuted(value: String): TextView = TextView(this).apply {
        text = value
        setTextColor(C_MUTED)
        textSize = 14f
        gravity = Gravity.LEFT or Gravity.CENTER_VERTICAL
    }

private fun iconText(value: String, size: Float): TextView = TextView(this).apply {
        text = value
        textSize = size
        gravity = Gravity.CENTER
        setTextColor(C_TEXT)
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
        includeFontPadding = false
    }



private fun buildBottomBar(main: LinearLayout, selected: String) {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(5), 0, dp(8))
            setBackgroundColor(0xF207080B.toInt())
        }
        val search = navItem("⌕", "Buscar", selected == "Buscar").apply { setOnClickListener { buildLibraryScreen(); ui.postDelayed({ focusSearchField() }, 100) } }
        val lib = navItem("▦", "Biblioteca", selected == "Biblioteca").apply { setOnClickListener { buildLibraryScreen() } }
        val profile = navItem("○", "Perfil", selected == "Perfil").apply { setOnClickListener { buildProfileScreen() } }
        bar.addView(search, LinearLayout.LayoutParams(0, -1, 1f))
        bar.addView(lib, LinearLayout.LayoutParams(0, -1, 1f))
        bar.addView(profile, LinearLayout.LayoutParams(0, -1, 1f))
        main.addView(bar, LinearLayout.LayoutParams(-1, dp(72) + navigationBarInset()))
    }



private fun navItem(icon: String, label: String, selected: Boolean): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        val iconView = TextView(this@MainActivity).apply {
            text = icon
            textSize = 27f
            gravity = Gravity.CENTER
            setTextColor(if (selected) C_WHITE else C_MUTED)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        val textView = TextView(this@MainActivity).apply {
            text = label
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(if (selected) C_WHITE else C_MUTED)
            typeface = Typeface.create("sans-serif", if (selected) Typeface.BOLD else Typeface.NORMAL)
        }
        addView(iconView, LinearLayout.LayoutParams(-1, 0, 1f))
        addView(textView, LinearLayout.LayoutParams(-1, 0, 1f))
    }



    private fun toggleFavorite(id: String) {
        if (favorites.contains(id)) favorites.remove(id) else favorites.add(id)
        savePrefs()
    }

    private fun addRecent(id: String) {
        recents.remove(id)
        recents.add(0, id)
        while (recents.size > 30) recents.removeAt(recents.lastIndex)
        savePrefs()
    }

    private fun loadPrefs() {
        val sp = getSharedPreferences("u3k", MODE_PRIVATE)
        favorites.clear()
        favorites.addAll(sp.getString("favorites", "").orEmpty().split('|').filter { it.isNotBlank() })
        recents.clear()
        recents.addAll(sp.getString("recents", "").orEmpty().split('|').filter { it.isNotBlank() })
        totalListens = sp.getInt("totalListens", 0)
        playCounts.clear()
        sp.getString("playCounts", "").orEmpty().split('|').forEach { item ->
            val parts = item.split('=', limit = 2)
            val id = parts.getOrNull(0).orEmpty()
            val count = parts.getOrNull(1)?.toIntOrNull() ?: 0
            if (id.isNotBlank() && count > 0) playCounts[id] = count
        }
    }

    private fun savePrefs() {
        getSharedPreferences("u3k", MODE_PRIVATE).edit()
            .putString("favorites", favorites.joinToString("|"))
            .putString("recents", recents.joinToString("|"))
            .putInt("totalListens", totalListens)
            .putString("playCounts", playCounts.entries.joinToString("|") { "${it.key}=${it.value}" })
            .apply()
    }

    private fun registerListen(id: String) {
        if (countedStartForTrackId == id) return
        countedStartForTrackId = id
        totalListens += 1
        playCounts[id] = (playCounts[id] ?: 0) + 1
        savePrefs()
    }

private fun buildProfileScreen() {
        currentScreen = "profile"
        titleView = null
        artistView = null
        heartButton = null
        seekBar = null
        elapsedView = null
        durationView = null
        playButton = null
        lyricsContainer = null
        translateButton = null
        root.removeAllViews()
        root.setBackgroundColor(C_BG)

        val main = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), statusBarInset() + dp(10), dp(18), 0)
            setBackgroundColor(C_BG)
        }
        root.addView(main, FrameLayout.LayoutParams(-1, -1))

        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        main.addView(header, LinearLayout.LayoutParams(-1, dp(62)))
        header.addView(logoCircleView(dp(42), 18f), LinearLayout.LayoutParams(dp(42), dp(42)).apply { rightMargin = dp(14) })
        header.addView(TextView(this).apply {
            text = "Perfil"
            setTextColor(C_TEXT)
            textSize = 30f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
        }, LinearLayout.LayoutParams(0, -1, 1f))

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(16))
        }
        scroll.addView(content, FrameLayout.LayoutParams(-1, -2))
        main.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val stats = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        stats.addView(statCard("Escuchas", totalListens.toString()), LinearLayout.LayoutParams(0, dp(92), 1f).apply { rightMargin = dp(8) })
        stats.addView(statCard("Favoritas", favorites.size.toString()), LinearLayout.LayoutParams(0, dp(92), 1f).apply { leftMargin = dp(8) })
        content.addView(stats, LinearLayout.LayoutParams(-1, dp(96)).apply { bottomMargin = dp(16) })

        content.addView(TextView(this).apply {
            text = PROFILE_HAND_TEXT
            setTextColor(C_TEXT)
            textSize = 22f
            typeface = Typeface.create("casual", Typeface.NORMAL)
            setLineSpacing(dp(4).toFloat(), 1.05f)
            gravity = Gravity.CENTER
            background = rounded(C_CARD, dp(22), C_LINE)
            setPadding(dp(22), dp(24), dp(22), dp(24))
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(22) })

        content.addView(TextView(this).apply {
            text = "Vídeos"
            setTextColor(C_TEXT)
            textSize = 20f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }, LinearLayout.LayoutParams(-1, dp(38)))
        content.addView(profileVideoCard("Stranger Things", PROFILE_STRANGER_VIDEO_URL), LinearLayout.LayoutParams(-1, dp(220)).apply { bottomMargin = dp(14) })
        content.addView(profileVideoCard("Arcane", PROFILE_ARCANE_VIDEO_URL), LinearLayout.LayoutParams(-1, dp(220)).apply { bottomMargin = dp(22) })

        content.addView(TextView(this).apply {
            text = "Favoritas"
            setTextColor(C_TEXT)
            textSize = 20f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }, LinearLayout.LayoutParams(-1, dp(38)))

        val favTracks = favorites.mapNotNull { id -> tracks.firstOrNull { it.id == id } }
        if (favTracks.isEmpty()) {
            content.addView(TextView(this).apply {
                text = "Cuando guardes canciones, aparecerán aquí."
                setTextColor(C_MUTED)
                textSize = 15f
                gravity = Gravity.CENTER
                background = rounded(C_CARD, dp(16), C_LINE)
                setPadding(dp(18), dp(22), dp(18), dp(22))
            }, LinearLayout.LayoutParams(-1, -2))
        } else {
            favTracks.forEach { track -> content.addView(songRow(track), LinearLayout.LayoutParams(-1, dp(74))) }
        }

        buildMiniPlayer(main)
        buildBottomBar(main, "Perfil")
    }



    private fun statCard(label: String, value: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        background = rounded(C_CARD, dp(18), C_LINE)
        addView(TextView(this@MainActivity).apply {
            text = value
            setTextColor(C_WHITE)
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, 0, 1f))
        addView(TextView(this@MainActivity).apply {
            text = label
            setTextColor(C_MUTED)
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, 0, 1f))
    }

private fun showShareLyricsOptions() {
        val track = tracks.getOrNull(currentIndex)
        if (track == null || lyricLines.isEmpty()) {
            Toast.makeText(this, "No hay letra cargada para compartir.", Toast.LENGTH_SHORT).show()
            return
        }
        val idx = lastLyricIndex.takeIf { it in lyricLines.indices } ?: 0
        val variants = arrayOf(
            shareTextFrom(idx, 1),
            shareTextFrom(idx, 2),
            shareTextFrom(max(0, idx - 1), 4)
        )
        val colors = intArrayOf(C_LYRIC_BLUE, C_LYRIC_ORANGE, C_LYRIC_PURPLE, C_LYRIC_GREEN)
        var selectedText = variants.first()
        var selectedColor = colors.first()

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(8), dp(18), dp(4))
        }
        container.addView(TextView(this).apply {
            text = "Fragmento"
            setTextColor(Color.BLACK)
            textSize = 15f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }, LinearLayout.LayoutParams(-1, dp(32)))
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, variants.map { it.replace('\n', ' ').take(70) })
        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { selectedText = variants[position] }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }
        container.addView(spinner, LinearLayout.LayoutParams(-1, dp(48)))

        container.addView(TextView(this).apply {
            text = "Color"
            setTextColor(Color.BLACK)
            textSize = 15f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }, LinearLayout.LayoutParams(-1, dp(32)))
        val colorRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        colors.forEach { c ->
            colorRow.addView(TextView(this).apply {
                text = ""
                background = rounded(c, dp(18), 0)
                setOnClickListener { selectedColor = c; Toast.makeText(this@MainActivity, "Color seleccionado", Toast.LENGTH_SHORT).show() }
            }, LinearLayout.LayoutParams(dp(42), dp(42)).apply { rightMargin = dp(10) })
        }
        container.addView(colorRow, LinearLayout.LayoutParams(-1, dp(52)))

        AlertDialog.Builder(this)
            .setTitle("Compartir letra")
            .setView(container)
            .setPositiveButton("Compartir") { _, _ -> shareCurrentLyric("generic", selectedText, selectedColor) }
            .setNegativeButton("Galería") { _, _ -> shareCurrentLyric("gallery", selectedText, selectedColor) }
            .setNeutralButton("Cancelar", null)
            .show()
    }



private fun shareCurrentLyric(target: String, selectedText: String, bgColor: Int) {
        val track = tracks.getOrNull(currentIndex)
        if (track == null || selectedText.isBlank()) {
            Toast.makeText(this, "No hay letra cargada para compartir.", Toast.LENGTH_SHORT).show()
            return
        }
        val bitmap = makeLyricShareBitmap(track, selectedText, bgColor)
        if (target == "gallery") {
            val uri = saveBitmapToGallery(bitmap, track)
            Toast.makeText(this, if (uri != null) "Imagen guardada en la galería." else "No se pudo guardar la imagen.", Toast.LENGTH_LONG).show()
            return
        }
        val uri = saveBitmapToCache(bitmap, track)
        if (uri == null) {
            Toast.makeText(this, "No se pudo preparar la imagen.", Toast.LENGTH_LONG).show()
            return
        }
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, "u3K · ${track.title}\n$GITHUB_REPO_URL")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Compartir letra"))
    }



private fun makeLyricShareBitmap(track: Track, selectedText: String, bgColor: Int): Bitmap {
        val w = 1080
        val h = 1920
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val darker = darken(bgColor, 0.62f)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), bgColor, darker, Shader.TileMode.CLAMP)
        }
        canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), paint)

        val logoPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 58f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            alpha = 230
        }
        canvas.drawText("u3K", 80f, 128f, logoPaint)

        val lyricPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 82f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        val layout = StaticLayout.Builder.obtain(selectedText, 0, selectedText.length, lyricPaint, w - 150)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setLineSpacing(10f, 1.0f)
            .build()
        canvas.save()
        canvas.translate(75f, 520f)
        layout.draw(canvas)
        canvas.restore()

        val metaPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 44f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            alpha = 235
        }
        val subPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 34f
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            alpha = 190
        }
        drawWrappedText(canvas, track.title, metaPaint, 76f, 1560f, w - 152, Layout.Alignment.ALIGN_NORMAL)
        drawWrappedText(canvas, GITHUB_REPO_URL, subPaint, 76f, 1690f, w - 152, Layout.Alignment.ALIGN_NORMAL)
        return bitmap
    }



    private fun drawWrappedText(canvas: Canvas, text: String, paint: TextPaint, x: Float, y: Float, width: Int, alignment: Layout.Alignment) {
        val layout = StaticLayout.Builder.obtain(text, 0, text.length, paint, width)
            .setAlignment(alignment)
            .setLineSpacing(4f, 1.0f)
            .setMaxLines(2)
            .build()
        canvas.save()
        canvas.translate(x, y)
        layout.draw(canvas)
        canvas.restore()
    }

    private fun saveBitmapToCache(bitmap: Bitmap, track: Track): Uri? = try {
        val dir = File(cacheDir, "shared").apply { mkdirs() }
        val file = File(dir, "u3k_${safeFilePart(track.id)}_${System.currentTimeMillis()}.png")
        FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
    } catch (_: Exception) {
        null
    }

    private fun saveBitmapToGallery(bitmap: Bitmap, track: Track): Uri? = try {
        val filename = "u3K_${safeFilePart(track.title)}_${System.currentTimeMillis()}.png"
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, filename)
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/u3K")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        contentResolver.openOutputStream(uri)?.use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)
        }
        uri
    } catch (_: Exception) {
        null
    }



    private fun nowPlayingVisual(track: Track, sizePx: Int): FrameLayout {
        val frame = FrameLayout(this)
        val cover = coverView(track, sizePx, dp(8), if (track.coverStyle == "logo") 20f else 42f)
        frame.addView(cover, FrameLayout.LayoutParams(sizePx, sizePx))
        val videoUrl = track.videoUrl
        if (videoUrl != null && track.title.contains("The Last of Us", ignoreCase = true)) {
            val video = VideoView(this).apply {
                visibility = View.GONE
                setVideoURI(Uri.parse(videoUrl))
                setOnPreparedListener { mp ->
                    mp.isLooping = true
                    mp.setVolume(0f, 0f)
                    if (visibility == View.VISIBLE) start()
                }
                setOnErrorListener { _, _, _ ->
                    visibility = View.GONE
                    Toast.makeText(this@MainActivity, "No se pudo cargar el vídeo The Last of Us.", Toast.LENGTH_SHORT).show()
                    true
                }
            }
            frame.addView(video, FrameLayout.LayoutParams(sizePx, sizePx))
            val hint = TextView(this).apply {
                text = "Toca para alternar portada/vídeo"
                setTextColor(C_WHITE)
                textSize = 12f
                typeface = Typeface.create("sans-serif", Typeface.BOLD)
                gravity = Gravity.CENTER
                setPadding(dp(8), 0, dp(8), 0)
                background = rounded(0x66000000, dp(12), 0)
            }
            frame.addView(hint, FrameLayout.LayoutParams(-2, dp(28), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(10) })
            frame.setOnClickListener {
                if (video.visibility == View.VISIBLE) {
                    video.pause()
                    video.visibility = View.GONE
                    cover.visibility = View.VISIBLE
                    hint.text = "Toca para ver vídeo"
                } else {
                    cover.visibility = View.GONE
                    video.visibility = View.VISIBLE
                    video.start()
                    hint.text = "Toca para ver portada"
                }
            }
        }
        return frame
    }

    private fun profileVideoCard(title: String, url: String): LinearLayout {
        var muted = true
        var mediaPlayer: MediaPlayer? = null
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(C_CARD, dp(16), C_LINE)
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        val titleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        titleRow.addView(TextView(this).apply {
            text = title
            setTextColor(C_WHITE)
            textSize = 16f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            maxLines = 1
        }, LinearLayout.LayoutParams(0, dp(34), 1f))
        val soundButton = TextView(this).apply {
            text = "Activar audio"
            setTextColor(C_GREEN)
            textSize = 12f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            gravity = Gravity.CENTER
            background = rounded(0x00000000, dp(14), C_LINE)
        }
        titleRow.addView(soundButton, LinearLayout.LayoutParams(dp(116), dp(32)))
        card.addView(titleRow, LinearLayout.LayoutParams(-1, dp(36)))
        val video = VideoView(this).apply {
            setVideoURI(Uri.parse(url))
            setOnPreparedListener { mp ->
                mediaPlayer = mp
                mp.isLooping = true
                mp.setVolume(0f, 0f)
                start()
            }
            setOnErrorListener { _, _, _ ->
                Toast.makeText(this@MainActivity, "No se pudo cargar $title desde GitHub.", Toast.LENGTH_SHORT).show()
                true
            }
        }
        card.addView(video, LinearLayout.LayoutParams(-1, 0, 1f))
        val toggle = View.OnClickListener {
            muted = !muted
            mediaPlayer?.setVolume(if (muted) 0f else 1f, if (muted) 0f else 1f)
            soundButton.text = if (muted) "Activar audio" else "Silenciar"
            soundButton.setTextColor(if (muted) C_GREEN else C_WHITE)
            if (!video.isPlaying) video.start()
        }
        soundButton.setOnClickListener(toggle)
        video.setOnClickListener(toggle)
        return card
    }

    private fun buildMiniPlayer(main: LinearLayout) {
        val track = tracks.getOrNull(currentIndex) ?: return
        val mini = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
            background = rounded(0xFF123B4A.toInt(), dp(9), 0)
            setOnClickListener { buildPlayerScreen() }
        }
        mini.addView(coverView(track, dp(48), dp(5), 8f), LinearLayout.LayoutParams(dp(48), dp(48)).apply { rightMargin = dp(10) })
        mini.addView(TextView(this).apply {
            text = track.title
            setTextColor(C_WHITE)
            textSize = 15f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            maxLines = 1
        }, LinearLayout.LayoutParams(0, -1, 1f))
        mini.addView(TextView(this).apply {
            text = if (favorites.contains(track.id)) "✓" else "+"
            setTextColor(if (favorites.contains(track.id)) C_GREEN else C_WHITE)
            textSize = 26f
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setOnClickListener { toggleFavorite(track.id); buildLibraryScreen() }
        }, LinearLayout.LayoutParams(dp(46), -1))
        mini.addView(TextView(this).apply {
            text = if (player?.isPlaying == true) "Ⅱ" else "▶"
            setTextColor(C_WHITE)
            textSize = 25f
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setOnClickListener { togglePlayback(); buildLibraryScreen() }
        }, LinearLayout.LayoutParams(dp(46), -1))
        main.addView(mini, LinearLayout.LayoutParams(-1, dp(62)).apply { topMargin = dp(4); bottomMargin = dp(2) })
    }

    private fun focusSearchField() {
        val search = root.findViewById<EditText>(SEARCH_FIELD_ID) ?: return
        search.requestFocus()
        (getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager)?.showSoftInput(search, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun logoCircleView(sizePx: Int, textSizeSp: Float): TextView = TextView(this).apply {
        text = "u3K"
        setTextColor(0xFFFFD66B.toInt())
        textSize = textSizeSp
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
        gravity = Gravity.CENTER
        background = rounded(0xFF1B78A6.toInt(), sizePx / 2, 0)
        includeFontPadding = false
    }

    private fun statusBarInset(): Int {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else 0
    }

    private fun navigationBarInset(): Int {
        val id = resources.getIdentifier("navigation_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else 0
    }

    private fun lyricCardColor(track: Track): Int {
        val colors = intArrayOf(C_LYRIC_BLUE, C_LYRIC_ORANGE, C_LYRIC_PURPLE, C_LYRIC_GREEN)
        return colors[kotlin.math.abs(track.id.hashCode()) % colors.size]
    }

    private fun darken(color: Int, factor: Float): Int {
        val a = Color.alpha(color)
        val r = (Color.red(color) * factor).toInt().coerceIn(0, 255)
        val g = (Color.green(color) * factor).toInt().coerceIn(0, 255)
        val b = (Color.blue(color) * factor).toInt().coerceIn(0, 255)
        return Color.argb(a, r, g, b)
    }

    private fun shareTextFrom(start: Int, count: Int): String {
        if (lyricLines.isEmpty()) return ""
        val from = start.coerceIn(0, lyricLines.lastIndex)
        val to = min(lyricLines.size, from + count)
        return lyricLines.subList(from, to).joinToString("\n") { it.text }
    }

    private fun startPlaybackNotification(track: Track, playing: Boolean) {
        try {
            val intent = Intent(this, PlaybackNotificationService::class.java).apply {
                action = "SHOW"
                putExtra("title", track.title)
                putExtra("playing", playing)
            }
            ContextCompat.startForegroundService(this, intent)
        } catch (_: Exception) {}
    }

    private fun preloadCovers(list: List<Track>) {
        val urls = list.mapNotNull { it.coverUrl }.distinct().filter { !coverCache.containsKey(it) }
        if (urls.isEmpty()) return
        Thread {
            urls.forEach { url ->
                try {
                    val conn = URL(url).openConnection() as HttpURLConnection
                    conn.connectTimeout = 8000
                    conn.readTimeout = 8000
                    conn.setRequestProperty("User-Agent", "u3K-Android-Player")
                    val bitmap = conn.inputStream.use { BitmapFactory.decodeStream(it) }
                    if (bitmap != null) coverCache[url] = bitmap
                } catch (_: Exception) {}
            }
        }.start()
    }

private fun coverView(track: Track, sizePx: Int, radiusPx: Int, labelSize: Float): FrameLayout {
        val frame = FrameLayout(this).apply { background = coverDrawable(track.coverStyle, radiusPx) }
        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = 0f
        }
        val label = TextView(this).apply {
            text = coverLabel(track)
            gravity = Gravity.CENTER
            setTextColor(C_WHITE)
            textSize = labelSize
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            alpha = 0.65f
        }
        frame.addView(image, FrameLayout.LayoutParams(sizePx, sizePx))
        frame.addView(label, FrameLayout.LayoutParams(sizePx, sizePx))
        track.coverUrl?.let { loadCoverImage(it, image, label) }
        return frame
    }



    private fun loadCoverImage(url: String, imageView: ImageView, fallbackLabel: TextView) {
        coverCache[url]?.let {
            imageView.setImageBitmap(it)
            imageView.alpha = 1f
            fallbackLabel.visibility = View.GONE
            return
        }
        Thread {
            try {
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 10000
                conn.readTimeout = 10000
                conn.setRequestProperty("User-Agent", "u3K-Android-Player")
                val bitmap = conn.inputStream.use { BitmapFactory.decodeStream(it) }
                if (bitmap != null) {
                    coverCache[url] = bitmap
                    runOnUiThread {
                        imageView.setImageBitmap(bitmap)
                        imageView.animate().alpha(1f).setDuration(250).start()
                        fallbackLabel.visibility = View.GONE
                    }
                }
            } catch (_: Exception) {}
        }.start()
    }

    private fun defaultCoverUrl(title: String): String {
        val file = when {
            title.contains("The Last of Us", ignoreCase = true) -> "cover2.jpg"
            title.contains("-") || title.contains("–") -> "cover3.jpg"
            else -> "cover1.jpg"
        }
        return REMOTE_BASE + file
    }

    private fun defaultCoverStyle(title: String): String = when {
        title.contains("The Last of Us", ignoreCase = true) -> "logo"
        title.contains("-") || title.contains("–") -> "red"
        else -> "sunset"
    }

    private fun safeFilePart(value: String): String = value.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9]+"), "_").trim('_').take(50).ifBlank { "letra" }

    private fun rounded(fill: Int, radius: Int, stroke: Int): GradientDrawable = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = radius.toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    private fun coverDrawable(style: String, radius: Int): GradientDrawable {
        val colors = when (style) {
            "ocean" -> intArrayOf(0xFF0F3A4D.toInt(), 0xFF071018.toInt(), 0xFF0D2530.toInt())
            "sunset" -> intArrayOf(0xFFECB37B.toInt(), 0xFF3A241B.toInt(), 0xFF0B0D10.toInt())
            "red" -> intArrayOf(0xFFE73370.toInt(), 0xFF262A47.toInt(), 0xFF111318.toInt())
            "group" -> intArrayOf(0xFFACB6C5.toInt(), 0xFF6F4D32.toInt(), 0xFF14161B.toInt())
            "logo" -> intArrayOf(0xFF0A0A0C.toInt(), 0xFF14161B.toInt(), 0xFF050506.toInt())
            else -> intArrayOf(0xFF262931.toInt(), 0xFF111318.toInt(), 0xFF06070A.toInt())
        }
        return GradientDrawable(GradientDrawable.Orientation.TL_BR, colors).apply { cornerRadius = radius.toFloat() }
    }

private fun coverLabel(track: Track): String = when (track.coverStyle) {
        "logo" -> "THE\nLAST\nOF US"
        else -> "u3K"
    }



    private fun formatTime(ms: Long): String {
        val total = max(0, ms / 1000)
        val min = total / 60
        val sec = total % 60
        return "%d:%02d".format(Locale.ROOT, min, sec)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun TextView.singleLineSet() {
        setSingleLine(true)
    }

    private fun httpGet(url: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 12000
        conn.readTimeout = 12000
        conn.setRequestProperty("User-Agent", "u3K-Android-Player")
        return conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
    }

    companion object {
        private const val LIST_CONTAINER_ID = 104203
        private const val SEARCH_FIELD_ID = 104204
    }
}
