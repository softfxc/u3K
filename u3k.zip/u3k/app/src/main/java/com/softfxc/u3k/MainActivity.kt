package com.softfxc.u3k

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.Editable
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

private const val REMOTE_MEDIA_JSON = "https://raw.githubusercontent.com/softfxc/u3K/main/media.json"
private const val REMOTE_BASE = "https://raw.githubusercontent.com/softfxc/u3K/main/"
private const val GITHUB_REPO_URL = "https://github.com/softfxc/u3K"
private const val PROFILE_HAND_TEXT = "u3K: 'u' de you/tú, '3' del formato de audio mp3 y 'K' de mil como en redes sociales: tus miles de audios."
private const val TLOU_VIDEO_URL = "https://raw.githubusercontent.com/softfxc/u3K/main/The%20Last%20of%20Us.mp4"
private const val PROFILE_STRANGER_VIDEO_URL = "https://raw.githubusercontent.com/softfxc/u3K/main/stranger%20things.mp4"
private const val PROFILE_ARCANE_VIDEO_URL = "https://raw.githubusercontent.com/softfxc/u3K/main/arcane.mp4"

private const val C_BLACK = 0xFF000000.toInt()
private const val C_DARK = 0xFF121212.toInt()
private const val C_SURFACE = 0xFF181818.toInt()
private const val C_SURFACE_2 = 0xFF222222.toInt()
private const val C_SOFT = 0xFF2C2C2C.toInt()
private const val C_WHITE = 0xFFFFFFFF.toInt()
private const val C_GRAY = 0xFFACADA8.toInt()
private const val C_GRAY_2 = 0xFF757575.toInt()
private const val C_GREEN = 0xFF1DB954.toInt()
private const val C_GREEN_DARK = 0xFF008000.toInt()
private const val C_LINE = 0xFF303030.toInt()

private const val PLAY = "▶"
private const val PAUSE = "Ⅱ"
private const val LIST_CONTAINER_ID = 0x5173
private const val SEARCH_FIELD_ID = 0x5174

private data class Track(
    val id: String,
    val title: String,
    val artist: String,
    val audioUrl: String,
    val durationMs: Long?,
    val coverStyle: String,
    val coverUrl: String?,
    val videoUrl: String?,
    val profileVideoUrl: String?,
    val lyrics: Map<String, String>
)

private data class LyricLine(val timeMs: Long, val text: String)
private enum class Screen { SPLASH, HOME, SEARCH, LIBRARY, PLAYER, PROFILE }
private enum class LibraryFilter { ALL, FAVORITES, RECENTS }

class MainActivity : Activity() {
    private lateinit var root: FrameLayout
    private val ui = Handler(Looper.getMainLooper())

    private var tracks = mutableListOf<Track>()
    private var currentScreen = Screen.SPLASH
    private var libraryFilter = LibraryFilter.ALL
    private var searchTerm = ""
    private var currentIndex = -1

    private val favorites = linkedSetOf<String>()
    private val recents = mutableListOf<String>()
    private val playCounts = linkedMapOf<String, Int>()
    private var totalListens = 0
    private var countedStartForTrackId: String? = null

    private val coverCache = linkedMapOf<String, Bitmap>()
    private var currentLyrics = listOf<LyricLine>()
    private var lyricLabels = mutableListOf<TextView>()
    private var selectedLanguage = ""
    private var lastLyricIndex = -1

    private var seekBar: SeekBar? = null
    private var elapsedView: TextView? = null
    private var durationView: TextView? = null
    private var playButton: TextView? = null
    private var miniPlayButton: TextView? = null

    private val tick = object : Runnable {
        override fun run() {
            updatePlaybackUi()
            ui.postDelayed(this, 300)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window.statusBarColor = C_BLACK
        window.navigationBarColor = C_BLACK
        root = FrameLayout(this).apply { setBackgroundColor(C_BLACK) }
        setContentView(root)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 33)
        }
        loadPrefs()
        showSplash()
    }

    override fun onDestroy() {
        ui.removeCallbacks(tick)
        savePrefs()
        super.onDestroy()
    }

    override fun onBackPressed() {
        when (currentScreen) {
            Screen.PLAYER, Screen.PROFILE -> buildLibraryScreen()
            Screen.SEARCH -> buildHomeScreen()
            Screen.LIBRARY -> buildHomeScreen()
            else -> super.onBackPressed()
        }
    }

    private fun showSplash() {
        currentScreen = Screen.SPLASH
        root.removeAllViews()
        root.setBackgroundColor(C_BLACK)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(28), 0, dp(28), 0)
        }
        root.addView(box, FrameLayout.LayoutParams(-1, -1))
        box.addView(logoMark(dp(96)), LinearLayout.LayoutParams(dp(96), dp(96)).apply { bottomMargin = dp(18) })
        box.addView(text("u3K", 42f, C_WHITE, true).apply {
            gravity = Gravity.CENTER
            letterSpacing = 0.04f
        }, LinearLayout.LayoutParams(-1, -2))
        box.addView(text("Cargando catálogo remoto", 15f, C_GRAY, false).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        ui.postDelayed({ loadMedia() }, 250)
    }

    private fun loadMedia() {
        root.removeAllViews()
        root.setBackgroundColor(C_BLACK)
        val loading = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(28), 0, dp(28), 0)
        }
        root.addView(loading, FrameLayout.LayoutParams(-1, -1))
        loading.addView(ProgressBar(this), LinearLayout.LayoutParams(dp(52), dp(52)).apply { bottomMargin = dp(18) })
        loading.addView(text("Leyendo media.json desde GitHub", 17f, C_WHITE, true).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, -2))
        loading.addView(text("Sin registro, sin login y sin catálogo interno", 13f, C_GRAY, false).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        Thread {
            try {
                val raw = httpGet(REMOTE_MEDIA_JSON)
                val parsed = parseMediaJson(raw).toMutableList()
                runOnUiThread {
                    tracks = parsed
                    preloadCovers(tracks)
                    ui.post(tick)
                    buildHomeScreen()
                }
            } catch (e: Exception) {
                runOnUiThread { showLoadError(e.message ?: "error desconocido") }
            }
        }.start()
    }

    private fun showLoadError(detail: String) {
        root.removeAllViews()
        root.setBackgroundColor(C_BLACK)
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
            background = rounded(C_SURFACE, dp(20), C_LINE)
        }
        root.addView(panel, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER).apply { leftMargin = dp(22); rightMargin = dp(22) })
        panel.addView(text("No se pudo cargar u3K", 22f, C_WHITE, true).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, -2))
        panel.addView(text("Revisa que media.json exista en la raíz del repo y que sus URLs sean accesibles.", 14f, C_GRAY, false).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        panel.addView(text(detail, 12f, C_GRAY_2, false).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        panel.addView(greenButton("REINTENTAR") { loadMedia() }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(18) })
    }

    private fun parseMediaJson(json: String): List<Track> {
        val out = mutableListOf<Track>()
        val arr = JSONObject(json).getJSONArray("tracks")
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val lyricsObj = o.optJSONObject("lyrics")
            val lyrics = linkedMapOf<String, String>()
            if (lyricsObj != null) {
                val keys = lyricsObj.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    lyrics[key.uppercase(Locale.ROOT)] = normalizeRemoteUrl(lyricsObj.getString(key))
                }
            }
            val title = o.optString("title", "Audio ${i + 1}").ifBlank { "Audio ${i + 1}" }
            val coverUrl = o.optString("coverUrl", "").takeIf { it.isNotBlank() } ?: defaultCoverUrl(title)
            val videoUrl = o.optString("videoUrl", "").takeIf { it.isNotBlank() } ?: if (title.contains("The Last of Us", true)) TLOU_VIDEO_URL else null
            out += Track(
                id = o.optString("id", "track_$i").ifBlank { "track_$i" },
                title = title,
                artist = o.optString("artist", "").ifBlank { "u3K" },
                audioUrl = normalizeRemoteUrl(o.getString("audioUrl")),
                durationMs = if (o.has("durationMs") && !o.isNull("durationMs")) o.optLong("durationMs") else null,
                coverStyle = o.optString("coverStyle", defaultCoverStyle(title)),
                coverUrl = normalizeRemoteUrl(coverUrl),
                videoUrl = videoUrl?.let { normalizeRemoteUrl(it) },
                profileVideoUrl = o.optString("profileVideoUrl", "").takeIf { it.isNotBlank() }?.let { normalizeRemoteUrl(it) },
                lyrics = lyrics
            )
        }
        return out
    }

    private fun buildHomeScreen() {
        currentScreen = Screen.HOME
        clearRefs()
        val content = beginScreen(Screen.HOME)
        content.addView(text(greeting(), 18f, C_WHITE, false), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        content.addView(text("Nuevos lanzamientos", 24f, C_WHITE, true), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(18); bottomMargin = dp(10) })

        val featured = tracks.firstOrNull { currentIndex >= 0 && it.id == tracks.getOrNull(currentIndex)?.id } ?: tracks.firstOrNull()
        if (featured != null) content.addView(featuredCard(featured), LinearLayout.LayoutParams(-1, dp(132)).apply { bottomMargin = dp(18) })

        val grid = GridLayout(this).apply {
            columnCount = 2
            useDefaultMargins = false
        }
        content.addView(grid, LinearLayout.LayoutParams(-1, -2))
        tracks.forEachIndexed { idx, track ->
            val card = albumCard(track) { openPlayer(idx) }
            val lp = GridLayout.LayoutParams().apply {
                width = 0
                height = GridLayout.LayoutParams.WRAP_CONTENT
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(if (idx % 2 == 0) 0 else dp(7), dp(7), if (idx % 2 == 0) dp(7) else 0, dp(12))
            }
            grid.addView(card, lp)
        }
        endScreen()
    }

    private fun buildSearchScreen() {
        currentScreen = Screen.SEARCH
        clearRefs()
        val content = beginScreen(Screen.SEARCH)
        content.addView(text("Buscar", 28f, C_WHITE, true), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6); bottomMargin = dp(14) })

        val searchBox = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), 0, dp(12), 0)
            background = rounded(C_WHITE, dp(5), 0)
        }
        val icon = ImageView(this).apply {
            setImageResource(R.drawable.ic_search)
            setColorFilter(C_BLACK)
        }
        searchBox.addView(icon, LinearLayout.LayoutParams(dp(26), dp(26)).apply { rightMargin = dp(8) })
        val field = EditText(this).apply {
            id = SEARCH_FIELD_ID
            hint = "Busca canciones"
            setHintTextColor(0xFF555555.toInt())
            setTextColor(C_BLACK)
            textSize = 16f
            singleLine()
            background = null
            setText(searchTerm)
            setSelection(text?.length ?: 0)
            addTextChangedListener(SimpleTextWatcher { value ->
                searchTerm = value
                buildSearchScreen()
            })
        }
        searchBox.addView(field, LinearLayout.LayoutParams(0, -1, 1f))
        content.addView(searchBox, LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(18) })

        val results = filteredBySearch()
        if (searchTerm.isBlank()) {
            val empty = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(0, dp(90), 0, dp(90))
            }
            empty.addView(ImageView(this).apply {
                setImageResource(R.drawable.ic_search)
                setColorFilter(C_GRAY)
            }, LinearLayout.LayoutParams(dp(130), dp(130)))
            empty.addView(text("Busca canciones en u3K", 20f, C_WHITE, true).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(20) })
            empty.addView(text("El catálogo se obtiene desde GitHub, sin cuenta y sin registro.", 14f, C_GRAY, false).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
            content.addView(empty, LinearLayout.LayoutParams(-1, -2))
        } else if (results.isEmpty()) {
            content.addView(text("No hay resultados para “$searchTerm”", 18f, C_WHITE, true), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(30) })
        } else {
            content.addView(text("Canciones", 24f, C_WHITE, true), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
            results.forEach { track ->
                content.addView(trackRow(track, showIndex = false), LinearLayout.LayoutParams(-1, dp(76)))
            }
        }
        ui.postDelayed({
            if (currentScreen == Screen.SEARCH) {
                field.requestFocus()
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showSoftInput(field, InputMethodManager.SHOW_IMPLICIT)
            }
        }, 120)
        endScreen()
    }

    private fun buildLibraryScreen() {
        currentScreen = Screen.LIBRARY
        clearRefs()
        val content = beginScreen(Screen.LIBRARY)
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(logoMark(dp(58)), LinearLayout.LayoutParams(dp(58), dp(58)).apply { rightMargin = dp(14) })
        header.addView(text("Tu biblioteca", 25f, C_WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        val profile = TextView(this).apply {
            text = "Perfil"
            gravity = Gravity.CENTER
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(C_WHITE)
            background = rounded(C_SOFT, dp(18), 0)
            setOnClickListener { buildProfileScreen() }
        }
        header.addView(profile, LinearLayout.LayoutParams(dp(84), dp(38)))
        content.addView(header, LinearLayout.LayoutParams(-1, dp(72)).apply { bottomMargin = dp(8) })

        val chipsScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        chipsScroll.addView(chips, ViewGroup.LayoutParams(-2, -1))
        chips.addView(filterChip("Listas", LibraryFilter.ALL), LinearLayout.LayoutParams(dp(90), dp(38)).apply { rightMargin = dp(8) })
        chips.addView(filterChip("Guardadas", LibraryFilter.FAVORITES), LinearLayout.LayoutParams(dp(118), dp(38)).apply { rightMargin = dp(8) })
        chips.addView(filterChip("Recientes", LibraryFilter.RECENTS), LinearLayout.LayoutParams(dp(108), dp(38)))
        content.addView(chipsScroll, LinearLayout.LayoutParams(-1, dp(46)).apply { bottomMargin = dp(12) })

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; id = LIST_CONTAINER_ID }
        content.addView(list, LinearLayout.LayoutParams(-1, -2))
        fillLibraryList(list)
        endScreen()
    }

    private fun beginScreen(selected: Screen): LinearLayout {
        root.removeAllViews()
        root.setBackgroundColor(C_BLACK)
        window.statusBarColor = C_BLACK
        window.navigationBarColor = C_BLACK
        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), statusBarInset() + dp(10), dp(16), navigationBarInset() + dp(6))
            id = 0x5050
        }
        root.addView(shell, FrameLayout.LayoutParams(-1, -1))
        val scroll = ScrollView(this).apply { clipToPadding = false; isFillViewport = false }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, dp(18)) }
        scroll.addView(content, ViewGroup.LayoutParams(-1, -2))
        shell.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        currentShellSelected = selected
        return content
    }

    private var currentShellSelected = Screen.HOME
    private fun endScreen() {
        val shell = root.findViewById<LinearLayout>(0x5050) ?: return
        buildMiniPlayer(shell)
        buildBottomNav(shell, currentShellSelected)
    }

    private fun fillLibraryList(list: LinearLayout) {
        list.removeAllViews()
        when (libraryFilter) {
            LibraryFilter.ALL -> {
                list.addView(playlistRow("Todas las canciones", "${tracks.size} canciones", tracks.firstOrNull()) { if (tracks.isNotEmpty()) openPlayer(0) }, LinearLayout.LayoutParams(-1, dp(94)))
                list.addView(playlistRow("Canciones guardadas", "${favorites.size} canciones", tracks.firstOrNull { favorites.contains(it.id) }) { libraryFilter = LibraryFilter.FAVORITES; buildLibraryScreen() }, LinearLayout.LayoutParams(-1, dp(94)))
                list.addView(playlistRow("Recientes", "${recents.size} escuchas", recents.firstOrNull()?.let { id -> tracks.firstOrNull { it.id == id } }) { libraryFilter = LibraryFilter.RECENTS; buildLibraryScreen() }, LinearLayout.LayoutParams(-1, dp(94)))
                contentDivider(list)
                tracks.forEach { list.addView(trackRow(it, showIndex = false), LinearLayout.LayoutParams(-1, dp(74))) }
            }
            LibraryFilter.FAVORITES -> {
                val favs = tracks.filter { favorites.contains(it.id) }
                if (favs.isEmpty()) list.addView(emptyMessage("Todavía no tienes canciones guardadas."), LinearLayout.LayoutParams(-1, -2))
                favs.forEach { list.addView(trackRow(it, showIndex = false), LinearLayout.LayoutParams(-1, dp(74))) }
            }
            LibraryFilter.RECENTS -> {
                val recentTracks = recents.mapNotNull { id -> tracks.firstOrNull { it.id == id } }
                if (recentTracks.isEmpty()) list.addView(emptyMessage("Aún no hay canciones recientes."), LinearLayout.LayoutParams(-1, -2))
                recentTracks.forEach { list.addView(trackRow(it, showIndex = false), LinearLayout.LayoutParams(-1, dp(74))) }
            }
        }
    }

    private fun openPlayer(index: Int) {
        val safe = index.coerceIn(0, tracks.lastIndex)
        if (safe < 0) return
        currentIndex = safe
        val track = tracks[safe]
        addRecent(track.id)
        startTrack(track, autoplay = true)
        loadDefaultLyrics(track)
        buildPlayerScreen()
    }

    private fun buildPlayerScreen() {
        currentScreen = Screen.PLAYER
        clearRefs(keepLyrics = true)
        root.removeAllViews()
        root.background = playerBackground()
        window.statusBarColor = C_BLACK
        window.navigationBarColor = C_BLACK
        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), statusBarInset() + dp(10), dp(16), navigationBarInset() + dp(6))
        }
        root.addView(shell, FrameLayout.LayoutParams(-1, -1))
        val scroll = ScrollView(this).apply { clipToPadding = false }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        scroll.addView(content, ViewGroup.LayoutParams(-1, -2))
        shell.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val track = tracks.getOrNull(currentIndex) ?: return
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val back = ImageView(this).apply {
            setImageResource(R.drawable.ic_arrow_back)
            setColorFilter(C_WHITE)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setOnClickListener { buildLibraryScreen() }
        }
        top.addView(back, LinearLayout.LayoutParams(dp(52), dp(52)))
        top.addView(text("Ahora reproduciendo", 16f, C_WHITE, true).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(0, -2, 1f))
        val fav = TextView(this).apply {
            text = if (favorites.contains(track.id)) "Guardada" else "Guardar"
            gravity = Gravity.CENTER
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(if (favorites.contains(track.id)) C_BLACK else C_WHITE)
            background = if (favorites.contains(track.id)) rounded(C_GREEN, dp(18), 0) else rounded(Color.TRANSPARENT, dp(18), C_GRAY_2)
            setOnClickListener { toggleFavorite(track.id); buildPlayerScreen() }
        }
        top.addView(fav, LinearLayout.LayoutParams(dp(96), dp(38)))
        content.addView(top, LinearLayout.LayoutParams(-1, dp(58)).apply { bottomMargin = dp(8) })

        content.addView(nowPlayingVisual(track), LinearLayout.LayoutParams(dp(278), dp(278)).apply { topMargin = dp(16); bottomMargin = dp(24) })
        titleView(track, content)
        controls(track, content)
        languageButtons(track, content)
        lyricsBlock(content)
        endPlayerScreen(shell)
    }

    private fun titleView(track: Track, content: LinearLayout) {
        content.addView(text(track.title, 24f, C_WHITE, true).apply {
            gravity = Gravity.START
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(-1, -2))
        content.addView(text("u3K", 14f, C_GRAY, false), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4); bottomMargin = dp(18) })
    }

    private fun controls(track: Track, content: LinearLayout) {
        seekBar = SeekBar(this).apply {
            max = (track.durationMs ?: PlaybackNotificationService.currentState().durationMs.toLong()).toInt().coerceAtLeast(1)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { if (fromUser) seekTo(progress) }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        content.addView(seekBar, LinearLayout.LayoutParams(-1, dp(44)))
        val times = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        elapsedView = text("0:00", 12f, C_GRAY, false)
        durationView = text(formatTime(track.durationMs ?: 0), 12f, C_GRAY, false).apply { gravity = Gravity.END }
        times.addView(elapsedView, LinearLayout.LayoutParams(0, -2, 1f))
        times.addView(durationView, LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(times, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        row.addView(roundButton("‹") { skip(-1) }, LinearLayout.LayoutParams(dp(58), dp(58)).apply { rightMargin = dp(18) })
        playButton = TextView(this).apply {
            text = if (PlaybackNotificationService.isCurrentPlaying(track.id)) PAUSE else PLAY
            gravity = Gravity.CENTER
            textSize = 30f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(C_BLACK)
            background = rounded(C_GREEN, dp(38), 0)
            setOnClickListener { togglePlayback() }
        }
        row.addView(playButton, LinearLayout.LayoutParams(dp(76), dp(76)))
        row.addView(roundButton("›") { skip(1) }, LinearLayout.LayoutParams(dp(58), dp(58)).apply { leftMargin = dp(18) })
        content.addView(row, LinearLayout.LayoutParams(-1, dp(86)).apply { bottomMargin = dp(16) })
    }

    private fun languageButtons(track: Track, content: LinearLayout) {
        if (track.lyrics.isEmpty()) return
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        track.lyrics.keys.forEach { lang ->
            val title = languageName(lang)
            val selected = selectedLanguage.equals(lang, true)
            val b = TextView(this).apply {
                text = title
                gravity = Gravity.CENTER
                textSize = 13f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(if (selected) C_BLACK else C_WHITE)
                background = if (selected) rounded(C_GREEN, dp(18), 0) else rounded(C_SURFACE, dp(18), C_LINE)
                setOnClickListener { loadLyrics(track, lang, rebuild = true); buildPlayerScreen() }
            }
            row.addView(b, LinearLayout.LayoutParams(dp(102), dp(38)).apply { rightMargin = dp(8) })
        }
        val share = TextView(this).apply {
            text = "Compartir"
            gravity = Gravity.CENTER
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(C_WHITE)
            background = rounded(C_SURFACE, dp(18), C_LINE)
            setOnClickListener { showShareLyricsOptions() }
        }
        row.addView(share, LinearLayout.LayoutParams(dp(102), dp(38)))
        content.addView(row, LinearLayout.LayoutParams(-1, dp(44)).apply { bottomMargin = dp(14) })
    }

    private fun lyricsBlock(content: LinearLayout) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(C_GREEN_DARK, dp(18), 0)
        }
        content.addView(box, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(22) })
        box.addView(text("Letra", 22f, C_WHITE, true), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        lyricLabels.clear()
        if (currentLyrics.isEmpty()) {
            box.addView(text("Esta canción no tiene letra sincronizada disponible.", 18f, C_WHITE, true).apply {
                setLineSpacing(dp(3).toFloat(), 1f)
            }, LinearLayout.LayoutParams(-1, -2))
        } else {
            currentLyrics.forEach { line ->
                val tv = text(line.text, 20f, 0x88FFFFFF.toInt(), true).apply {
                    setPadding(0, dp(4), 0, dp(4))
                    setLineSpacing(dp(2).toFloat(), 1f)
                }
                lyricLabels.add(tv)
                box.addView(tv, LinearLayout.LayoutParams(-1, -2))
            }
        }
    }

    private fun endPlayerScreen(shell: LinearLayout) {
        buildBottomNav(shell, Screen.LIBRARY)
    }

    private fun buildProfileScreen() {
        currentScreen = Screen.PROFILE
        clearRefs()
        val content = beginScreen(Screen.LIBRARY)
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(logoMark(dp(68)), LinearLayout.LayoutParams(dp(68), dp(68)).apply { rightMargin = dp(14) })
        val copy = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        copy.addView(text("Perfil", 28f, C_WHITE, true), LinearLayout.LayoutParams(-1, -2))
        copy.addView(text("Actividad local de u3K", 14f, C_GRAY, false), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
        header.addView(copy, LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(header, LinearLayout.LayoutParams(-1, dp(86)).apply { bottomMargin = dp(16) })

        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        stats.addView(statCard(totalListens.toString(), "escuchas"), LinearLayout.LayoutParams(0, dp(92), 1f).apply { rightMargin = dp(8) })
        stats.addView(statCard(favorites.size.toString(), "guardadas"), LinearLayout.LayoutParams(0, dp(92), 1f).apply { leftMargin = dp(8) })
        content.addView(stats, LinearLayout.LayoutParams(-1, dp(100)).apply { bottomMargin = dp(16) })

        content.addView(text(PROFILE_HAND_TEXT, 18f, C_WHITE, true).apply {
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(C_SURFACE, dp(18), C_LINE)
            setLineSpacing(dp(4).toFloat(), 1f)
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(18) })

        content.addView(text("Vídeos", 24f, C_WHITE, true), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        content.addView(profileVideoCard("Stranger Things", PROFILE_STRANGER_VIDEO_URL), LinearLayout.LayoutParams(-1, dp(210)).apply { bottomMargin = dp(14) })
        content.addView(profileVideoCard("Arcane", PROFILE_ARCANE_VIDEO_URL), LinearLayout.LayoutParams(-1, dp(210)).apply { bottomMargin = dp(20) })
        endScreen()
    }

    private fun albumCard(track: Track, click: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(12))
            background = rounded(C_SURFACE, dp(4), 0)
            setOnClickListener { click() }
            addView(coverFrame(track, dp(142), dp(4)), LinearLayout.LayoutParams(-1, dp(142)))
            addView(text(track.title, 15f, C_WHITE, true).apply {
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
            }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(9) })
            addView(text("u3K", 12f, C_GRAY, false), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(3) })
        }
    }

    private fun featuredCard(track: Track): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = gradient(intArrayOf(C_SOFT, C_DARK, C_BLACK), dp(6))
            setOnClickListener { openPlayer(tracks.indexOfFirst { it.id == track.id }.coerceAtLeast(0)) }
            addView(coverFrame(track, dp(108), dp(4)), LinearLayout.LayoutParams(dp(108), dp(108)).apply { rightMargin = dp(14) })
            val copy = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
            copy.addView(text("Sigue escuchando", 12f, C_GREEN, true), LinearLayout.LayoutParams(-1, -2))
            copy.addView(text(track.title, 21f, C_WHITE, true).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
            copy.addView(text("Disponible en GitHub", 13f, C_GRAY, false), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
            addView(copy, LinearLayout.LayoutParams(0, -1, 1f))
            addView(TextView(context).apply {
                text = PLAY
                gravity = Gravity.CENTER
                textSize = 24f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(C_BLACK)
                background = rounded(C_GREEN, dp(25), 0)
            }, LinearLayout.LayoutParams(dp(52), dp(52)).apply { leftMargin = dp(10) })
        }
    }

    private fun trackRow(track: Track, showIndex: Boolean): LinearLayout {
        val idx = tracks.indexOfFirst { it.id == track.id }
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(5), 0, dp(5))
            background = rounded(Color.TRANSPARENT, dp(1), 0)
            setOnClickListener { openPlayer(idx.coerceAtLeast(0)) }
            if (showIndex) addView(text((idx + 1).toString(), 14f, C_GRAY, false).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(30), -1))
            addView(coverFrame(track, dp(58), dp(2)), LinearLayout.LayoutParams(dp(58), dp(58)).apply { rightMargin = dp(14) })
            val copy = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
            copy.addView(text(track.title, 16f, C_WHITE, false).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }, LinearLayout.LayoutParams(-1, 0, 1f))
            val meta = if (PlaybackNotificationService.isCurrentPlaying(track.id)) "Reproduciendo" else "u3K"
            copy.addView(text(meta, 13f, if (PlaybackNotificationService.isCurrentPlaying(track.id)) C_GREEN else C_GRAY, false), LinearLayout.LayoutParams(-1, 0, 1f))
            addView(copy, LinearLayout.LayoutParams(0, -1, 1f))
        }
    }

    private fun playlistRow(title: String, desc: String, sample: Track?, click: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(8))
            setOnClickListener { click() }
            if (sample != null) addView(coverFrame(sample, dp(74), dp(2)), LinearLayout.LayoutParams(dp(74), dp(74)).apply { leftMargin = dp(4); rightMargin = dp(16) })
            else addView(playlistPlaceholder(), LinearLayout.LayoutParams(dp(74), dp(74)).apply { leftMargin = dp(4); rightMargin = dp(16) })
            val copy = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
            copy.addView(text(title, 16f, C_WHITE, false), LinearLayout.LayoutParams(-1, 0, 1f))
            copy.addView(text(desc, 13f, C_GRAY, false), LinearLayout.LayoutParams(-1, 0, 1f))
            addView(copy, LinearLayout.LayoutParams(0, -1, 1f))
        }
    }

    private fun buildMiniPlayer(shell: LinearLayout) {
        val track = tracks.getOrNull(currentIndex) ?: return
        val mini = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
            background = rounded(C_SOFT, dp(5), 0)
            setOnClickListener { buildPlayerScreen() }
        }
        mini.addView(coverFrame(track, dp(50), dp(3)), LinearLayout.LayoutParams(dp(50), dp(50)).apply { rightMargin = dp(10) })
        val copy = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
        copy.addView(text(track.title, 14f, C_WHITE, true).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }, LinearLayout.LayoutParams(-1, 0, 1f))
        copy.addView(text(if (PlaybackNotificationService.isCurrentPlaying(track.id)) "Reproduciendo" else "En pausa", 12f, C_GRAY, false), LinearLayout.LayoutParams(-1, 0, 1f))
        mini.addView(copy, LinearLayout.LayoutParams(0, -1, 1f))
        miniPlayButton = TextView(this).apply {
            text = if (PlaybackNotificationService.isCurrentPlaying(track.id)) PAUSE else PLAY
            gravity = Gravity.CENTER
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(C_WHITE)
            setOnClickListener { togglePlayback() }
        }
        mini.addView(miniPlayButton, LinearLayout.LayoutParams(dp(48), dp(48)))
        shell.addView(mini, LinearLayout.LayoutParams(-1, dp(62)).apply { bottomMargin = dp(5) })
    }

    private fun buildBottomNav(shell: LinearLayout, selected: Screen) {
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(4))
            setBackgroundColor(C_BLACK)
        }
        shell.addView(nav, LinearLayout.LayoutParams(-1, dp(60)))
        nav.addView(navItem(R.drawable.ic_home, "Inicio", selected == Screen.HOME) { buildHomeScreen() }, LinearLayout.LayoutParams(0, -1, 1f))
        nav.addView(navItem(R.drawable.ic_search, "Buscar", selected == Screen.SEARCH) { buildSearchScreen() }, LinearLayout.LayoutParams(0, -1, 1f))
        nav.addView(navItem(R.drawable.ic_library_music, "Biblioteca", selected == Screen.LIBRARY || selected == Screen.PLAYER) { buildLibraryScreen() }, LinearLayout.LayoutParams(0, -1, 1f))
    }

    private fun navItem(iconRes: Int, label: String, selected: Boolean, action: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setOnClickListener { action() }
            val icon = ImageView(context).apply {
                setImageResource(iconRes)
                setColorFilter(if (selected) C_WHITE else C_GRAY)
            }
            addView(icon, LinearLayout.LayoutParams(dp(24), dp(24)))
            addView(text(label, 11f, if (selected) C_WHITE else C_GRAY, selected).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(3) })
        }
    }

    private fun nowPlayingVisual(track: Track): FrameLayout {
        val frame = FrameLayout(this).apply { background = rounded(Color.TRANSPARENT, dp(4), 0) }
        val cover = coverFrame(track, dp(278), dp(4))
        frame.addView(cover, FrameLayout.LayoutParams(-1, -1))
        val videoUrl = track.videoUrl
        if (!videoUrl.isNullOrBlank()) {
            val video = VideoView(this).apply { visibility = View.GONE }
            frame.addView(video, FrameLayout.LayoutParams(-1, -1))
            val hint = text("Toca portada / vídeo", 12f, C_WHITE, true).apply {
                gravity = Gravity.CENTER
                background = rounded(0xAA000000.toInt(), dp(16), 0)
                setPadding(dp(12), 0, dp(12), 0)
            }
            frame.addView(hint, FrameLayout.LayoutParams(-2, dp(34), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(12) })
            var showing = false
            fun prepare() {
                try {
                    video.setVideoURI(Uri.parse(videoUrl))
                    video.setOnPreparedListener { mp ->
                        mp.isLooping = true
                        mp.setVolume(0f, 0f)
                        video.start()
                    }
                    video.setOnErrorListener { _, _, _ -> true }
                } catch (_: Exception) {}
            }
            frame.setOnClickListener {
                showing = !showing
                if (showing) {
                    video.visibility = View.VISIBLE
                    if (!video.isPlaying) prepare()
                    hint.text = "Vídeo activo"
                } else {
                    try { video.pause() } catch (_: Exception) {}
                    video.visibility = View.GONE
                    hint.text = "Toca portada / vídeo"
                }
            }
        }
        return frame
    }

    private fun profileVideoCard(title: String, url: String): FrameLayout {
        val frame = FrameLayout(this).apply { background = rounded(C_SURFACE, dp(6), 0) }
        val video = VideoView(this)
        frame.addView(video, FrameLayout.LayoutParams(-1, -1))
        val shade = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.BOTTOM
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x10000000, 0xDD000000.toInt()))
        }
        frame.addView(shade, FrameLayout.LayoutParams(-1, -1))
        shade.addView(text(title, 21f, C_WHITE, true), LinearLayout.LayoutParams(-1, -2))
        shade.addView(text("Autoplay silenciado · toca para activar audio", 12f, C_GRAY, false), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
        var muted = true
        frame.setOnClickListener {
            muted = !muted
            (video.tag as? MediaPlayer)?.setVolume(if (muted) 0f else 1f, if (muted) 0f else 1f)
        }
        try {
            video.setVideoURI(Uri.parse(url))
            video.setOnPreparedListener { mp ->
                video.tag = mp
                mp.isLooping = true
                mp.setVolume(0f, 0f)
                video.start()
            }
            video.setOnErrorListener { _, _, _ -> true }
        } catch (_: Exception) {}
        return frame
    }

    private fun startTrack(track: Track, autoplay: Boolean) {
        val intent = Intent(this, PlaybackNotificationService::class.java).apply {
            action = PlaybackNotificationService.ACTION_LOAD
            putExtra(PlaybackNotificationService.EXTRA_ID, track.id)
            putExtra(PlaybackNotificationService.EXTRA_TITLE, track.title)
            putExtra(PlaybackNotificationService.EXTRA_URL, track.audioUrl)
            putExtra(PlaybackNotificationService.EXTRA_AUTOPLAY, autoplay)
        }
        try { ContextCompat.startForegroundService(this, intent) } catch (_: Exception) { startService(intent) }
        countedStartForTrackId = null
    }

    private fun togglePlayback() {
        val intent = Intent(this, PlaybackNotificationService::class.java).apply { action = PlaybackNotificationService.ACTION_TOGGLE }
        try { ContextCompat.startForegroundService(this, intent) } catch (_: Exception) { startService(intent) }
        ui.postDelayed({ updatePlaybackUi() }, 120L)
    }

    private fun seekTo(position: Int) {
        val intent = Intent(this, PlaybackNotificationService::class.java).apply {
            action = PlaybackNotificationService.ACTION_SEEK
            putExtra(PlaybackNotificationService.EXTRA_POSITION, position)
        }
        try { ContextCompat.startForegroundService(this, intent) } catch (_: Exception) { startService(intent) }
    }

    private fun skip(delta: Int) {
        if (tracks.isEmpty()) return
        val next = when {
            currentIndex < 0 -> 0
            else -> (currentIndex + delta + tracks.size) % tracks.size
        }
        openPlayer(next)
    }

    private fun updatePlaybackUi() {
        val state = PlaybackNotificationService.currentState()
        val track = tracks.getOrNull(currentIndex)
        val duration = max(state.durationMs, track?.durationMs?.toInt() ?: 0)
        if (duration > 0) {
            seekBar?.max = duration
            seekBar?.progress = state.positionMs.coerceIn(0, duration)
            elapsedView?.text = formatTime(state.positionMs.toLong())
            durationView?.text = formatTime(duration.toLong())
        }
        val playingCurrent = track != null && state.trackId == track.id && state.playing
        playButton?.text = if (playingCurrent) PAUSE else PLAY
        miniPlayButton?.text = if (playingCurrent) PAUSE else PLAY
        if (playingCurrent && track != null && state.positionMs > 15000 && countedStartForTrackId != track.id) {
            countedStartForTrackId = track.id
            totalListens += 1
            playCounts[track.id] = (playCounts[track.id] ?: 0) + 1
            savePrefs()
        }
        updateLyrics(state.positionMs.toLong())
    }

    private fun updateLyrics(pos: Long) {
        if (currentLyrics.isEmpty() || lyricLabels.isEmpty()) return
        var active = 0
        for (i in currentLyrics.indices) {
            if (currentLyrics[i].timeMs <= pos + 250) active = i else break
        }
        if (active == lastLyricIndex) return
        lastLyricIndex = active
        lyricLabels.forEachIndexed { i, tv ->
            tv.setTextColor(if (i == active) C_WHITE else 0x88FFFFFF.toInt())
            tv.textSize = if (i == active) 22f else 20f
        }
    }

    private fun loadDefaultLyrics(track: Track) {
        selectedLanguage = when {
            track.lyrics.containsKey("ES") -> "ES"
            track.lyrics.containsKey("EN") -> "EN"
            track.lyrics.isNotEmpty() -> track.lyrics.keys.first()
            else -> ""
        }
        currentLyrics = emptyList()
        lastLyricIndex = -1
        if (selectedLanguage.isNotBlank()) loadLyrics(track, selectedLanguage, rebuild = true)
    }

    private fun loadLyrics(track: Track, lang: String, rebuild: Boolean = false) {
        selectedLanguage = lang
        currentLyrics = emptyList()
        lastLyricIndex = -1
        val url = track.lyrics[lang] ?: return
        Thread {
            try {
                val lines = parseLrc(httpGet(url))
                runOnUiThread {
                    currentLyrics = lines
                    if (rebuild && currentScreen == Screen.PLAYER) buildPlayerScreen()
                }
            } catch (_: Exception) {
                runOnUiThread {
                    currentLyrics = emptyList()
                    if (rebuild && currentScreen == Screen.PLAYER) buildPlayerScreen()
                }
            }
        }.start()
    }

    private fun parseLrc(raw: String): List<LyricLine> {
        val regex = Regex("\\[(\\d{1,2}):(\\d{2})(?:\\.(\\d{1,3}))?]([^\\r\\n]*)")
        return raw.lineSequence().mapNotNull { line ->
            val m = regex.find(line) ?: return@mapNotNull null
            val min = m.groupValues[1].toLongOrNull() ?: 0
            val sec = m.groupValues[2].toLongOrNull() ?: 0
            val fracText = m.groupValues[3]
            val ms = when (fracText.length) { 1 -> fracText.toLong() * 100; 2 -> fracText.toLong() * 10; 3 -> fracText.toLong(); else -> 0 }
            val text = m.groupValues[4].trim()
            if (text.isBlank()) null else LyricLine(min * 60000 + sec * 1000 + ms, text)
        }.sortedBy { it.timeMs }.toList()
    }

    private fun showShareLyricsOptions() {
        if (currentLyrics.isEmpty()) {
            Toast.makeText(this, "Esta canción no tiene letra para compartir.", Toast.LENGTH_SHORT).show()
            return
        }
        var start = lastLyricIndex.coerceAtLeast(0).coerceAtMost(currentLyrics.lastIndex)
        var count = 4
        var color = C_GREEN_DARK
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(6), 0, dp(6), 0) }
        val preview = text("", 18f, C_WHITE, true).apply {
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setLineSpacing(dp(4).toFloat(), 1f)
        }
        fun refreshPreview() {
            preview.text = lyricSnippet(start, count)
            preview.background = gradient(intArrayOf(color, darken(color, 0.65f)), dp(18))
        }
        refreshPreview()
        layout.addView(preview, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        layout.addView(text("Inicio", 13f, Color.DKGRAY, true), LinearLayout.LayoutParams(-1, -2))
        layout.addView(SeekBar(this).apply {
            max = currentLyrics.lastIndex.coerceAtLeast(1)
            progress = start
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { start = progress; refreshPreview() }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }, LinearLayout.LayoutParams(-1, dp(42)))
        layout.addView(text("Líneas", 13f, Color.DKGRAY, true), LinearLayout.LayoutParams(-1, -2))
        layout.addView(SeekBar(this).apply {
            max = 5
            progress = count - 1
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { count = progress + 1; refreshPreview() }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }, LinearLayout.LayoutParams(-1, dp(42)))
        val colors = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(C_GREEN_DARK, 0xFF8A2BE2.toInt(), 0xFFB91C1C.toInt()).forEach { c ->
            colors.addView(TextView(this).apply { background = rounded(c, dp(18), 0); setOnClickListener { color = c; refreshPreview() } }, LinearLayout.LayoutParams(0, dp(36), 1f).apply { rightMargin = dp(8) })
        }
        layout.addView(colors, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(8) })
        AlertDialog.Builder(this)
            .setTitle("Compartir letra")
            .setView(layout)
            .setNegativeButton("Cancelar", null)
            .setNeutralButton("Guardar") { _, _ -> saveLyricImage(lyricSnippet(start, count), color) }
            .setPositiveButton("Compartir") { _, _ -> shareLyricImage(lyricSnippet(start, count), color) }
            .show()
    }

    private fun lyricSnippet(start: Int, count: Int): String = currentLyrics.drop(start).take(count).joinToString("\n") { it.text }

    private fun createLyricBitmap(snippet: String, color: Int): Bitmap {
        val w = 1080
        val h = 1080
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val gradient = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), color, darken(color, 0.58f), Shader.TileMode.CLAMP)
        paint.shader = gradient
        canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), paint)
        paint.shader = null
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = C_WHITE
            textSize = 58f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
        val layout = StaticLayout.Builder.obtain(snippet, 0, snippet.length, tp, w - 140)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setLineSpacing(10f, 1f)
            .setIncludePad(false)
            .build()
        canvas.save()
        canvas.translate(70f, 220f)
        layout.draw(canvas)
        canvas.restore()
        val brand = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = C_WHITE; textSize = 38f; typeface = Typeface.DEFAULT_BOLD }
        canvas.drawText("u3K · $GITHUB_REPO_URL", 70f, 980f, brand)
        return bmp
    }

    private fun shareLyricImage(snippet: String, color: Int) {
        try {
            val file = File(cacheDir, "u3k_letra_${System.currentTimeMillis()}.png")
            FileOutputStream(file).use { createLyricBitmap(snippet, color).compress(Bitmap.CompressFormat.PNG, 100, it) }
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_TEXT, GITHUB_REPO_URL)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "Compartir letra u3K"))
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo compartir: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun saveLyricImage(snippet: String, color: Int) {
        try {
            val bitmap = createLyricBitmap(snippet, color)
            val name = "u3k_letra_${System.currentTimeMillis()}.png"
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/u3K")
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                if (uri != null) contentResolver.openOutputStream(uri)?.use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            } else {
                val dir = File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_PICTURES), "u3K")
                dir.mkdirs()
                FileOutputStream(File(dir, name)).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            }
            Toast.makeText(this, "Imagen guardada en galería", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo guardar: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun coverFrame(track: Track, size: Int, radius: Int): FrameLayout {
        val frame = FrameLayout(this).apply { background = rounded(C_SOFT, radius, 0) }
        val key = track.coverUrl.orEmpty()
        val bmp = coverCache[key]
        if (bmp != null) {
            frame.addView(ImageView(this).apply {
                setImageBitmap(bmp)
                scaleType = ImageView.ScaleType.CENTER_CROP
            }, FrameLayout.LayoutParams(-1, -1))
        } else {
            val place = LinearLayout(this).apply {
                gravity = Gravity.CENTER
                orientation = LinearLayout.VERTICAL
                background = coverGradient(track)
            }
            place.addView(ImageView(this).apply {
                setImageResource(R.drawable.ic_music_note)
                setColorFilter(C_WHITE)
                alpha = 0.88f
            }, LinearLayout.LayoutParams((size * 0.36f).roundToInt(), (size * 0.36f).roundToInt()))
            frame.addView(place, FrameLayout.LayoutParams(-1, -1))
        }
        return frame
    }

    private fun coverGradient(track: Track): GradientDrawable {
        val colors = when {
            track.coverStyle.contains("red", true) || track.title.contains("Arcane", true) -> intArrayOf(0xFF431407.toInt(), 0xFF991B1B.toInt())
            track.coverStyle.contains("logo", true) || track.title.contains("Last of Us", true) -> intArrayOf(0xFF064E3B.toInt(), 0xFF111827.toInt())
            track.coverStyle.contains("cover4", true) || track.title.contains("Stranger", true) -> intArrayOf(0xFF312E81.toInt(), 0xFF111827.toInt())
            else -> intArrayOf(0xFF7C2D12.toInt(), 0xFF111827.toInt())
        }
        return gradient(colors, dp(4))
    }

    private fun playlistPlaceholder(): FrameLayout {
        return FrameLayout(this).apply {
            background = gradient(intArrayOf(C_SOFT, C_SURFACE), dp(2))
            addView(ImageView(context).apply {
                setImageResource(R.drawable.ic_library_music)
                setColorFilter(C_WHITE)
            }, FrameLayout.LayoutParams(dp(34), dp(34), Gravity.CENTER))
        }
    }

    private fun preloadCovers(list: List<Track>) {
        Thread {
            var changed = false
            list.mapNotNull { it.coverUrl }.distinct().forEach { url ->
                if (!coverCache.containsKey(url)) {
                    try {
                        val bytes = URL(url).openStream().use { it.readBytes() }
                        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.let { bmp ->
                            coverCache[url] = bmp
                            changed = true
                        }
                    } catch (_: Exception) {}
                }
            }
            if (changed) runOnUiThread {
                when (currentScreen) {
                    Screen.HOME -> buildHomeScreen()
                    Screen.SEARCH -> buildSearchScreen()
                    Screen.LIBRARY -> buildLibraryScreen()
                    Screen.PLAYER -> buildPlayerScreen()
                    Screen.PROFILE -> buildProfileScreen()
                    else -> {}
                }
            }
        }.start()
    }

    private fun filterChip(label: String, mode: LibraryFilter): TextView {
        val selected = libraryFilter == mode
        return TextView(this).apply {
            text = label
            gravity = Gravity.CENTER
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(if (selected) C_BLACK else C_WHITE)
            background = if (selected) rounded(C_GREEN, dp(18), 0) else rounded(C_SOFT, dp(18), 0)
            setOnClickListener { libraryFilter = mode; buildLibraryScreen() }
        }
    }

    private fun greenButton(label: String, action: () -> Unit): TextView = TextView(this).apply {
        text = label
        gravity = Gravity.CENTER
        textSize = 14f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(C_BLACK)
        background = rounded(C_GREEN, dp(24), 0)
        setOnClickListener { action() }
    }

    private fun roundButton(label: String, action: () -> Unit): TextView = TextView(this).apply {
        text = label
        gravity = Gravity.CENTER
        textSize = 32f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(C_WHITE)
        background = rounded(C_SURFACE_2, dp(29), 0)
        setOnClickListener { action() }
    }

    private fun statCard(value: String, label: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        setPadding(dp(10), dp(10), dp(10), dp(10))
        background = rounded(C_SURFACE, dp(8), 0)
        addView(text(value, 28f, C_GREEN, true).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, 0, 1f))
        addView(text(label, 13f, C_GRAY, false).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, 0, 1f))
    }

    private fun emptyMessage(msg: String): TextView = text(msg, 16f, C_GRAY, false).apply {
        gravity = Gravity.CENTER
        setPadding(0, dp(40), 0, dp(40))
    }

    private fun contentDivider(parent: LinearLayout) {
        parent.addView(View(this).apply { setBackgroundColor(C_LINE) }, LinearLayout.LayoutParams(-1, 1).apply { topMargin = dp(8); bottomMargin = dp(8) })
    }

    private fun clearRefs(keepLyrics: Boolean = false) {
        seekBar = null
        elapsedView = null
        durationView = null
        playButton = null
        miniPlayButton = null
        if (!keepLyrics) {
            lyricLabels.clear()
            if (currentScreen != Screen.PLAYER) currentLyrics = emptyList()
        }
    }

    private fun filteredBySearch(): List<Track> {
        val term = searchTerm.trim().lowercase(Locale.ROOT)
        return if (term.isBlank()) emptyList() else tracks.filter { it.title.lowercase(Locale.ROOT).contains(term) }
    }

    private fun addRecent(id: String) {
        recents.remove(id)
        recents.add(0, id)
        while (recents.size > 30) recents.removeAt(recents.lastIndex)
        savePrefs()
    }

    private fun toggleFavorite(id: String) {
        if (favorites.contains(id)) favorites.remove(id) else favorites.add(id)
        savePrefs()
    }

    private fun greeting(): String {
        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        return when (hour) {
            in 6..12 -> "Buenos días"
            in 13..20 -> "Buenas tardes"
            else -> "Buenas noches"
        }
    }

    private fun languageName(code: String): String = when (code.uppercase(Locale.ROOT)) {
        "ES" -> "Español"
        "EN" -> "Inglés"
        else -> code
    }

    private fun formatTime(ms: Long): String {
        if (ms <= 0) return "0:00"
        val total = ms / 1000
        return "${total / 60}:${(total % 60).toString().padStart(2, '0')}"
    }

    private fun normalizeRemoteUrl(value: String): String {
        val v = value.trim()
        return when {
            v.startsWith("http://") || v.startsWith("https://") -> v.replace(" ", "%20")
            v.isBlank() -> v
            else -> REMOTE_BASE + Uri.encode(v, "/[]-_.~")
        }
    }

    private fun defaultCoverUrl(title: String): String = when {
        title.contains("The Last of Us", true) -> REMOTE_BASE + "cover2.jpg"
        title.contains("Arcane", true) || title.contains("Blood", true) || title.contains("Guitarra", true) -> REMOTE_BASE + "cover3.jpg"
        else -> REMOTE_BASE + "cover1.jpg"
    }

    private fun defaultCoverStyle(title: String): String = when {
        title.contains("The Last of Us", true) -> "logo"
        title.contains("Arcane", true) || title.contains("Blood", true) || title.contains("Guitarra", true) -> "red"
        else -> "sunset"
    }

    private fun httpGet(url: String): String {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 20000
            requestMethod = "GET"
            setRequestProperty("Cache-Control", "no-cache")
        }
        return conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
    }

    private fun loadPrefs() {
        val sp = getSharedPreferences("u3k_state", Context.MODE_PRIVATE)
        favorites.clear()
        sp.getString("favorites", "")?.split("|")?.filter { it.isNotBlank() }?.forEach { favorites.add(it) }
        recents.clear()
        sp.getString("recents", "")?.split("|")?.filter { it.isNotBlank() }?.forEach { recents.add(it) }
        totalListens = sp.getInt("totalListens", 0)
    }

    private fun savePrefs() {
        getSharedPreferences("u3k_state", Context.MODE_PRIVATE).edit()
            .putString("favorites", favorites.joinToString("|"))
            .putString("recents", recents.joinToString("|"))
            .putInt("totalListens", totalListens)
            .apply()
    }

    private fun text(value: String, sp: Float, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = value
        textSize = sp
        setTextColor(color)
        includeFontPadding = true
        typeface = if (bold) Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD) else Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
    }

    private fun logoMark(size: Int): TextView = TextView(this).apply {
        text = "u3K"
        gravity = Gravity.CENTER
        textSize = (size / resources.displayMetrics.density) * 0.26f
        setTextColor(C_BLACK)
        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        background = rounded(C_GREEN, size / 2, 0)
    }

    private fun rounded(color: Int, radius: Int, strokeColor: Int): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        setColor(color)
        cornerRadius = radius.toFloat()
        if (strokeColor != 0) setStroke(dp(1), strokeColor)
    }

    private fun gradient(colors: IntArray, radius: Int): GradientDrawable = GradientDrawable(GradientDrawable.Orientation.TL_BR, colors).apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = radius.toFloat()
    }

    private fun playerBackground(): GradientDrawable = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(C_SOFT, C_DARK, C_BLACK)).apply { shape = GradientDrawable.RECTANGLE }

    private fun darken(color: Int, factor: Float): Int {
        val r = (Color.red(color) * factor).roundToInt().coerceIn(0, 255)
        val g = (Color.green(color) * factor).roundToInt().coerceIn(0, 255)
        val b = (Color.blue(color) * factor).roundToInt().coerceIn(0, 255)
        return Color.rgb(r, g, b)
    }

    private fun EditText.singleLine() {
        isSingleLine = true
        maxLines = 1
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()

    private fun statusBarInset(): Int {
        val resId = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (resId > 0) resources.getDimensionPixelSize(resId) else 0
    }

    private fun navigationBarInset(): Int {
        val resId = resources.getIdentifier("navigation_bar_height", "dimen", "android")
        return if (resId > 0) resources.getDimensionPixelSize(resId) else 0
    }

    private class SimpleTextWatcher(val onChange: (String) -> Unit) : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { onChange(s?.toString().orEmpty()) }
        override fun afterTextChanged(s: Editable?) {}
    }
}
