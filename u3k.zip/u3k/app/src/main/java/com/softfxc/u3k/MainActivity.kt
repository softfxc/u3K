package com.softfxc.u3k

import android.app.Activity
import android.app.AlertDialog
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.Editable
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextWatcher
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.*
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

private const val REMOTE_MEDIA_JSON = "https://raw.githubusercontent.com/softfxc/u3K/main/media.json"
private const val REMOTE_BASE = "https://raw.githubusercontent.com/softfxc/u3K/main/"
private const val PROFILE_HAND_TEXT = "u3K: 'u' de you/tú, '3' del formato de audio mp3 y 'K' de mil como en redes sociales: tus miles de audios."

private const val C_BG = 0xFF090A0D.toInt()
private const val C_CARD = 0xFF17181D.toInt()
private const val C_LINE = 0xFF202127.toInt()
private const val C_TEXT = 0xFFF3F3F4.toInt()
private const val C_MUTED = 0xFF9A9BA1.toInt()
private const val C_CHIP = 0xFF202126.toInt()
private const val C_WHITE = 0xFFFFFFFF.toInt()

private data class Track(
    val id: String,
    val title: String,
    val artist: String,
    val audioUrl: String,
    val durationMs: Long?,
    val coverStyle: String,
    val coverUrl: String?,
    val lyrics: Map<String, String>
)

private data class LyricLine(val timeMs: Long, val text: String)

private enum class FilterMode { ALL, FAVORITES, RECENTS }

class MainActivity : Activity() {
    private lateinit var root: FrameLayout
    private val ui = Handler(Looper.getMainLooper())

    private var tracks: MutableList<Track> = mutableListOf()
    private var filterMode = FilterMode.ALL
    private var searchTerm = ""

    private val favorites = linkedSetOf<String>()
    private val recents = mutableListOf<String>()
    private var totalListens = 0
    private val playCounts = linkedMapOf<String, Int>()
    private val coverCache = linkedMapOf<String, Bitmap>()
    private var currentScreen = "intro"

    private var player: MediaPlayer? = null
    private var isPrepared = false
    private var currentIndex = -1
    private var selectedLanguage = "ES"
    private var lyricLines = listOf<LyricLine>()
    private var lyricLabels = mutableListOf<TextView>()
    private var lastLyricIndex = -1
    private var countedStartForTrackId: String? = null

    private var seekBar: SeekBar? = null
    private var elapsedView: TextView? = null
    private var durationView: TextView? = null
    private var playButton: TextView? = null
    private var titleView: TextView? = null
    private var artistView: TextView? = null
    private var heartButton: TextView? = null
    private var lyricsContainer: LinearLayout? = null
    private var translateButton: TextView? = null

    private val tick = object : Runnable {
        override fun run() {
            updatePlaybackUi()
            ui.postDelayed(this, 250)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window.statusBarColor = C_BG
        window.navigationBarColor = C_BG
        root = FrameLayout(this)
        root.setBackgroundColor(C_WHITE)
        setContentView(root)
        showIntroThenStart()
    }

    private fun showIntroThenStart() {
        window.statusBarColor = C_WHITE
        window.navigationBarColor = C_WHITE
        root.removeAllViews()
        root.setBackgroundColor(C_WHITE)

        val introText = TextView(this).apply {
            text = "Música, maestro"
            setTextColor(Color.BLACK)
            textSize = 32f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            alpha = 0f
            letterSpacing = 0.02f
        }
        root.addView(introText, FrameLayout.LayoutParams(-1, -1))

        fun startApp() {
            introText.animate().cancel()
            root.removeAllViews()
            root.setBackgroundColor(C_BG)
            window.statusBarColor = C_BG
            window.navigationBarColor = C_BG
            loadPrefs()
            loadMedia()
            ui.post(tick)
        }

        introText.animate()
            .alpha(1f)
            .setDuration(650)
            .withEndAction {
                ui.postDelayed({
                    introText.animate()
                        .alpha(0f)
                        .setDuration(500)
                        .withEndAction {
                            introText.text = "Music, mr"
                            introText.animate()
                                .alpha(1f)
                                .setDuration(650)
                                .withEndAction {
                                    ui.postDelayed({
                                        introText.animate()
                                            .alpha(0f)
                                            .setDuration(500)
                                            .withEndAction { startApp() }
                                            .start()
                                    }, 600)
                                }
                                .start()
                        }
                        .start()
                }, 700)
            }
            .start()
    }

    override fun onDestroy() {
        super.onDestroy()
        ui.removeCallbacks(tick)
        player?.release()
        player = null
    }

    override fun onBackPressed() {
        if (currentScreen != "library") {
            buildLibraryScreen()
        } else {
            super.onBackPressed()
        }
    }

    private fun loadMedia() {
        val assetJson = assets.open("media.json").bufferedReader().use { it.readText() }
        tracks = parseMediaJson(assetJson).toMutableList()
        buildLibraryScreen()

        Thread {
            try {
                val remoteJson = httpGet(REMOTE_MEDIA_JSON)
                val remoteTracks = parseMediaJson(remoteJson)
                if (remoteTracks.isNotEmpty()) {
                    runOnUiThread {
                        tracks = remoteTracks.toMutableList()
                        if (currentScreen == "library") buildLibraryScreen()
                    }
                }
            } catch (_: Exception) {
                // El media.json local permite que la app arranque aunque todavía no exista el remoto.
            }
        }.start()
    }

    private fun parseMediaJson(json: String): List<Track> {
        val out = mutableListOf<Track>()
        val arr = JSONObject(json).getJSONArray("tracks")
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val lyricsObj = o.optJSONObject("lyrics")
            val lyrics = linkedMapOf<String, String>()
            if (lyricsObj != null) {
                val keys = lyricsObj.keys()
                while (keys.hasNext()) {
                    val originalKey = keys.next()
                    val k = originalKey.uppercase(Locale.ROOT)
                    lyrics[k] = lyricsObj.getString(originalKey)
                }
            }
            val duration = if (o.has("durationMs") && !o.isNull("durationMs")) o.getLong("durationMs") else null
            val title = o.getString("title")
            val rawArtist = o.optString("artist", "")
            val normalizedArtist = when {
                title.contains("The Last of Us", ignoreCase = true) -> ""
                rawArtist.isBlank() || rawArtist.equals("u3K", ignoreCase = true) -> "Anxo"
                else -> rawArtist
            }
            val coverUrl = o.optString("coverUrl", "").takeIf { it.isNotBlank() } ?: defaultCoverUrl(title)
            out += Track(
                id = o.getString("id"),
                title = title,
                artist = normalizedArtist,
                audioUrl = o.getString("audioUrl"),
                durationMs = duration,
                coverStyle = o.optString("coverStyle", defaultCoverStyle(title)),
                coverUrl = coverUrl,
                lyrics = lyrics
            )
        }
        return out
    }

    private fun buildLibraryScreen() {
        currentScreen = "library"
        titleView = null
        artistView = null
        heartButton = null
        seekBar = null
        elapsedView = null
        durationView = null
        playButton = null
        lyricsContainer = null
        translateButton = null
        root.removeAllViews()

        val main = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(0))
            setBackgroundColor(C_BG)
        }
        root.addView(main, FrameLayout.LayoutParams(-1, -1))

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        main.addView(top, LinearLayout.LayoutParams(-1, dp(54)))

        val logo = TextView(this).apply {
            text = "u3K"
            setTextColor(C_WHITE)
            textSize = 30f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL
        }
        top.addView(logo, LinearLayout.LayoutParams(0, -1, 1f))
        top.addView(iconText("♡", 30f).apply { setOnClickListener { filterMode = FilterMode.FAVORITES; buildLibraryScreen() } }, LinearLayout.LayoutParams(dp(40), -1))
        top.addView(iconText("Perfil", 15f).apply { setOnClickListener { buildProfileScreen() } }, LinearLayout.LayoutParams(dp(64), -1))

        val search = EditText(this).apply {
            hint = "Buscar canciones..."
            setHintTextColor(C_MUTED)
            setTextColor(C_TEXT)
            textSize = 15f
            singleLineSet()
            background = rounded(C_CARD, dp(13), 0)
            setPadding(dp(16), 0, dp(16), 0)
            setText(searchTerm)
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    searchTerm = s?.toString().orEmpty()
                    refreshSongList()
                }
                override fun afterTextChanged(s: Editable?) {}
            })
        }
        main.addView(search, LinearLayout.LayoutParams(-1, dp(56)).apply { bottomMargin = dp(12) })

        val chips = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        main.addView(chips, LinearLayout.LayoutParams(-1, dp(45)).apply { bottomMargin = dp(6) })
        chips.addView(filterChip("Todas", FilterMode.ALL), LinearLayout.LayoutParams(dp(94), dp(38)).apply { rightMargin = dp(10) })
        chips.addView(filterChip("♡  Favoritas", FilterMode.FAVORITES), LinearLayout.LayoutParams(dp(128), dp(38)).apply { rightMargin = dp(10) })
        chips.addView(filterChip("◷  Recientes", FilterMode.RECENTS), LinearLayout.LayoutParams(dp(128), dp(38)))

        val listScroll = ScrollView(this).apply { isFillViewport = false }
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            id = LIST_CONTAINER_ID
        }
        listScroll.addView(list, ScrollView.LayoutParams(-1, -2))
        main.addView(listScroll, LinearLayout.LayoutParams(-1, 0, 1f))

        buildBottomBar(main, "Biblioteca")
        refreshSongList()
    }

    private fun refreshSongList() {
        val list = root.findViewById<LinearLayout>(LIST_CONTAINER_ID) ?: return
        list.removeAllViews()
        val q = searchTerm.trim().lowercase(Locale.ROOT)
        val filtered = tracks.filter { track ->
            val byFilter = when (filterMode) {
                FilterMode.ALL -> true
                FilterMode.FAVORITES -> favorites.contains(track.id)
                FilterMode.RECENTS -> recents.contains(track.id)
            }
            val byText = q.isBlank() || track.title.lowercase(Locale.ROOT).contains(q) || track.artist.lowercase(Locale.ROOT).contains(q)
            byFilter && byText
        }.let { list ->
            if (filterMode == FilterMode.RECENTS) list.sortedBy { recents.indexOf(it.id).takeIf { pos -> pos >= 0 } ?: Int.MAX_VALUE } else list
        }

        if (filtered.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "No hay canciones para este filtro."
                setTextColor(C_MUTED)
                textSize = 15f
                gravity = Gravity.CENTER
                setPadding(0, dp(40), 0, 0)
            }, LinearLayout.LayoutParams(-1, dp(120)))
            return
        }

        filtered.forEach { track -> list.addView(songRow(track), LinearLayout.LayoutParams(-1, dp(73))) }
    }

    private fun songRow(track: Track): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(8))
            setBackgroundColor(C_BG)
            setOnClickListener { openPlayer(tracks.indexOfFirst { it.id == track.id }.coerceAtLeast(0)) }
        }

        val cover = coverView(track, dp(54), dp(10), if (track.coverStyle == "logo") 10f else 22f)
        row.addView(cover, LinearLayout.LayoutParams(dp(54), dp(54)).apply { rightMargin = dp(14) })

        val center = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(center, LinearLayout.LayoutParams(0, -1, 1f))

        center.addView(TextView(this).apply {
            text = track.title
            setTextColor(C_TEXT)
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
        }, LinearLayout.LayoutParams(-1, 0, 1f))

        val tagRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        tagRow.addView(smallTag("LRC"), LinearLayout.LayoutParams(dp(36), dp(24)).apply { rightMargin = dp(6) })
        track.lyrics.keys.sorted().forEach { lang -> tagRow.addView(smallTag(lang), LinearLayout.LayoutParams(dp(34), dp(24)).apply { rightMargin = dp(6) }) }
        center.addView(tagRow, LinearLayout.LayoutParams(-1, dp(27)))

        row.addView(TextView(this).apply {
            text = formatTime(track.durationMs ?: 0L).takeIf { track.durationMs != null } ?: "--:--"
            setTextColor(C_MUTED)
            textSize = 14f
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(dp(54), -1))
        row.addView(iconText("⋮", 26f), LinearLayout.LayoutParams(dp(24), -1))

        val wrapper = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(row, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(View(this@MainActivity).apply { setBackgroundColor(C_LINE) }, LinearLayout.LayoutParams(-1, 1))
        }
        return wrapper
    }

    private fun buildPlayerScreen() {
        currentScreen = "player"
        val track = tracks.getOrNull(currentIndex) ?: return
        root.removeAllViews()
        root.setBackgroundColor(C_BG)
        lyricLabels.clear()
        lastLyricIndex = -1

        val scroll = ScrollView(this).apply { isFillViewport = true }
        val main = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(22), dp(18), dp(22), dp(0))
        }
        scroll.addView(main, ScrollView.LayoutParams(-1, -2))
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        main.addView(top, LinearLayout.LayoutParams(-1, dp(48)))
        top.addView(iconText("⌄", 32f).apply { setOnClickListener { buildLibraryScreen() } }, LinearLayout.LayoutParams(dp(52), -1))
        top.addView(TextView(this).apply {
            text = "Ahora reproduciendo"
            setTextColor(C_TEXT)
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(0, -1, 1f))
        top.addView(iconText("⋮", 28f), LinearLayout.LayoutParams(dp(52), -1))

        val cover = coverView(track, dp(300), dp(14), if (track.coverStyle == "logo") 24f else 52f)
        main.addView(cover, LinearLayout.LayoutParams(dp(300), dp(300)).apply { topMargin = dp(12); bottomMargin = dp(26) })

        val titleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        main.addView(titleRow, LinearLayout.LayoutParams(-1, dp(66)))
        val titleBlock = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
        titleView = TextView(this).apply {
            text = track.title
            setTextColor(C_TEXT)
            textSize = 24f
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 2
        }
        artistView = TextView(this).apply {
            text = track.artist
            setTextColor(C_MUTED)
            textSize = 14f
            visibility = if (track.artist.isBlank()) View.INVISIBLE else View.VISIBLE
        }
        titleBlock.addView(titleView, LinearLayout.LayoutParams(-1, 0, 1f))
        titleBlock.addView(artistView, LinearLayout.LayoutParams(-1, 0, 1f))
        titleRow.addView(titleBlock, LinearLayout.LayoutParams(0, -1, 1f))
        heartButton = iconText(if (favorites.contains(track.id)) "♥" else "♡", 36f).apply {
            setOnClickListener { toggleFavorite(track.id); text = if (favorites.contains(track.id)) "♥" else "♡" }
        }
        titleRow.addView(heartButton, LinearLayout.LayoutParams(dp(56), -1))

        seekBar = SeekBar(this).apply {
            max = (track.durationMs ?: 1L).toInt()
            progress = 0
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser && isPrepared) player?.seekTo(progress)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        main.addView(seekBar, LinearLayout.LayoutParams(-1, dp(36)))

        val times = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        elapsedView = smallMuted("0:00")
        durationView = smallMuted(formatTime(track.durationMs ?: 0L).takeIf { track.durationMs != null } ?: "--:--").apply { gravity = Gravity.RIGHT }
        times.addView(elapsedView, LinearLayout.LayoutParams(0, dp(22), 1f))
        times.addView(durationView, LinearLayout.LayoutParams(0, dp(22), 1f))
        main.addView(times, LinearLayout.LayoutParams(-1, dp(25)))

        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        main.addView(controls, LinearLayout.LayoutParams(-1, dp(84)).apply { topMargin = dp(6) })
        controls.addView(iconText("⇄", 26f), LinearLayout.LayoutParams(0, -1, 1f))
        controls.addView(iconText("⏮", 34f).apply { setOnClickListener { previousTrack() } }, LinearLayout.LayoutParams(0, -1, 1f))
        playButton = TextView(this).apply {
            text = "▶"
            textSize = 32f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(C_BG)
            background = rounded(C_WHITE, dp(34), 0)
            setOnClickListener { togglePlayback() }
        }
        controls.addView(playButton, LinearLayout.LayoutParams(dp(72), dp(72)))
        controls.addView(iconText("⏭", 34f).apply { setOnClickListener { nextTrack() } }, LinearLayout.LayoutParams(0, -1, 1f))
        controls.addView(iconText("↻", 26f), LinearLayout.LayoutParams(0, -1, 1f))

        translateButton = TextView(this).apply {
            text = if (track.lyrics.size > 1) "◎  Traducir" else "◎  Letra"
            setTextColor(C_TEXT)
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(0x00000000, dp(10), C_LINE)
            isEnabled = track.lyrics.size > 1
            alpha = if (track.lyrics.size > 1) 1f else 0.65f
            setOnClickListener { toggleLyricsLanguage() }
        }
        main.addView(translateButton, LinearLayout.LayoutParams(dp(145), dp(44)).apply { topMargin = dp(4); bottomMargin = dp(8) })

        val shareButton = TextView(this).apply {
            text = "↗  Compartir letra"
            setTextColor(C_TEXT)
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(0x00000000, dp(10), C_LINE)
            setOnClickListener { showShareLyricsOptions() }
        }
        main.addView(shareButton, LinearLayout.LayoutParams(dp(180), dp(44)).apply { bottomMargin = dp(12) })

        lyricsContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, dp(6), 0, dp(36))
        }
        main.addView(lyricsContainer, LinearLayout.LayoutParams(-1, -2))
        renderLyricsLoading()
    }

    private fun openPlayer(index: Int) {
        if (tracks.isEmpty()) return
        currentIndex = index.coerceIn(0, tracks.lastIndex)
        addRecent(tracks[currentIndex].id)
        buildPlayerScreen()
        prepareCurrentTrack(true)
    }

    private fun prepareCurrentTrack(autoplay: Boolean) {
        val track = tracks.getOrNull(currentIndex) ?: return
        player?.release()
        player = null
        isPrepared = false
        countedStartForTrackId = null
        playButton?.text = "…"
        lyricLines = emptyList()
        selectedLanguage = when {
            track.lyrics.containsKey("ES") -> "ES"
            track.lyrics.containsKey("EN") -> "EN"
            track.lyrics.isNotEmpty() -> track.lyrics.keys.first()
            else -> "ES"
        }
        loadLyrics(track)

        val mp = MediaPlayer()
        player = mp
        try {
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .build()
            )
            mp.setDataSource(this, Uri.parse(track.audioUrl))
            mp.setOnPreparedListener {
                isPrepared = true
                seekBar?.max = max(1, it.duration)
                durationView?.text = formatTime(it.duration.toLong())
                playButton?.text = if (autoplay) "Ⅱ" else "▶"
                if (autoplay) {
                    registerListen(track.id)
                    it.start()
                }
            }
            mp.setOnCompletionListener { nextTrack() }
            mp.setOnErrorListener { _, _, _ ->
                Toast.makeText(this, "No se pudo reproducir esta canción.", Toast.LENGTH_LONG).show()
                playButton?.text = "▶"
                true
            }
            mp.prepareAsync()
        } catch (e: Exception) {
            Toast.makeText(this, "Error al abrir el MP3: ${e.message}", Toast.LENGTH_LONG).show()
            playButton?.text = "▶"
        }
    }

    private fun togglePlayback() {
        val mp = player ?: return
        if (!isPrepared) return
        if (mp.isPlaying) {
            mp.pause()
            playButton?.text = "▶"
        } else {
            tracks.getOrNull(currentIndex)?.let { registerListen(it.id) }
            mp.start()
            playButton?.text = "Ⅱ"
        }
    }

    private fun nextTrack() {
        if (tracks.isEmpty()) return
        currentIndex = if (currentIndex < 0) 0 else (currentIndex + 1) % tracks.size
        addRecent(tracks[currentIndex].id)
        buildPlayerScreen()
        prepareCurrentTrack(true)
    }

    private fun previousTrack() {
        if (tracks.isEmpty()) return
        currentIndex = if (currentIndex <= 0) tracks.lastIndex else currentIndex - 1
        addRecent(tracks[currentIndex].id)
        buildPlayerScreen()
        prepareCurrentTrack(true)
    }

    private fun updatePlaybackUi() {
        val mp = player ?: return
        if (!isPrepared) return
        try {
            val pos = mp.currentPosition
            val dur = max(1, mp.duration)
            seekBar?.max = dur
            if (seekBar?.isPressed != true) seekBar?.progress = min(pos, dur)
            elapsedView?.text = formatTime(pos.toLong())
            durationView?.text = formatTime(dur.toLong())
            playButton?.text = if (mp.isPlaying) "Ⅱ" else "▶"
            updateLyricHighlight(pos.toLong())
        } catch (_: Exception) {}
    }

    private fun loadLyrics(track: Track) {
        val url = track.lyrics[selectedLanguage]
        if (url == null) {
            renderLyricsMessage("Letra no disponible.")
            return
        }
        renderLyricsLoading()
        Thread {
            try {
                val text = httpGet(url)
                val parsed = parseLrc(text)
                runOnUiThread {
                    lyricLines = parsed
                    if (parsed.isEmpty()) renderLyricsMessage("La letra LRC está vacía o no tiene marcas de tiempo.") else renderLyrics()
                }
            } catch (e: Exception) {
                runOnUiThread { renderLyricsMessage("No se pudo cargar la letra ${selectedLanguage}.") }
            }
        }.start()
    }

    private fun toggleLyricsLanguage() {
        val track = tracks.getOrNull(currentIndex) ?: return
        if (track.lyrics.size <= 1) return
        val keys = track.lyrics.keys.sorted()
        val currentPos = keys.indexOf(selectedLanguage).takeIf { it >= 0 } ?: 0
        selectedLanguage = keys[(currentPos + 1) % keys.size]
        translateButton?.text = "◎  $selectedLanguage"
        loadLyrics(track)
    }

    private fun renderLyricsLoading() = renderLyricsMessage("Cargando letra sincronizada…")

    private fun renderLyricsMessage(message: String) {
        lyricsContainer?.removeAllViews()
        lyricLabels.clear()
        lyricsContainer?.addView(TextView(this).apply {
            text = message
            setTextColor(C_MUTED)
            textSize = 17f
            gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, dp(18))
        }, LinearLayout.LayoutParams(-1, -2))
    }

    private fun renderLyrics() {
        val box = lyricsContainer ?: return
        box.removeAllViews()
        lyricLabels.clear()
        lyricLines.forEach { line ->
            val tv = TextView(this).apply {
                text = line.text
                setTextColor(C_MUTED)
                alpha = 0.68f
                textSize = 18f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT
                setPadding(dp(4), dp(8), dp(4), dp(8))
            }
            lyricLabels += tv
            box.addView(tv, LinearLayout.LayoutParams(-1, -2))
        }
    }

    private fun updateLyricHighlight(positionMs: Long) {
        if (lyricLines.isEmpty() || lyricLabels.isEmpty()) return
        var idx = 0
        for (i in lyricLines.indices) {
            if (positionMs >= lyricLines[i].timeMs) idx = i else break
        }
        if (idx == lastLyricIndex) return
        lastLyricIndex = idx
        lyricLabels.forEachIndexed { i, tv ->
            val distance = kotlin.math.abs(i - idx)
            when (distance) {
                0 -> {
                    tv.setTextColor(C_WHITE)
                    tv.alpha = 1f
                    tv.textSize = 23f
                    tv.typeface = Typeface.DEFAULT_BOLD
                }
                1 -> {
                    tv.setTextColor(C_TEXT)
                    tv.alpha = 0.78f
                    tv.textSize = 18f
                    tv.typeface = Typeface.DEFAULT_BOLD
                }
                else -> {
                    tv.setTextColor(C_MUTED)
                    tv.alpha = 0.48f
                    tv.textSize = 17f
                    tv.typeface = Typeface.DEFAULT
                }
            }
        }
    }

    private fun parseLrc(text: String): List<LyricLine> {
        val out = mutableListOf<LyricLine>()
        val rx = Regex("\\[(\\d{1,2}):(\\d{2})(?:\\.(\\d{1,3}))?]")
        text.lineSequence().forEach { raw ->
            val matches = rx.findAll(raw).toList()
            if (matches.isEmpty()) return@forEach
            val lyricText = raw.substringAfterLast("]").trim()
            if (lyricText.isBlank()) return@forEach
            matches.forEach { m ->
                val min = m.groupValues[1].toLong()
                val sec = m.groupValues[2].toLong()
                val frac = m.groupValues.getOrNull(3).orEmpty()
                val ms = when (frac.length) {
                    0 -> 0L
                    1 -> frac.toLong() * 100
                    2 -> frac.toLong() * 10
                    else -> frac.take(3).toLong()
                }
                out += LyricLine(min * 60_000 + sec * 1_000 + ms, lyricText)
            }
        }
        return out.sortedBy { it.timeMs }
    }

    private fun filterChip(label: String, mode: FilterMode): TextView = TextView(this).apply {
        text = label
        gravity = Gravity.CENTER
        textSize = 14f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(if (filterMode == mode) C_BG else C_TEXT)
        background = rounded(if (filterMode == mode) C_WHITE else 0x00000000, dp(11), if (filterMode == mode) 0 else C_LINE)
        setOnClickListener {
            filterMode = mode
            buildLibraryScreen()
        }
    }

    private fun smallTag(label: String): TextView = TextView(this).apply {
        text = label
        setTextColor(C_TEXT)
        textSize = 11f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        background = rounded(C_CHIP, dp(5), 0)
    }

    private fun smallMuted(value: String): TextView = TextView(this).apply {
        text = value
        setTextColor(C_MUTED)
        textSize = 14f
        gravity = Gravity.LEFT or Gravity.CENTER_VERTICAL
    }

    private fun iconText(value: String, size: Float): TextView = TextView(this).apply {
        text = value
        textSize = size
        gravity = Gravity.CENTER
        setTextColor(C_TEXT)
        typeface = Typeface.DEFAULT_BOLD
    }

    private fun buildBottomBar(main: LinearLayout, selected: String) {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(5), 0, dp(8))
            background = rounded(0xCC090A0D.toInt(), 0, C_LINE)
        }
        val home = navItem("⌂", "Inicio", selected == "Inicio").apply { setOnClickListener { buildLibraryScreen() } }
        val lib = navItem("◧", "Biblioteca", selected == "Biblioteca").apply { setOnClickListener { buildLibraryScreen() } }
        val profile = navItem("♙", "Perfil", selected == "Perfil").apply { setOnClickListener { buildProfileScreen() } }
        bar.addView(home, LinearLayout.LayoutParams(0, -1, 1f))
        bar.addView(lib, LinearLayout.LayoutParams(0, -1, 1f))
        bar.addView(profile, LinearLayout.LayoutParams(0, -1, 1f))
        main.addView(bar, LinearLayout.LayoutParams(-1, dp(76)))
    }

    private fun navItem(icon: String, label: String, selected: Boolean): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        val iconView = TextView(this@MainActivity).apply {
            text = icon
            textSize = 30f
            gravity = Gravity.CENTER
            setTextColor(if (selected) C_WHITE else C_MUTED)
        }
        val textView = TextView(this@MainActivity).apply {
            text = label
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(if (selected) C_WHITE else C_MUTED)
            typeface = if (selected) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }
        addView(iconView, LinearLayout.LayoutParams(-1, 0, 1f))
        addView(textView, LinearLayout.LayoutParams(-1, 0, 1f))
    }

    private fun toggleFavorite(id: String) {
        if (favorites.contains(id)) favorites.remove(id) else favorites.add(id)
        savePrefs()
    }

    private fun addRecent(id: String) {
        recents.remove(id)
        recents.add(0, id)
        while (recents.size > 30) recents.removeAt(recents.lastIndex)
        savePrefs()
    }

    private fun loadPrefs() {
        val sp = getSharedPreferences("u3k", MODE_PRIVATE)
        favorites.clear()
        favorites.addAll(sp.getString("favorites", "").orEmpty().split('|').filter { it.isNotBlank() })
        recents.clear()
        recents.addAll(sp.getString("recents", "").orEmpty().split('|').filter { it.isNotBlank() })
        totalListens = sp.getInt("totalListens", 0)
        playCounts.clear()
        sp.getString("playCounts", "").orEmpty().split('|').forEach { item ->
            val parts = item.split('=', limit = 2)
            val id = parts.getOrNull(0).orEmpty()
            val count = parts.getOrNull(1)?.toIntOrNull() ?: 0
            if (id.isNotBlank() && count > 0) playCounts[id] = count
        }
    }

    private fun savePrefs() {
        getSharedPreferences("u3k", MODE_PRIVATE).edit()
            .putString("favorites", favorites.joinToString("|"))
            .putString("recents", recents.joinToString("|"))
            .putInt("totalListens", totalListens)
            .putString("playCounts", playCounts.entries.joinToString("|") { "${it.key}=${it.value}" })
            .apply()
    }

    private fun registerListen(id: String) {
        if (countedStartForTrackId == id) return
        countedStartForTrackId = id
        totalListens += 1
        playCounts[id] = (playCounts[id] ?: 0) + 1
        savePrefs()
    }

    private fun buildProfileScreen() {
        currentScreen = "profile"
        titleView = null
        artistView = null
        heartButton = null
        seekBar = null
        elapsedView = null
        durationView = null
        playButton = null
        lyricsContainer = null
        translateButton = null
        root.removeAllViews()
        root.setBackgroundColor(C_BG)

        val main = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(0))
            setBackgroundColor(C_BG)
        }
        root.addView(main, FrameLayout.LayoutParams(-1, -1))

        main.addView(TextView(this).apply {
            text = "Perfil"
            setTextColor(C_TEXT)
            textSize = 30f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL
        }, LinearLayout.LayoutParams(-1, dp(58)))

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(16))
        }
        scroll.addView(content, ScrollView.LayoutParams(-1, -2))
        main.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val stats = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        stats.addView(statCard("Escuchas", totalListens.toString()), LinearLayout.LayoutParams(0, dp(92), 1f).apply { rightMargin = dp(8) })
        stats.addView(statCard("Favoritos", favorites.size.toString()), LinearLayout.LayoutParams(0, dp(92), 1f).apply { leftMargin = dp(8) })
        content.addView(stats, LinearLayout.LayoutParams(-1, dp(96)).apply { bottomMargin = dp(16) })

        content.addView(TextView(this).apply {
            text = PROFILE_HAND_TEXT
            setTextColor(C_TEXT)
            textSize = 24f
            typeface = Typeface.create("casual", Typeface.NORMAL)
            setLineSpacing(dp(4).toFloat(), 1.05f)
            gravity = Gravity.CENTER
            background = rounded(C_CARD, dp(20), C_LINE)
            setPadding(dp(22), dp(24), dp(22), dp(24))
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(22) })

        content.addView(TextView(this).apply {
            text = "Favoritos"
            setTextColor(C_TEXT)
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(-1, dp(38)))

        val favTracks = favorites.mapNotNull { id -> tracks.firstOrNull { it.id == id } }
        if (favTracks.isEmpty()) {
            content.addView(TextView(this).apply {
                text = "Todavía no guardaste canciones como favoritas. Pulsa el corazón en el reproductor para añadirlas aquí."
                setTextColor(C_MUTED)
                textSize = 15f
                gravity = Gravity.CENTER
                background = rounded(C_CARD, dp(16), C_LINE)
                setPadding(dp(18), dp(22), dp(18), dp(22))
            }, LinearLayout.LayoutParams(-1, -2))
        } else {
            favTracks.forEach { track -> content.addView(songRow(track), LinearLayout.LayoutParams(-1, dp(73))) }
        }

        buildBottomBar(main, "Perfil")
    }

    private fun statCard(label: String, value: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        background = rounded(C_CARD, dp(18), C_LINE)
        addView(TextView(this@MainActivity).apply {
            text = value
            setTextColor(C_WHITE)
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, 0, 1f))
        addView(TextView(this@MainActivity).apply {
            text = label
            setTextColor(C_MUTED)
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, 0, 1f))
    }

    private fun showShareLyricsOptions() {
        val options = arrayOf("WhatsApp / Estado", "Instagram", "Compartir con otra app", "Guardar en galería")
        AlertDialog.Builder(this)
            .setTitle("Letra como imagen")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> shareCurrentLyric("whatsapp")
                    1 -> shareCurrentLyric("instagram")
                    2 -> shareCurrentLyric("generic")
                    3 -> shareCurrentLyric("gallery")
                }
            }
            .show()
    }

    private fun shareCurrentLyric(target: String) {
        val track = tracks.getOrNull(currentIndex)
        if (track == null || lyricLines.isEmpty()) {
            Toast.makeText(this, "No hay letra cargada para compartir.", Toast.LENGTH_SHORT).show()
            return
        }
        val bitmap = makeLyricShareBitmap(track)
        if (target == "gallery") {
            val uri = saveBitmapToGallery(bitmap, track)
            Toast.makeText(this, if (uri != null) "Imagen guardada en la galería." else "No se pudo guardar la imagen.", Toast.LENGTH_LONG).show()
            return
        }
        val uri = saveBitmapToCache(bitmap, track)
        if (uri == null) {
            Toast.makeText(this, "No se pudo preparar la imagen.", Toast.LENGTH_LONG).show()
            return
        }
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, "u3K - ${track.title}")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        when (target) {
            "whatsapp" -> intent.setPackage("com.whatsapp")
            "instagram" -> intent.setPackage("com.instagram.android")
        }
        try {
            if (target != "generic" && intent.resolveActivity(packageManager) != null) {
                startActivity(intent)
            } else {
                intent.setPackage(null)
                startActivity(Intent.createChooser(intent, "Compartir letra"))
            }
        } catch (_: Exception) {
            intent.setPackage(null)
            startActivity(Intent.createChooser(intent, "Compartir letra"))
        }
    }

    private fun makeLyricShareBitmap(track: Track): Bitmap {
        val w = 1080
        val h = 1920
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val palettes = arrayOf(
            intArrayOf(0xFF6E7F80.toInt(), 0xFF2F3F45.toInt()),
            intArrayOf(0xFF8A6F5A.toInt(), 0xFF392C28.toInt()),
            intArrayOf(0xFF64748B.toInt(), 0xFF1F2937.toInt()),
            intArrayOf(0xFF7C6D8A.toInt(), 0xFF2B2433.toInt()),
            intArrayOf(0xFF6A8068.toInt(), 0xFF243126.toInt())
        )
        val pair = palettes[kotlin.math.abs(track.id.hashCode()) % palettes.size]
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), pair[0], pair[1], Shader.TileMode.CLAMP)
        }
        canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), paint)

        val logoPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 58f
            typeface = Typeface.DEFAULT_BOLD
            alpha = 230
        }
        canvas.drawText("u3K", 82f, 125f, logoPaint)

        val idx = lastLyricIndex.takeIf { it in lyricLines.indices } ?: 0
        val from = max(0, idx - 1)
        val to = min(lyricLines.size, idx + 3)
        val shareLines = lyricLines.subList(from, to)
        var y = 610f
        shareLines.forEachIndexed { offset, line ->
            val absoluteIndex = from + offset
            val isCurrent = absoluteIndex == idx
            val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = if (isCurrent) 74f else 52f
                typeface = if (isCurrent) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                alpha = if (isCurrent) 255 else 185
            }
            val layout = StaticLayout.Builder.obtain(line.text, 0, line.text.length, tp, w - 160)
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .setLineSpacing(6f, 1.0f)
                .build()
            canvas.save()
            canvas.translate(80f, y)
            layout.draw(canvas)
            canvas.restore()
            y += layout.height + if (isCurrent) 54f else 38f
        }

        val metaPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 42f
            typeface = Typeface.DEFAULT_BOLD
            alpha = 235
        }
        val subPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 34f
            typeface = Typeface.DEFAULT
            alpha = 185
        }
        drawWrappedText(canvas, track.title, metaPaint, 80f, 1630f, w - 160, Layout.Alignment.ALIGN_NORMAL)
        if (track.artist.isNotBlank()) drawWrappedText(canvas, track.artist, subPaint, 80f, 1702f, w - 160, Layout.Alignment.ALIGN_NORMAL)
        drawWrappedText(canvas, "Letra sincronizada · $selectedLanguage", subPaint, 80f, 1794f, w - 160, Layout.Alignment.ALIGN_NORMAL)
        return bitmap
    }

    private fun drawWrappedText(canvas: Canvas, text: String, paint: TextPaint, x: Float, y: Float, width: Int, alignment: Layout.Alignment) {
        val layout = StaticLayout.Builder.obtain(text, 0, text.length, paint, width)
            .setAlignment(alignment)
            .setLineSpacing(4f, 1.0f)
            .setMaxLines(2)
            .build()
        canvas.save()
        canvas.translate(x, y)
        layout.draw(canvas)
        canvas.restore()
    }

    private fun saveBitmapToCache(bitmap: Bitmap, track: Track): Uri? = try {
        val dir = File(cacheDir, "shared").apply { mkdirs() }
        val file = File(dir, "u3k_${safeFilePart(track.id)}_${System.currentTimeMillis()}.png")
        FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
    } catch (_: Exception) {
        null
    }

    private fun saveBitmapToGallery(bitmap: Bitmap, track: Track): Uri? = try {
        val filename = "u3K_${safeFilePart(track.title)}_${System.currentTimeMillis()}.png"
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, filename)
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/u3K")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        contentResolver.openOutputStream(uri)?.use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)
        }
        uri
    } catch (_: Exception) {
        null
    }

    private fun coverView(track: Track, sizePx: Int, radiusPx: Int, labelSize: Float): FrameLayout {
        val frame = FrameLayout(this).apply { background = coverDrawable(track.coverStyle, radiusPx) }
        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = 0f
        }
        val label = TextView(this).apply {
            text = coverLabel(track)
            gravity = Gravity.CENTER
            setTextColor(C_WHITE)
            textSize = labelSize
            typeface = Typeface.DEFAULT_BOLD
        }
        frame.addView(image, FrameLayout.LayoutParams(sizePx, sizePx))
        frame.addView(label, FrameLayout.LayoutParams(sizePx, sizePx))
        track.coverUrl?.let { loadCoverImage(it, image, label) }
        return frame
    }

    private fun loadCoverImage(url: String, imageView: ImageView, fallbackLabel: TextView) {
        coverCache[url]?.let {
            imageView.setImageBitmap(it)
            imageView.alpha = 1f
            fallbackLabel.visibility = View.GONE
            return
        }
        Thread {
            try {
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 10000
                conn.readTimeout = 10000
                conn.setRequestProperty("User-Agent", "u3K-Android-Player")
                val bitmap = conn.inputStream.use { BitmapFactory.decodeStream(it) }
                if (bitmap != null) {
                    coverCache[url] = bitmap
                    runOnUiThread {
                        imageView.setImageBitmap(bitmap)
                        imageView.animate().alpha(1f).setDuration(250).start()
                        fallbackLabel.visibility = View.GONE
                    }
                }
            } catch (_: Exception) {}
        }.start()
    }

    private fun defaultCoverUrl(title: String): String {
        val file = when {
            title.contains("The Last of Us", ignoreCase = true) -> "cover2.jpg"
            title.contains("-") || title.contains("–") -> "cover3.jpg"
            else -> "cover1.jpg"
        }
        return REMOTE_BASE + file
    }

    private fun defaultCoverStyle(title: String): String = when {
        title.contains("The Last of Us", ignoreCase = true) -> "logo"
        title.contains("-") || title.contains("–") -> "red"
        else -> "sunset"
    }

    private fun safeFilePart(value: String): String = value.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9]+"), "_").trim('_').take(50).ifBlank { "letra" }

    private fun rounded(fill: Int, radius: Int, stroke: Int): GradientDrawable = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = radius.toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    private fun coverDrawable(style: String, radius: Int): GradientDrawable {
        val colors = when (style) {
            "ocean" -> intArrayOf(0xFF0F3A4D.toInt(), 0xFF071018.toInt(), 0xFF0D2530.toInt())
            "sunset" -> intArrayOf(0xFFECB37B.toInt(), 0xFF3A241B.toInt(), 0xFF0B0D10.toInt())
            "red" -> intArrayOf(0xFFE73370.toInt(), 0xFF262A47.toInt(), 0xFF111318.toInt())
            "group" -> intArrayOf(0xFFACB6C5.toInt(), 0xFF6F4D32.toInt(), 0xFF14161B.toInt())
            "logo" -> intArrayOf(0xFF0A0A0C.toInt(), 0xFF14161B.toInt(), 0xFF050506.toInt())
            else -> intArrayOf(0xFF262931.toInt(), 0xFF111318.toInt(), 0xFF06070A.toInt())
        }
        return GradientDrawable(GradientDrawable.Orientation.TL_BR, colors).apply { cornerRadius = radius.toFloat() }
    }

    private fun coverLabel(track: Track): String = when (track.coverStyle) {
        "logo" -> "THE\nLAST\nOF US"
        "ocean" -> "⌁"
        "sunset" -> "◑"
        "red" -> "◆"
        "group" -> "☰"
        else -> track.title.take(1).uppercase(Locale.ROOT)
    }

    private fun formatTime(ms: Long): String {
        val total = max(0, ms / 1000)
        val min = total / 60
        val sec = total % 60
        return "%d:%02d".format(Locale.ROOT, min, sec)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun TextView.singleLineSet() {
        setSingleLine(true)
    }

    private fun httpGet(url: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 12000
        conn.readTimeout = 12000
        conn.setRequestProperty("User-Agent", "u3K-Android-Player")
        return conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
    }

    companion object {
        private const val LIST_CONTAINER_ID = 104203
    }
}
