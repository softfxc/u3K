plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.softfxc.u3k"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.softfxc.u3k"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
